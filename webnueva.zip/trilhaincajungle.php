<?php 

$title_tour = "Inca Jungle  Machu Picchu 4 Dias E 3 Noites"; // NO PONER EN MAYUSCULA
$title_seo = "TRILHA INCA JUNGLE MACHU PICCHU";  // TITULO SEO
$description_seo = "O Caminho Inca Jungle, é uma escolha de aventuras no ciclismo e na caminhada até Machu Picchu 4D/3N essa descida emocionante de BTT e caminhada pela selva Inca, será um passeio extraordinário e maravilhoso, onde se pode desfrutar de atividades diferentes e plantações nativas, tais como a secagem do café, bananais, e a sagrada folha de coca";  // DESCRIPCION SEO 

$final = $_SERVER["REQUEST_URI"];

$url = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
 ?>

<!doctype html>
<html lang="pt-BR">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?=$title_seo?></title>

    <meta content="<?=$description_seo?>" name="description" />

    <meta http-equiv="content-language" content="pt_BR" />
    <meta name="content-language" content="pt-BR" />

    <!-- open graph -->
    <meta property="og:locale" content="pt_BR" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?=$title_seo?>" />
    <meta property="og:description" content="<?=$description_seo?>" />
    <meta property="og:url" content="<?=$url?>" />
    <meta property="og:site_name" content="Trilha Inca Cuzco" />
    <meta property="og:image" content="/img/trilhasalkantay.jpg" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/tours.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
      <link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
      <link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
      <link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
      <link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
      <link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
      <link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
      <link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
      <link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
      <link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
      <link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
      <link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
      <link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
      <link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
      <link rel="manifest" href="/favicon/manifest.json">
      <meta name="msapplication-TileColor" content="#ffffff">
      <meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
      <meta name="theme-color" content="#ffffff">

  </head>
  <body>
<div id="wrapper">

<section class="top-page">
<?php include('includes/header.php') ?>
</section>

  <div id="page-content-wrapper">
    <section class="container bg-light shadow tours-body">
    <div class="row">
        <div class="col-12 col-sm-9">
          <h1 class="mt-1"><?=$title_tour?></h1>

          <article class="text-justify my-3 my-ms-5">

          <p>O Caminho Inca  Jungle, é uma escolha de aventuras no ciclismo e na caminhada até Machu Picchu  4D/3N essa descida emocionante de Bike e caminhada pela selva Inca, será um  passeio extraordinário e maravilhoso, onde se pode desfrutar de atividades  diferentes e plantações nativas, tais como a secagem do café, bananais, e a  sagrada folha de coca.&nbsp;<br>
          Esta Trilha Inca Jungle é uma grande alternativa  para pessoas que querem uma forma tranqüila e agradável, também para não ter  problemas na altitude, um pouco diferente de ter mais contato com os povos  locais que vivem do outro lado da cidade da região de Cusco. Esta opção é cheia  de adrenalina, excelentes vistas e passeios inesquecíveis!</p>

          </article>

          <div class="near_by_hotel_wrapper">
            <div class="near_by_hotel_container">
              <table class="table no-border custom_table dataTable no-footer dtr-inline">
                <colgroup>
                <col width="22%">
                <col width="78%">
                </colgroup>
                <tbody>
                  <tr>
                    <td class="first-td">DURAÇÂO:</td>
                    <td>4 DIAS E 3 NOITES</td>
                  </tr>
                  <tr>
                     <td class="first-td">TIPO DE CIRCUITO:</td>
                    <td>Aventura, Caminhada, hospedagem, Àguas Termais</td>
                  </tr>
                  <tr>
                     <td class="first-td">LOCAIS A VISITAR:</td>
                    <td>Nevados, ciclismo, Trilha Inca, as    plantações de coca,plantações de café, águas termais e povoados.</td>
                  </tr>
                  <tr>
                     <td class="first-td">TOTAL DA CAMINHADA</td>
                    <td>36 kilômetros.</td>
                  </tr>
                  <tr>
                     <td class="first-td">AVALIAÇÃO FISICA</td>
                    <td>Moderado a difícil</td>
                  </tr>
                  <tr>
                     <td class="first-td">DESCONTO PARA ESTUDANTES</td>
                    <td>Com Carteira Internacional de    Estudante (ISIC verde): - U$ 20.00. Tem que enviar cópia por email no ato da    reserva</td>
                  </tr>
                </tbody>
              </table>
            </div>
            </div>

             <div id="horizontalTab" class="mt-3">
                   <ul class="resp-tabs-list">
                        <li><i class="fa fa-list" aria-hidden="true"></i> Roteiro</li>
                        <li> <i class="fa fa-usd" aria-hidden="true"></i> Preços</li>
                        <li><i class="fa fa-list-ol" aria-hidden="true"></i> O que Inclui </li>
                        <li><i class="fa fa-cog" aria-hidden="true"></i> Opcionais</li>
                          <li><i class="fa fa-book" aria-hidden="true"></i> Inf. Gerais</li>
                       <li><i class="fa fa-question-circle-o" aria-hidden="true"></i> Condições Gerais</li>
                       <li><i class="fa fa-credit-card" aria-hidden="true"></i> Pagamento</li>
                        <li class="bg-danger text-white"><i class="fa fa-calendar-check-o" aria-hidden="true"></i> Reserva</li>
                    
                 
                  </ul>

                   <div class="resp-tabs-container text-justify">
                    <div class="termin">
                      
                    <strong>ROTEIRO</strong>
                    
                    <h2>DIA 01: CUSCO - SANTA MARIA (BIKE)</h2>
                    <p>Primeiramente nosso transfer passará  para buscá-los no hotel meia hora antes da saída, nossa viagem dura por volta  de 4h30m e no decorrer da viagem observaremos impressionantes paisagens, como  as montanhas mais altas da região, como o Nevado Veronica e Pitusiray, que se  encontra quase a 5800 m.a.n.m, também vamos ver os pitorescos povoados de  Poroy, chinchero e Ollantaytambo onde tomaremos a pista pela margem direita  para elevarmos até a altura de 4350 metros sobre o nivel do mar, encontraremos  a Abra del Malaga, ponto místico onde se realiza cerimônias de agradecimento a  Pachamama (Terra Mãe) com muita freqüência. Neste ponto já poderemos observar  todo o Vale da Convencion, onde também será o ponto onde podemos coordenar com  o guia para começar nossa aventura Full Adrenalina, mas no caso que esteja  neblina baixa, desceremos com o carro até um local que se chama San Luis onde  nosso guia nos entregará as bicicletas, onde começaremos uma das excursões mais  lindas do mundo comparada somente com a de Coroico na Bolivia, iremos descendo  em Down Hill, observando a Imensidão do Vale da Convencion e conforme  desceremos irão encontrar diferentes espécies da flora e fauna, visitaremos na  metade do caminho as Ruínas dos Inkas do Wamanmarka.</p>
                    
                    <p>Iremos almoçar e seguiremos viagem por mais 4  horas de bike e chegaremos a 1430 metros de altura em Santa Maria. (nossa  primeira noite em um lodge de serviços básicos). Onde teremos o jantar em uma  região de floresta e teremos um pequeno resumo e comentário sobre o trekking do  dia seguinte com todo o grupo.</p>
                    <div class="text-center my-2"><img class="img-thumbnail m-1"  src="img/tours/santamaria.jpg" alt="TRILHA INCA JUNGLE"><img class="img-thumbnail m-1"  src="img/tours/wamanmarka.jpg" alt="TRILHA INCA JUNGLE"></div>

                    <h2>DIA 02: SANTA MARIA - SANTA TERESA (TREKKING)</h2>
                    <p>Depois de um bom café da manhã, com  muitas vitaminas a base de banana, laranjas, mamão e outras frutas da região,  estaremos dispostos a começar a nossa fantástica caminhada cheia de aventuras,  caminharemos por lugares cheios de vegetação onde podemos apreciar o cultivo e  a secagem do café , assim como a planta sagrada dos Incas a folha de COCA,  caminharemos por segmentos de caminhos incas originais, onde encontraremos com  a história&nbsp;<strong>kapac ñan</strong>&nbsp;(redes de caninhos inca), hoje degradada pelo tempo, depois da  energética caminhada com seu ar mais puro do mundo, teremos a oportunidade de  ingressar aos Banhos Termos-Medicinais de Cocalmayo em Santa Teresa para  relaxar depois de um dia de caminhada, chegaremos a Santa Teresa onde  jantaremos e dormiremos, na hora do jantar teremos uma coordenação do guia para  o dia seguinte.</p>

                    <div class="text-center my-2"><img class="img-thumbnail m-1"  src="img/tours/santateresa.jpg" alt="TRILHA INCA JUNGLE"><img class="img-thumbnail m-1"  src="img/tours/santateresa1.jpg" alt="TRILHA INCA JUNGLE"></div>
                    
                    <h2>DIA 03: SANTA TERESA - ÁGUAS CALIENTES (CAMINHADA)</h2>
                    <p>Este dia é memorável por sua  variedade de flora e fauna que veremos no decorrer do dia, como borboletas,  loros, iguanas, aves e insetos.<br>
                    Este dia sairemos às 9h45 em busca das pontes  levadiças assim como cruzar o Rio Vilcanota (Rio Sagrado dos Incas) através de  uma tirolesa onde poremos a prova nossa aventura e adrenalina, este ponto é um  dos mais emocionantes e divertidos. e também visitaremos o Inti Watana (relógio  solar) e almoçaremos na Hidroelétrica com comidas típicas da zona.</p>
                    
                    <p>Finalmente chegaremos a Águas Calientes, a  última noite da viagem, teremos um jantar e uma reunião com nossos guias para  indicar sobre o dia mais grandioso de suas vida, a Visita a Cidade Sagrada de  Machu Picchu.</p>
                    <div class="text-center my-2"><img class="img-thumbnail m-1"  src="img/tours/aguascalientes.jpg" alt="aguas calientes"><img class="img-thumbnail m-1"  src="img/tours/aguascalientes1.jpg" alt="machu picchu pueblo"></div>
                    
                    <h2>DIA 04: MACHU PICCHU FULL DAY</h2>
                    <p>Depois do café da manhã, começaremos  a caminhada rumo ao sítio arqueológico de Machu Picchu uma das Maravilhas do  Mundo Moderno, para apreciar o amanhecer de Machu Picchu, nesta caminhada nos  subiremos desde 1980 m.a.n.m até a chegada em 2450 m.a.n.m. A visita guiada por  um Guia Oficial em Inglês ou Espanhol terá duas horas de duração, e em seguida,  terão tempo livre para tirar fotos, e caminhar por sua conta, meditar, e entre  outros, neste mesmo dia você estará retornando ao Cusco, tomaremos o trem de  Águas Calientes a Ollantaytambo, onde nosso van ou bus estará aguardando para  levá-los até Cusco chegando a as 21h45.</p>

                    <div class="text-center my-2"><img class="img-thumbnail m-1"  src="img/tours/machupicchutravel.jpg" alt="machu picchu"><img class="img-thumbnail m-1"  src="img/tours/ollantaytambo.jpg" alt="TRILHA INCA JUNGLE"></div>
    
                    </div>
                    <div>
                
                      <div class="prices">
                      
                        <ul class="nav nav-tabs justify-content-center">
                          <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#grupal">SERVIÇO GRUPAL</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#privado">SERVIÇO PRIVADO</a>
                          </li>
                        </ul>

                        <div class="tab-content">
                          <div id="grupal" class="container tab-pane active"><br>

                              <table class="table table-sm table-bordered table-striped shadow-sm text-center">

                                <thead>
                                  <tr>
                                    <th colspan="5"><?=$title_tour?></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>SERVICO REGULAR:</td>
                                    <td>01 pessoa</td>
                                    <td>02 pessoa</td>
                                    <td>03 pessoa</td>
                                    <td>04 pessoa</td>
                                  </tr>
                                  <tr>
                                    <td>ADULTO :</td>
                                    <td>US $ 480</td>
                                    <td>US $ 460</td>
                                    <td>US $ 450</td>
                                    <td>US $ 400</td>
                                  </tr>
                                  <tr>
                                    <td>ESTUDANTES :</td>
                                    <td>US $ 460</td>
                                    <td>US $ 440</td>
                                    <td>US $ 420</td>
                                    <td>US $ 380</td>
                                  </tr>
                                </tbody>
                                   
                                </table>
                                <ul class="termin listok listab">
                                  <li>Serviço regular está formado por pessoas de diferentes nacionalidades, onde participarão a Trilha Salkantay 5 dias e 4 noites, para os quais o guia será no idioma espanhol e inglês.</li>
                                    <li>Na Trilha salkantay, está incluído uma noite do hotel na ultima noite de pernoite no povoado de Aguas Calientes, numa acomodação Individual, Duplo, Casal ou Triplo. O hotel que está incluído no pacote é Hotel Seven Machupicchu.</li>
                                    <li>No caso voce deseja melhorar a categoria do hotel, voce pode solicitar-nos na hora de contato, para nos enviar as opções dos hotéis e cotação.</li>
                                </ul>
                                
                          </div>
                          <div id="privado" class="container tab-pane fade"><br>

                            <table class="table table-sm table-bordered table-striped shadow-sm text-center">

                                <thead>
                                  <tr>
                                    <th colspan="7"><?=$title_tour?></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>SERVICO PRIVADO:​</td>
                                    <td>02 pessoas​</td>
                                    <td>03 pessoas​</td>
                                    <td>04 pessoas​</td>
                                    <td>05 pessoas​</td>
                                    <td>06 pessoas​</td>
                                    <td>07 pessoas a mais​</td>
                                  </tr>
                                  <tr>
                                    <td>ADULTOS</td>
                                    <td>$ 680</td>
                                    <td>$ 660</td>
                                    <td>$ 640</td>
                                    <td>$ 610</td>
                                    <td>$ 580</td>
                                    <td>$ 450</td>
                                  </tr>
                                  <tr>
                                    <td>ESTUDANTES</td>
                                    <td>$ 660</td>
                                    <td>$ 640</td>
                                    <td>$ 620</td>
                                    <td>$ 590</td>
                                    <td>$ 560</td>
                                    <td>$ 430</td>
                                  </tr>
                                </tbody>

                                </table>
                                <ul class="termin listok listab">
                                  <li>O serviço privado está considerado um serviço personalizado, onde o grupo estará formado apenas das pessoas que voce deseja como: familiares, amigos, acompanhantes, etc. Ao mesmo tempo, o serviço será mais confortável no equipamentos, flexível no horario da saída, os cavalos levarão suas coisas até 7 quilos, isolante inflável, saco de dormir, o guia será um só idioma, a agência vai providenciar uma camiseta da Trilha Salkantay para cada um e a comida será variada, com opção de comida vegetariano ou glúten.</li>
                                  <li>Na Trilha Salkantay inclui um pernoite num hotel para ultima noite de pernoite no povoado de Aguas Calientes, numa acomodação Duplo, Casal ou Triplo. O hotel que está incluído no pacote é Hotel Seven Machupicchu.</li>
                                  <li>No caso voce deseja melhorar a categoria do hotel, voce pode solicitar-nos na hora de contato, para nos enviar as opções dos hotéis e cotação.</li>
                                  <li>Nossos guias são profissionais, com autorização para a trilha salkantay, para os quais portarão um cartão profissional de identificao no percurso da trilha salkantay e tambem são autorizados pelos órgãos competentes da área protegida pelo SERNANP e tambem por Ministerio de Cultura Cusco..</li>
                                  <li>O grupo mínimo para abrir a Trilha Salkantay está considerado a partir de 2 pessoas a mais, de acordo na tabela acima.</li>
                                  <li>A saída a Trilha Salkantay 4 dias e 3 noites, podemos programar qualquer dia do ano, a partir do mes de Marco ate Janeiro.</li>
                                </ul>

                          </div>
                        </div>
                      </div>

                    </div>
                      <div>
                        <div class="d-block d-sm-flex">
                          <div class="col-12 col-sm-6 p-1 listab border p-2">
                              <h3>O QUE INCLUI :</h3>
                              <ul class="listok">
                                  <li>Transporte       turístico Cusco-Puerto Malaga&nbsp;</li>
                                  <li>Bicicletas com       suspensão dianteira</li>
                                  <li>Alimentação 3 almoços, 3 cafés da manhã e 3 jantares</li>
                                  <li>3 noites de       hospedagem</li>
                                  <li>Tickets de entrada em Machu Picchu</li>
                                  <li>Guia Oficial (Espanhol e Inglês)</li>
                                  <li>Trem de retorno (Aguas Calientes-</li>
                                  <li>Ollantaytambo)</li>
                                  <li>Maleta de       primeiros socorros</li>
                                  <li>Translado de Ollantaytambo - Cusco&nbsp;<br>
                                  </li>
                              </ul>
                          </div>
                          <div class="col-12 col-sm-6 p-1 listab border p-2">
                              <h3>O QUE NAO INCLUI :​</h3>
                              <ul class="listnot">
                                    <li>Café da manhã no primeiro dia.</li>
                                    <li>Ticket de bus       Águas Calientes - Machu Picchu (opcional)</li>
                                    <li>Entrada nos Banhos Termais (10 soles)<br>
                                    </li>
                                    <li>Gorjetas</li>
                                    <li>Serviços Extras<br>
                                    </li>
                                  
                              </ul>
                          </div>
                        </div>
                        </div>

                    <div>
                      <div class="d-block d-sm-flex">
                          <div class="col-12 col-sm-6 p-1 listab border p-2">
                              <h3>RECOMENDAÇÕES :</h3>
                              <ul class="listot">
                                
                                  <li>Uma mochila       pequena</li>
                                  <li>Roupas adequadas para os banhos termais</li>
                                  <li>Roupas adequadas       para caminhar&nbsp;</li>
                                  <li>Calça e bermuda</li>
                                  <li>Máquina fotográfica, filmes e baterias (as pilhas são consumidas       mais rapidamente sob condições frias)&nbsp;</li>
                                  <li>Chapéu ou bonés para proteger contra o sol, chuva ou frio&nbsp;</li>
                                  <li>Bloqueador Solar e       Repelente&nbsp;</li>
                                  <li>Lanterna</li>
                                  <li>Poncho para chuva</li>
                                  <li>Snacks: biscoitos,       barras energéticas, chocolates, etc.&nbsp;</li>
                                  <li>Garrafa de água e comprimidos de purificação (Micropur)</li>
                                  <li>Passaporte Original&nbsp;</li>
                                  <li> Dinheiro Extra<br>
                                  </li>
                                
                              </ul>
                          </div>
                          <div class="col-12 col-sm-6 p-1 listab border p-2">
                              <h3>SERVIÇOS OPCIONAIS :</h3>
                              <ul class="listot">
                                    <li>Uma noite hotel em Àguas Calientes pode ser reservado com custo       adicional, dependendo do hotel que você escolher.&nbsp;</li>
                                    <li>Se você deseja visitar Machu picchu novamente no dia seguinte, é o       custo extra bilhete.&nbsp;</li>
                                    <li>Ferroviário Vistadome serviço (primeira classe) ao  invés de (Expeditions trem turístico), o custo è adicional</li>
                                  
                              </ul>
                          </div>
                      </div>
                   </div>
                   <div>
                      <?php include('includes/infgenerais.php') ?>
                   </div>
                  <div>
                      <?php include('includes/condicoesgerais.php') ?>
                   </div>
                    <div>
                      <?php include('includes/metodospagamento.php') ?>
                   </div>
                   <div>
                      <?php include('includes/bookingtours.php') ?>    
                   </div>

              </div>
          </div>
        </div>
        <div class="col-12 col-sm-3">
          <?php include('includes/aside.php') ?>
        </div>
    </div>
  </section>


  <section class="mt-2 bot-page">
        <?php include('includes/footer.php') ?>
  </section>

</div>
</div>
  <script src="https://code.jquery.com/jquery-2.2.1.min.js" ></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>
  <script src="js/validator.js"></script>
  <script src="js/tours.js"></script>

  </body>
</html>