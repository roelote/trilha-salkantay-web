   

<?php 

$r1="";
$tipo1="1";//trilha
$tipo2="2";//pacote

if($final == $r1."/"){$directory="img/sliders/home";$title="TRILHA INCA JUNGLE MACHU PICCHU 4 DIAS";}
if($final == $r1."/trilhaincajungle.php"){$directory="img/sliders/incajungle";$title="TRILHA INCA JUNGLE MACHU PICCHU 4 DIAS";$pprice="470";$tipo=$tipo1;}
if($final == $r1."/trilhaincacurta.php"){$directory="img/sliders/shortincatrail";$title="TRILHA INCA CURTA 2 DIAS";$pprice="420";$tipo=$tipo1;}
if($final == $r1."/trilhasalkantay.php"){$directory="img/sliders/salkantay";$title="SALKANTAY MACHU PICCHU 5 DIAS";$pprice="380";$tipo=$tipo1;}
if($final == $r1."/trilhasalkantaymachupicchu.php"){$directory="img/sliders/salkantay";$title="SALKANTAY MACHU PICCHU 4 DIAS";$pprice="380";$tipo=$tipo1;}
if($final == $r1."/cuscopunoalternativo.php"){$directory="img/sliders/packagecuscopuno";$title="PACOTE CUSCO PUNO 7 DIAS";$pprice="735";$tipo=$tipo2;}
//if($final == "/laresmachupicchu.php"){$directory="img/sliders/larestrek";$title="LARES TREK TO MACHU PICCHU";}
//if($final == "/huchuyqosqo.php"){$directory="img/sliders/huchuyqosqo";$title="HUCHUY QOSQO";}
if($final == $r1."/cuscoclassicotradicional.php"){$directory="img/sliders/traditional";$title="TOURS TRADICIONAL 4 DIAS";$pprice="465";$tipo=$tipo2;}
if($final == $r1."/cuscoclassicopernoite.php"){$directory="img/sliders/overnight";$title="CUSCO CLASSICO PERNOITE 4 DIAS";$pprice="455";$tipo=$tipo2;}
if($final == $r1."/cuscoclassicoopcional.php"){$directory="img/sliders/optional";$title="CUSCO CLASSICO OPCIONAL 3 DIAS";$pprice="360";$tipo=$tipo2;}
if($final == $r1."/cuscoclassicomoderno.php"){$directory="img/sliders/modern";$title="CUSCO CLASSIC0 MODERN0 3 DIAS";$pprice="375";$tipo=$tipo2;}
if($final == $r1."/cuscoclassicimperial.php"){$directory="img/sliders/imperial";$title="CUSCO CLASSICO IMPERIAL 6 DIAS";$pprice="565";$tipo=$tipo2;}
if($final == $r1."/cuscoclassicocultural.php"){$directory="img/sliders/cultural";$title="CUSCO CLASSICO CULTURAL 2 DIAS";$pprice="350";$tipo=$tipo2;}
if($final == $r1."/cuscoclassicoconvencional.php"){$directory="img/sliders/conventional";$title="CUSCO CLASSICO CONVENCIONAL 5 DIAS";$pprice="510";$tipo=$tipo2;}
if($final == $r1."/cuscoclassicarqueologico.php"){$directory="img/sliders/archaeological";$title="CUSCO CLASSICO ARQUEOLOGICO 5 DIAS";$pprice="410";$tipo=$tipo2;}
if($final == $r1."/cuscoclassicomachupicchu.php"){$directory="img/sliders/machupicchu";$title="CUSCO CLASSICO MACHU PICCHU 1 DIA";}
if($final == $r1."/trilhaincaclassica.php"){$directory="img/sliders/classicincatrail";$title="TRILHA INCA CLÀSSICA 4 DIAS";$pprice="550";$tipo=$tipo1;}
if($final == $r1."/trilhachoquequirao.php"){$directory="img/sliders/choquequirao";$title="TRILHA CHOQUEQUIRAO 5 DIAS";$pprice="400";$tipo=$tipo1;}
if($final == $r1."/lagotiticaca.php"){$directory="img/sliders/lagotiticaca";$title="LAGO TITICACA - PUNO";}
if($final == $r1."/cityarqueologico.php"){$directory="img/sliders/citytour";$title="CITY TOUR ARQUEOLOGICO";}
if($final == $r1."/vallesagrado.php"){$directory="img/sliders/valle";$title="VALLE SAGRADO DOS INCAS";$pprice="45";$tipo=$tipo1;}
if($final == $r1."/marasmoraysalineras.php"){$directory="img/sliders/marasmoray";$title="MARAS MORAY SALINERAS";}
if($final == $r1."/rafting.php"){$directory="img/sliders/rafting";$title="RAFTING NO RIO APURIMAC";}
if($final == $r1."/cabalgata.php"){$directory="img/sliders/cabalgata";$title="TOUR A CAVALO";}
if($final == $r1."/trilhaantisuyo.php"){$directory="img/sliders/trilhaantisuyo1";$title="TRILHA ANTISUYO 1 DIA";$pprice="55";$tipo=$tipo1;}
if($final == $r1."/trilhaantisuyomachupicchu.php"){$directory="img/sliders/trilhaantisuyo2";$title="TRILHA ANTISUYO MACHU PICCHU 2 DIAS";$pprice="335";$tipo=$tipo1;}
if($final == $r1."/trilhaantisuyopiuraymachupicchu.php"){$directory="img/sliders/trilhaantisuyo3";$title="TRILHA ANTISUYO MACHU PICCHU 3 DIAS";$pprice="380";$tipo=$tipo1;}
if($final == $r1."/cuscopunoarequipa9dias.php"){$directory="img/sliders/cuscopunoarequipa9dias";$title="PACOTE: CUSCO - PUNO - AREQUIPA 9 DIAS";}
if($final == $r1."/pacotetodoperu.php"){$directory="img/sliders/pacotetodoperu";$title="PACOTE TODO PERU 9 DIAS";}
if($final == $r1."/pacotecuscopunoalternativo.php"){$directory="img/sliders/pacotecuscopunoalternativo";$title="PACOTE CUSCO - PUNO ALTERNATIVO 7 DIAS";}
if($final == $r1."/pacotecuscoclassico.php"){$directory="img/sliders/pacotecuscoclassico";$title="PACOTE CUSCO CLASSICO 5 DIAS";}
//pacotes
if($final == $r1."/machu-picchu.php"){$directory="img/sliders/machupicchu";$title="PACOTE CUSCO CLASSICO 5 DIAS";}
if($final == $r1."/trilhainca.php"){$directory="img/sliders/machupicchu";$title="PACOTE CUSCO CLASSICO 5 DIAS";}
if($final == $r1."/trilhaincaantisuyo.php"){$directory="img/sliders/trilhaantisuyo1";$title="PACOTE CUSCO CLASSICO 5 DIAS";}
if($final == $r1."/salkantay.php"){$directory="img/sliders/salkantay";$title="PACOTE CUSCO CLASSICO 5 DIAS";}
if($final == $r1."/inca-jungle.php"){$directory="img/sliders/incajungle";$title="PACOTE CUSCO CLASSICO 5 DIAS";}
if($final == $r1."/alternativas.php"){$directory="img/sliders/salkantay";$title="PACOTE CUSCO CLASSICO 5 DIAS";}

if($final == $r1."/quemsomos.php"){$directory="img/sliders/shortincatrail";}
if($final == $r1."/galeria.php"){$directory="img/sliders/shortincatrail";}
if($final == $r1."/contato.php"){$directory="img/sliders/shortincatrail";}
if($final == $r1."/condicoes-gerais.php"){$directory="img/sliders/shortincatrail";}
if($final == $r1."/metodos-pagamento.php"){$directory="img/sliders/shortincatrail";}
if($final == $r1."/reservas.php"){$directory="img/sliders/shortincatrail";}

if($final == $r1."/pacotesperu.php"){$directory="img/sliders/lima-cusco-puno-9d8n";$title="PACOTES TURÍSTICOS EM TODO O PERU: CUSCO, PUNO, AREQUIPA, LIMA";}
if($final == $r1."/lima-cusco-puno.php"){$directory="img/sliders/lima-cusco-puno";$title="PACOTE LIMA - CUSCO E PUNO 11 DIAS";$pprice="1045";$tipo=$tipo2;}
if($final == $r1."/lima-cusco-puno-9d8n.php"){$directory="img/sliders/lima-cusco-puno-9d8n";$title="LIMA - CUSCO E PUNO 9 DIAS";$pprice="950";$tipo=$tipo2;}
if($final == $r1."/cusco-puno-arequipa-lima.php"){$directory="img/sliders/cusco-puno-arequipa-lima";$title="PACOTE: CUSCO - PUNO – AREQUIPA – LIMA 12 DIAS";$pprice="1175";$tipo=$tipo2;}
if($final == $r1."/pacotetudoperu.php"){$directory="img/sliders/pacotetudoperu";$title="LIMA - PARACAS - NAZCA - AREQUIPA - PUNO - CUSCO - MACHU PICCHU 14 DIAS";$pprice="1540";$tipo=$tipo2;}

 
if($directory != ""){

echo ' <div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-ride="carousel">';
                  $id=0;

                    if ($final != "wNCTRAVEL" and $final != "wNCTRAVEL"){

                      $dirint = dir($directory);

                      echo '<ol class="carousel-indicators">';
                      echo '          
                      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>';  
                      echo '</ol>';
                      echo '<div class="carousel-inner" role="listbox">';
                      while (($archivo = $dirint->read()) !== false)
                      {
                        if ($archivo == "." || $archivo == ".." || $archivo == "Thumbs.db"){
                        }
                        else{
                          if($id == 0)
                          {

                            echo "<div class='carousel-item active' style='background: url($directory/$archivo)' ></div>";

                          }
                          else
                          {
                           echo "<div class='carousel-item' style='background: url($directory/$archivo)' ></div>";
                          }
                          $id=$id+1;
                          }
                      }
                      $dirint->close();
                    }
                  echo'                               
                 </div>
            </div>';
}



?>
