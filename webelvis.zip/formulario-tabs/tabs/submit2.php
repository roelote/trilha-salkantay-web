<?php

if($_POST)
{
	$fname = $_POST['fname2'];
	$lname = $_POST['lname2'];
	$email = $_POST['email2'];
	$phno = $_POST['phno2'];




$from = $_POST['email2'];
$subject = 'Booking in English Cusco';
$message = 

'Nombre: ' . $fname . 
"\n". 'apellidos: ' . $lname.
"\n". 'Email: ' . $email. 
"\n". 'Nro Pax:' . $lname. 
"\n". 'Message:' . $phno;

$headers = "From: ". $from . "\n";
mail ('jroelx@gmail.com', $subject, $message, $headers);



	?>
    
    <table border="0">
    
    <tr>
    <td colspan="2">Succedd !!! Lima</td>
    </tr>
    
    <tr>
    <td colspan="2"><hr /></td>
    </tr>
    
    <tr>
    <td>First Name</td>
    <td><?php echo $fname ?></td>
    </tr>
    
    <tr>
    <td>Last Name</td>
    <td><?php echo $lname ?></td>
    </tr>
    
    <tr>
    <td>Your eMail</td>
    <td><?php echo $email; ?></td>
    </tr>
    
    <tr>
    <td>Contact No</td>
    <td><?php echo $phno; ?></td>
    </tr>
    
    </table>
    <?php
	
}

?>