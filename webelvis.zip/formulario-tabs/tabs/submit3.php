<?php

if($_POST)
{
	$fname = $_POST['fname3'];
	$lname = $_POST['lname3'];
	$email = $_POST['email3'];
	$phno = $_POST['phno3'];




$from = $_POST['email3'];
$subject = 'Booking in English Cusco';
$message = 

'Nombre: ' . $fname . 
"\n". 'apellidos: ' . $lname.
"\n". 'Email: ' . $email. 
"\n". 'Nro Pax:' . $lname. 
"\n". 'Message:' . $phno;

$headers = "From: ". $from . "\n";
mail ('jroelx@gmail.com', $subject, $message, $headers);



	?>
    
    <table border="0">
    
    <tr>
    <td colspan="2">Succedd !!! Arequipa</td>
    </tr>
    
    <tr>
    <td colspan="2"><hr /></td>
    </tr>
    
    <tr>
    <td>First Name</td>
    <td><?php echo $fname ?></td>
    </tr>
    
    <tr>
    <td>Last Name</td>
    <td><?php echo $lname ?></td>
    </tr>
    
    <tr>
    <td>Your eMail</td>
    <td><?php echo $email; ?></td>
    </tr>
    
    <tr>
    <td>Contact No</td>
    <td><?php echo $phno; ?></td>
    </tr>
    
    </table>
    <?php
	
}

?>


