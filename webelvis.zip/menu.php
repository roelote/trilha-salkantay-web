<div class="colormenu">
<div class="logo">
	<img class="" src="/img/logo-freewalks.png" alt="">
</div><div class="idiomas-header">
       
        <span class="es"><a href="/es/"><img src="../img/es.png" alt="ingles"></a></span>
      </div>
			<div id='cssmenu' class="container-max">
          <ul>
             <li><a href='/'>Home</a></li>
             <li><a href='/lima/'>Lima</a>
				<ul class='lista-submenu-nav'>
				<li><a href='/lima/free-walking-tour-lima-10-30-am'>Free Historical Centre Tour Lima at 10am, starts in Mrflres</a></li>
				<li><a href='/lima/free-walking-tour-lima-11-30-am'>Free Historical Centre Tour Lima at 11am, starts in Lima </a></li>
				<li><a href='/lima/free-walking-tour-lima-afternoon'>Free Historical Centre Tour Lima at 3pm, starts in Lima</a></li>
				<li><a href='/lima/free-walking-tour-lima-barranco'>Free Hcal. Centre Tour Lima from Barranco, starts in Lima</a></li>
			   </ul>
             </li>
             <li><a href='/miraflores/'>Miraflores</a>
				<ul class='lista-submenu-nav'>
				<li><a href='/miraflores/free-walking-tour-miraflores-4-15-pm'>Free Walking Tour at 4:15pm</a></li>
			   </ul>
             </li>
             <li><a href='/arequipa/'>Arequipa</a>
				<ul class='lista-submenu-nav'>
				<li><a href='/arequipa/free-walking-tour-arequipa-10-am'>Free Historical Centre Tour Arequipa at 10am</a></li>
				<li><a href='/arequipa/free-walking-tour-arequipa-3-pm'>Free Historical Centre Tour Arequipa at 3pm</a></li>
			   </ul>
             </li>
             <li><a href='/cusco/'>Cusco</a>
				<ul class='lista-submenu-nav'>
				<li><a href='/cusco/downtown-city-tour'>Free Historical Centre Tour Cusco at 10am</a></li>
				<li><a href='/cusco/walking-tour-plaza-armas'>Free Historical Centre Tour Cusco at 1pm</a></li>
				<li><a href='/cusco/walking-tour-historical-center'>Free Historical Centre Tour Cusco at 3.30pm</a></li>
				<li><a href='/cusco/tour-sunday'>Sunday Free Hcal. Centre Tour Cusco at 10am</a></li>
			   </ul>
             </li>
             <li><a href='/blog/'>Blog</a></li>
             <li><a href='/contact-us'>Contact us</a></li>
             <li><a href='/booking/'>Booking</a></li>

			 
          </ul>
 </div>
        

 </div>
