<div  id="cuadro-reservas">
    <section>
        <hgroup class="boooking">
           <span style="color: red;">This Tour is OFF</span>
        </hgroup>

<div id="container">
  <div id="form" class="result">

  <?php
function dameURL(){
$url="http://".$_SERVER['HTTP_HOST'].":".$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];
return $url;
}
$urlweb=dameURL();

$resultado = substr($urlweb, 39);
$nombretour=str_replace("-"," ",$resultado);
$nombretour1=str_replace("/","-",$nombretour);

?>
      <form method="" id="">

<!--                     <input type="hidden" name="nombretour" value=<?=$resultado?> />  -->
        
                   <div class="form-group top15 padding10">
                      <input type="text" name="fname" id="lname" placeholder="Your Name:" required data-error="Please enter your name" />
                    </div>
                    <div class="form-group padding10">
                      <input type="email" name="email" id="email" placeholder="Your Email" required data-error="Please enter your email" />
                    </div>
                     <div class="form-group padding10">
                      <input type="email" name="email1" id="email1" placeholder="Confirm your Email" required data-error="both emails must match up" />
                    </div>
                    
                       <div class="form-group padding10">
                               
                        <input type="text" id="datepicker" name="date" placeholder="Date" />
                      </div>
                    <!-- <div class="form-group padding10">
                      <input type="text" name="lname" id="lname" placeholder="Subject:" />
                    </div> -->
                    <div class="form-group padding10">
                     <div class="controls">
                            <select class="form-control" id="lname" name="lname">
                            <option value="" disabled selected>Size of Group</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                              <option>6</option>
                              <option>7</option>
                              <option>8</option>
                              <option>9</option>
                              <option>10</option>
                            </select>
                           </div>
              </div>

                     <div class="form-group padding10">
                      <select class="form-control" name="nombretour" id="nombretour" >
                         <option value="" disabled selected>Choose your free tour departure</option>
                          <option value="miraflores-4-15pm">Free Walking Tour Miraflores at 4:15 pm</option>
                      </select>
                    </div>

                      <div class="form-group padding10">
                        <textarea class="form-control" name="phno" rows="7" placeholder="" id="comment" required data-error="Write your message"></textarea>
                      </div> 

                    <!-- <div class="centrarsend"><button type="submit">Send</button></div> -->
        </form>
    </div>
</div>
        

<style type="text/css">


input
{
  width:100%;
  height:35px;
  text-align:center;
  border:solid #cddcdc 2px;
  font-family:Verdana, Geneva, sans-serif;
  border-radius:3px;
}
button
{
  text-align:center;
  width:50%;
  height:35px;
  border:0;
  font-family:Verdana, Geneva, sans-serif;
  border-radius:3px;
  background:#00a2d1;
  color:#fff;
  font-weight:bolder;
  font-size:18px;
}
hr
{
  border:solid #cecece 1px;
}
#header
{
  width:100%;
  height:50px;
  background:#00a2d1;
  text-align:center;
}
#header label
{
  font-family:Verdana, Geneva, sans-serif;
  font-size:35px;
  color:#f9f9f9;
}
.form-control
{
  color:#00acd4;
}
a{
  color:#00a2d1;
  text-decoration:none;
}
</style>

</section>
</div>