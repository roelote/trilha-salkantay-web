<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free City Tour Cusco | Half Day City Tour Cusco | Free Walking Tour</title>
    <meta content="Want to step beyond of a regular City Tour Cusco? Then explore with us this city | Our Free Walking City Tour Cusco is a unique platform designed for Explorers who really want to experience this city on a Half Day City Tour Cusco." name="description" />
    <meta content="Free City Tour Cusco, Half day City Tour Cusco, free walking tour" name="keywords" />
    <meta content="en" name="language" />


     <!-- Bootstrap -->
       <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">

 <!--   estilos slider pekeño -->
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
<link href="../css/flag-icon.min.css" rel="stylesheet">

                <!-- favicons -->
        <link rel="apple-touch-icon" sizes="57x57" href="../favicons/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../favicons/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../favicons/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../favicons/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../favicons/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../favicons/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../favicons/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../favicons/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../favicons/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="../favicons/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="../favicons/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../favicons/favicon-16x16.png">
        <link rel="manifest" href="../favicons/manifest.json">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content="../favicons/ms-icon-144x144.png">
        <meta name="theme-color" content="#ffffff">
          <!-- end favicons -->
          <!-- open graph -->
                          <meta property="og:type" content="website">
                          <meta property="og:title" content="Free City Tour Cusco | Half Day City Tour Cusco | Free Walking Tour">
                          <meta property="og:description" content="Want to step beyond of a regular City Tour Cusco? Then explore with us this city | Our Free Walking City Tour Cusco is a unique platform designed for Explorers who really want to experience this city on a Half Day City Tour Cusco."">
                          <meta property="og:url" content="https://www.freewalkingtoursperu.com/cusco/downtown-city-tour">
                          <meta property="og:image" content="https://www.freewalkingtoursperu.com/img/free-walking-tours-cusco-2.jpg">
                          <meta property="fb:app_id" content="freewalkingtourscusco">
                              <!-- twitter -->
          <!-- end open graph -->

<script type="application/ld+json">
      {
        "@context": "http://schema.org/",
        "@type": "Review",
        "itemReviewed": {
          "@type": "Thing",
          "name": "Downtown Walking City Tour at 10:00 am"
        },
        "author": {
          "@type": "Organization",
          "name": "Cusco"
        },
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": "4.5",
          "bestRating": "5"
        },
        "publisher": {
          "@type": "Organization",
          "name": "Free Walking Tours Peru"
        }
      }
      
    </script>

    
  </head>
  <body>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>
    <div id="fb-root"></div>

    <div class="container">
      <header class="cabecera">
 <?php include('../menu.php');?>
          <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-walking-tour-peru-xs.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-walking-tour-xs.png">
        <img src="../img/lima-walking-tour.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>

      </header>

 
    <div class="cuerpo">

      <section class="container izquierda">
     
        <section class="cuadro-texto cuadro-contenedor">

          <h1>Free City Tour Cusco at 10am | Half Day City Tour Cusco</h1>


          <div class="wecolmetour">
              <p>Discover The Magic of Cusco city centre on foot, our genuine modern-day Free City Tour Cusco is unmissable & unforgettable, our Free Walking Tour Cusco puts the power back in the hands of modern-day travelers where you will show your gratuity at the end of the tour in direct proportion to the tour’s quality | As you free tour with us, (Half Day City Tour by foot)you´ll have the opportunity to talk to a local friend & tour guide, local Peruvian tour guide who will show you the city more from the Peruvian side rather from a tour guide´s view point, you will also have the chance to show your viewpoint and if possible discuss with other Travelers and why not Make Friends while you explore the world, All these factors make our tour on foot a <b>MODERN</b> Free city tour.</p>
            
              <p><strong>NOTE:</strong>&nbsp;All our free city tours in Cusco (<a href="https://www.freewalkingtoursperu.com/cusco/downtown-city-tour">10am</a>&nbsp;&ndash;&nbsp;<a href="https://www.freewalkingtoursperu.com/cusco/walking-tour-plaza-armas">1pm</a>&nbsp;&ndash;&nbsp;<a href="https://www.freewalkingtoursperu.com/cusco/walking-tour-historical-center">3:30pm</a>&nbsp;&ndash;&nbsp;<a href="https://www.freewalkingtoursperu.com/cusco/tour-sunday">10am Sundays</a>) are the same or similar, so you can only take one free tour.</p>


          <h2 class="text-center">BEFORE JOINING OUR FREE TOUR YOU SHOULD KNOW:</h2>

<p><strong>Free Tour Meet up Time</strong>: 10am from Monday to Saturday &ndash; if you like a free tour on&nbsp;<a href="https://www.freewalkingtoursperu.com/cusco/tour-sunday">Sundays follow me here</a>.</p>
<p><strong>Meeting Place</strong>:&nbsp;<a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.980109,15z/data=!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">Regocijo</a>&nbsp;Plazoleta in front of Choco Museo.</p>
<p><strong>How to find our Meeting Place?&nbsp;</strong>Use as Landmark the&nbsp;<a href="https://www.google.com.pe/maps/place/Museo+del+Chocolate/@-13.5172359,-71.9804421,15z/data=!4m2!3m1!1s0x0:0x2f9797c884894ed0?sa=X&amp;ved=0ahUKEwi_r9zsmdTZAhVCT98KHW09BxcQ_BIIvwEwCg">Choco Museo</a>(we are in front of it) or The City Hall (we are in front of it), there are many Choco Museos, priorize <a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.980109,15z/data=!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">Regocijo</a>.</p>
<p><strong>Walking Tour Length</strong>: 2.5 to 3 hours.</p>
<p><strong>Our Happy Official Tour Guide wears</strong>: &nbsp;Inkan Milky Way Logo on the Yellow Vests, look for this at the Correct Meeting Place.</p>
<p><strong>To bring</strong>: Warm Cloth, Hats, sunglasses, walking shoes and a jumper.</p>
<p><strong>Price:</strong> FREE &ndash; Donation basis.</p>
<p><strong>Language</strong>: English &amp; Spanish, you choose your language.</p>

<div class="btn-reserva">
  

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#titlea-side"><button type="button" class="btn btnreserva active">Book Now</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>


<p><span style="color: #ff0000;">To Consider:</span>&nbsp;You might get confused with other people, pls show up at the correct meeting point &amp; Our free tours in Cusco are operated by Inkan Milky Way Tours Cusco, a 100% Indigenous Peruvian Co,&nbsp;<a href="https://www.facebook.com/freewalkingtourscusco/">follow us here.</a></p>



   
          </div>
          <div class="slidertours">
              <div id="demo">
                <div class="container">
                  <div class="row">
                    <div class="span12">

                      <div id="owl-demo" class="owl-carousel">
                        <div class="item"><img src="../img/free-walking-tours-cusco-1.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walking-tours-cusco-2.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walking-tours-cusco-3.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walking-tours-cusco-4.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walking-tours-cusco-1.jpg" alt="Owl Image"></div>

                      </div>
                      
                    </div>
                  </div>
                </div>
           </div>

          </div>

          <div id="verticalTab">
                <ul class="resp-tabs-list">
                <li> <span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> ITINERARY</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> INCLUSIONS</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> REMARKS & FAQ’S</li>
                </ul>
                <div class="resp-tabs-container">
                    <div>
                        <h2 class="h2-tours-detalle"> Spots we are going to visit:  </h2> 

                       <p class="texto-ciudades">Below itinerary is changeable because of many reasons: festivals, strikes, holydays, car traffics, rainy season, etc. if you are a Blogger, Top rated TripAdvisor Criticizer, Lonely Planet Agent or just a highly demanding customer, then we ask you kindly to check our policies to avoid misunderstandings; Nonetheless we will do our best so that you can have a great experience with us.</p>

                     
                   <ul style="list-style-type: none" class="bi-ciudades">
   <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Join us at <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.9822977,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">Regocijo plazoleta at 10am</a>, just 50 meters AWAY from the Plaza de Armas, we are in front of the Choco Museo, look for Inkan Milky Way Cusco logo on the Yellow Vests, <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.9822977,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">See our Google Map of Inkan Free Tours by Foot Cusco</a>.</li>
   <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>San Francisco Plaza & Saint Claire Arch & San Pedro Church (outdoor explanation).</li>
   <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>San Pedro Market, designed by Alexander Gustave Eiffel in 1928, learn about Local Life and culture of Indigenous people.</li>
   <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Plaza de Armas (Main Square) & Acclla Wasi Temple (outdoor explanation).</li>
   <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Palace of Pachaquteq (indoor from Mon to Fri), the 9th emperor & Palace of Inca Tupac Yupanqui (outdoor explanation), the 10th emperor.</li>
   <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Peru is the Land of the Inkas and The Land of the best coffees as well, learn about best Peruvian Kopi Luwak.</li>
   <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Remember this is free with only a tip at the end so don’t expect bells and whistles¡</li>


                  <!--   <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Free local fruit tasting</li> -->


                   </ul>

                    </div>

                    <div>
                      <div class="imagesit">
                        <img src="../img/ico-cusco-10am/inca-culture-free-walks-cusco.png" alt="inca-culture-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/best-picture-free-walks-cusco.png" alt="best-picture-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/accomodation-tips-free-walks-cusco.png" alt="accomodation-tips-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/history-free-walks-cusco.png" alt="history-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/catholicism-free-walks-cusco.png" alt="catholicism-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/geo-orientation-free-walks-cusco.png" alt="geo-orientation-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/inquires-free-walks-cusco.png" alt="inquires-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/andes-explation-free-walks-cusco.png" alt="andes-explation-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/maps-free-walks-cusco.png" alt="maps-free-walks-cusco">
                      <!--   <img src="../img/ico-cusco-10am/alpaca-watching-free-walks-cusco.png" alt="alpaca-watching-free-walks-cusco"> -->
                        <img src="../img/ico-cusco-10am/inca-arquitecture-free-walks-cusco.png" alt="inca-arquitecture-free-walks-cusco">
                       <!--  <img src="../img/ico-cusco-10am/llamas-free-walks-cusco.png" alt="llamas-free-walks-cusco"> -->
                        <img src="../img/ico-cusco-10am/travel-tips-free-walks-cusco.png" alt="travel-tips-free-walks-cusco">
                       <!--  <img src="../img/ico-cusco-10am/loca-fruit-samples-free-walks-cusco.png" alt="loca-fruit-samples-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/local-fruits-samples-free-walks-cusco.png" alt="local-fruits-samples-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/local-fruits-free-walks-cusco-1.png" alt="local-fruits-free-walks-cusco-1"> -->
                      </div>
                    </div>

                    <div>
                    <ul style="list-style-type: none">

                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Where is our Meeting Point in Cusco?(<a href="#" class="alternar-respuesta">View</a>)</p> 
                      <p class="respuesta" style="display:none">Our Meeting Point is Regocijo plazoleta, just 50 meters AWAY from the Plaza de Armas, we are in front of the Choco Museo, <a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.980109,15z/data=%214m5%213m4%211s0x0:0x49be8bcaa264818d%218m2%213d-13.5171337%214d-71.980109">Google our Cusco Meeting Point Map here.</a><br>
                      <span style="color: #ff0000;">Don’t get confused in the plaza de armas or plaza espinar, we don’t gather our customers in those places.</span></p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>How to recognize our Tour Guides at the Meeting Point in Cusco?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">Look for <span style="background-color: #ffff00;">Inkan Milky Way logo</span> on the Yellow Vests at the Correct Meeting Point, don&rsquo;t get confused with other uniforms</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Where does the free tour end up in Cusco?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">All our free tours end up near the Plaza de Armas at San Agustin Street 269 (just 3 min away from plaza de armas).</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>What’s an appropriate amount of tip for our free tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">This is our Philosophy for our Free Tour: <span style="color: #008080;">Pay what you think the tour was worth&iexcl;</span>, our free tours are from good to great quality, in simple terms, they are decent tours and decent tours should be rewarded Generously, <span style="color: #ff0000;">Not with coins such as 2 soles or 5 soles.</span><br>
                      Let us mean ourselves clear: <span style="color: #008080;">Pay What It's Worth is Not Pay what you can or what you like&rdquo;</span>. In New York, some free tour companies have the philosophy of &ldquo;Pay what you like&rdquo;, and this really good because New Yorkers are big Tippers however we are in South America where there are many tourists who don&rsquo;t even have the Tipping culture.<br>
                      Apart from this consider that your tour guide relies entirely on your tips, since no one of them are funded by NGO´s or the government. Tips are also shared among the whole team.
                      Most tourists tip between twenty to thirty soles, this is subject to change according to the quality of the tour.<br>
                      Thanks</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Things to be brought:(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">
                      - Always Warm Clothes (if it is rainy or cold, don’t blame your tour guide).<br>
                      - Sun Block Lotions.<br>
                      - Sun Glasses.<br>
                      - Walking Shoes, NO flip flops in Cusco city.<br>
                      - BIG SMILE and WILLINGNESS TO WALK.<br></p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Available Languages in Cusco:(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">
                      - All our free tours in Cusco are in English.<br>
                      - Nuestro free tour a las 10am (todos los días, incluso domingos) es 100% en Español.<br>
                      - Si no puede realizar nuestro free tour a las 10am, Ud. siempre está invitado a realizar los free tours a la 1pm o 3:30pm (De lunes a sábado), sin embargo los guiados son en Ingles.<br>
                      <span style="color: #ff0000;">Nota:</span> Siempre podemos darles guiados en español, pero nuestra compañía se caracteriza por la calidad de servicio de los guías y para eso ofrecemos guías profesionales, es decir personas que han estudiado para ser guía de turistas, no simples improvisadores o guías falsos sin carnet o autorización del gobierno.</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>When is this happening?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">Free Tour Meet up times for Cusco:<br>
                      From Monday to Saturday at: 10am, 1pm and 3:30pm.<br>
                      Every Sunday at 10am only (there is no other meet up time).</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Do the free tours in Cusco (10am, 1pm or 3:30pm) have different itinerary?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">No, all our free tours in Cusco have the same or very similar itinerary, so you can only take one.</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Can we leave the free tour because we have other scheduled tours?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">You can always leave our free tour, if you have other tours or activities, however Don’t forget to tip your tour guide, Don’t escape, Don’t run away, Don’t walk away, Don’t ignore your tour guide, Don’t pretend that you don’t know our walks are tip based, Don’t pretend that you forgot to bring some tip.<br>
                      Thanks</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>What is the duration of our free tours in Cusco?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">All our Cusco Walking Tours last about 2.5 to 3 hours, approximately 1.6 km – 1 mi. in distance, therefore we kindly ask our tourists to HAVE that AVAIABLE TIME.</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Minimum walkers required to run the tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">05 tourists, otherwise will be cancelled, for more info go to: <a href="https://www.freewalkingtoursperu.com/terms-conditions">our policies.</a></p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Maximum walkers allowed per group?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">20 tourists either for English or Spanish, for more info go to: <a href="https://www.freewalkingtoursperu.com/terms-conditions">our policies.</a>
                      From time to time we have large groups and one tour guide to manage the whole group, please don’t blame on your guide or the team, simply because most attendees don’t book in advance so cannot take a decision beforehand.</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We are a group of 11 or more. Can we make a reservation online?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">Groups or Families of 11 or more are more than welcome to <a href="https://www.freewalkingtoursperu.com/contact-us">contact us</a> before reserving and according to our available tour guides and available spot in our free tour whether we will accept or reject your participation in our free tours. From experience we know that large groups have the tendency to NOT pay attention to the Tour Guide´s explanation which is so disrespectful for both the guide and other attendees.<br>
                      However if you happen to forget to book your large group, you can always show up at the meeting point, we will take care of you, just don’t expect the best of the best, remember it is free tour, if you want the best from the best look for a private tour. </p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We are a group of 11 or more. Can we have a private free tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">NO, our free tour service is a group service, you will join other attendees.<br>
                      Even if you are 20 people, we still say no, because from experience we know that big groups of friends or mates Do Not pay attention to our Tour Guide’s explanation.
                      Because of this reason, we advise you to take a Private tour (pre-paid) however if you want to take our free tour, you must <a href="https://www.freewalkingtoursperu.com/contact-us">contact us</a> in advance so that you can join our GROUP service (Not private).</p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Can our free tours ever get cancelled because of weather, protests or festivities in Cusco?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">- When it comes to Protests we might cancel our free tour, this can happen without a previous notification, so we ask for your understanding in advance.<br>
                      - If there are Festivities, we might cancel also.<br>
                      - If rainy, the tour itinerary may be changed but the show must go on! Unless it is too rainy. </p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We use crutches, can we participate in your free tours?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">Yes, you can as long as you are capable to walk and stand on your feet for some minutes while your guide explains about some historical spots. </p></li>
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We use wheelchair, can we participate in your free tours?(<a href="#" class="alternar-respuesta">View</a>)</p>
                      <p class="respuesta" style="display:none">Unfortunately the answer is NO, because most streets in Peru are not yet designed for Wheelchair users, this issue is out from our hands to solve. We kindly encourage you to take a private tour instead, make sure you have a person that can help you. </p></li>

                    <a href="#" class="alternar-todo"id="alternar-todo">Show and hide all answers</a>

                    </ul>
                    </div>
                </div>
            </div>


          

         </section>

        

      </section>

      <aside class="derecha" id="derecha">
        <div class="redes-movil mt-3 visible-xs">
        <section class="redes-s" style="width: 100%;font-size: 12px; border-radius: 5px;">
  <div class="row text-center mt-2 mb-3">
  <span class="tex-center">
  <h4 id="titlea-side">Make a wise decision in Cusco, see our awesome 1.8k+ reviews at:</h4>

   <a href="https://web.facebook.com/freewalkingtourscusco/"><i class="fab fa-facebook"></i></a>
   <a href="https://www.youtube.com/channel/UCjCwOb8Uayzl2pCLsntighg"><i class="fab fa-youtube-square"></i></a>
   <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html"><img src="/img/trip-advisor.jpg" class="mt-1" alt="" width="38" height="35"></a>
   <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953"><img src="/img/google-b.png" alt="" style="" width="40" height="38"></a>
   <a href="https://plus.google.com/+Inkanmilkyway-freewalkingtourscusco"><i class="fab fa-google-plus-square"></i></a>
</span>
  </div>
</section>
        </div>
      <?php include('../cuadro-reservas-cusco.php');?>

       <div class="mapadetalle mb-2">
        <h2 class="hidden-xs"> <span class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span> Click The Map to See</h2>
        <div class="centrarmapa"><img id="myImg" src="../img/maps-inkan-mily-way-en.jpg" alt="Free Walking Tour Cusco 10:00 am" width="300" height="150"></div>

        <!-- The Modal -->
        <div id="myModal" class="modal">
          <span class="close">×</span>
          <img class="modal-content" id="img01" alt="mapa ubicacion">
          <div id="caption"></div>
        </div>
        </div>

        <div class="chalecoc text-center mt-2 mb-3">
          <img src="../img/chaleco-img.png" alt="chalecos fwt" width="150px" >
        </div>

      </aside>

<section class="redes-s hidden-xs" style="float: left;
width: 100%;
border: 2px solid #c8cbc4;
background-color: #ede58a;font-size: 1.7em;">
  <div class="row text-center mt-2 mb-3">
  <span class="tex-center">
  Make a wise decision in Cusco, see our awesome 1.8k+ reviews at:

   <a href="https://web.facebook.com/freewalkingtourscusco/"><i class="fab fa-facebook"></i></a>
   <a href="https://www.youtube.com/channel/UCjCwOb8Uayzl2pCLsntighg"><i class="fab fa-youtube-square"></i></a>
   <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html"><img src="/img/trip-advisor.jpg" class="mt-1" alt="" width="38" height="35"></a>
   <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953"><img src="/img/google-b.png" alt="" style="" width="40" height="38"></a>
   <a href="https://plus.google.com/+Inkanmilkyway-freewalkingtourscusco"><i class="fab fa-google-plus-square"></i></a>
</span>
  </div>
</section>

     <div class="maps-c mb-5">
      
       <div class="contenedormap">
        <h3 class="text-center mt-1" style="float: left;width: 100%;font-size: 1.6em;">Meeting Point Map for our Cusco Free Tours – Google maps</h3>
         <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15517.202489400717!2d-71.980109!3d-13.5171337!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x49be8bcaa264818d!2sInkan+Milky+Way+Cusco%2C+Free+Walking+Tour!5e0!3m2!1ses!2spe!4v1520117347022" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
       </div>
     </div>

         <div class="carousel-reviews broun-block hidden-xs">
 <h3 class="text-center mt-3" style="float: left;width: 100%;font-size: 1.6em;">What our customers are saying about us¡</h3>     
    <div class="container">
        <div class="">
            <div id="carousel-reviews1" class="carousel slide" data-ride="carousel"  data-interval="5000">
            
                <div class="carousel-inner">
                    <div class="item active">
                            <div class="col-md-4 col-sm-6">
                                  <div class="block-text rel zmin">
                                  <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html#REVIEWS">Genial Free Walking Tour con Pedro</a>
                                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                                  <p>Magnífico paseo por el centro de Cuzco, recorriendo la historia y las curiosidades de la ciudad y del país peruano. Pedro nos guió muy bien por las partes más conocidas de la ciudad y respondió a todas nuestras preguntas de una manera muy profesional. 100% recomendado!</p>
                                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                </div>
                            <div class="person-text rel">
                               <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/03/0a/18/dc/facebook-avatar.jpg" width="80">    
                              <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html#REVIEWS">DavidDonLopez</a>
                          <!--     <i>from Glasgow, Scotland</i> -->
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 hidden-xs">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or10-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">Excelentes guías</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>El guía tenía un amplio conocimiento histórico de Cusco y de los sitios visitados. Los sitios escogidos para el recorrido son muy interesantes. Me gusto especialmente la plaza de mercado, es un muy buen sitio para comprar recordatorios a buen precio y para ver las costumbres autóctonas.  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="/img/reviews/review-cusco.jpg" width="80">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or10-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">HenryCamilo</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>

                  <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">What a great tour</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>A really informative and personable guide Angie, Cusco native , took us for really amazing tour of the city! The market where we learned about the traditions and local food ,tried local fruit , learned all we needed to know about coca leaves for attitude sickness, botanical garden with colorful explanation of SanPedro ceremony , visiting quechua museum...</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/03/89/95/d3/hawaiisurfbabe.jpg" width="80">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">HawaiiSurfBabe</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>

          </div>

          
                    <div class="item ">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Great free walking tour in Cusco</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Elvis was brilliant, funny and provided us with all the background information to cusco,  Incan history. The pre Incan, Incan and post colonial history. It has been one of the best walking tours I had.</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                  <img alt="" src="/img/reviews/review-cusco3.jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Jalil-Ahmad Sharif</a>
              <!--   <i>from Glasgow, Scotland</i> -->
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Cusco tours by foot</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>My group had Pedro as our guide. It was such a great historical and cultural tour. He gave us a great lay of the city for us to be able to navigate easily on our own. I highly recommend taking this tour it was amazing!  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-cusco1.jpg" width="80">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Krystal Dace</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Educational walking tour</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>It was a great Tour! Our guide was very friedly, gave us a lot of interesting information and aswered all of our questions. We liked the most that he went to the market with us and explained something about the different fruits for example. My two friends and i totally recommand!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/10/e4/32/cc/sunshinegirl2929.jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Kathrin Neumann</a>
              </div>
            </div>
                    </div>



                    <div class="item">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.facebook.com/pg/freewalkingtourscusco/reviews/?ref=page_internal">Getting to know Cusco by walking</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>Great walking tour. Easy to find. Our guide Elvis was very knowledgeable. Even though our group was not too big, he had a microphone so it was easy to hear him. At the end he brought us to a shop where we tried local fruit. Highly recommended for those visiting Cusco!</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/02/3a/76/42/sweetd82.jpg" width="80">
                <a title="" href="https://www.facebook.com/pg/freewalkingtourscusco/reviews/?ref=page_internal">Megan Adam</a>
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="#">Afternoon Free Walking Tour</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Good little walking tour, and the guide made It fun by quizzing us on the things he had told us, along the way. I had been to Cusco before but definitely learned some new things on this tour. Finishing in the shop was a bit cheesy and the guide was blatantly checking the tips but whatever. A good way to spend a couple of spare hours in Cusco and a good introduction to the history of the Incas.</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-cusco2.jpg" width="80">
                    <a title="" href="#">SDRJvoy </a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or40-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">First thing to do in Cusco</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>I’ve done this tour several times. It’s a great intro to Cusco. This was the first time with Angela as our guide and she really did a great job especially with the San Pedro Market. I’ve spent a lot of time in Cusco and I still learned new things about the market this time. Thanks, Angela 
Roy </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/01/d6/c1/9d/roy-mccutchen.jpg" width="80">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or40-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">Roy M</a>
              </div>
            </div>
                    </div>
         
                                    
                </div>
                <a class="left carousel-control" href="#carousel-reviews1" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-reviews1" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </div>
    </div>

</div>


<div class="carousel-reviews broun-block hidden-sm hidden-md hidden-lg">

<h3 class="text-center mt-1 hidden-xs " style="float: left;width: 100%;font-size: 1.6em;">What our customers are saying about us¡</h3>
    <div class="container">
        <div class="">
            <div id="carousel-reviews" class="carousel slide" data-ride="carousel"  data-interval="5000">
            
                <div class="carousel-inner">
                    <div class="item active">
                            <div class="col-md-4 col-sm-6">
                                  <div class="block-text rel zmin">
                                 <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html#REVIEWS">Genial Free Walking Tour con Pedro</a>
                                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                                  <p>Magnífico paseo por el centro de Cuzco, recorriendo la historia y las curiosidades de la ciudad y del país peruano. Pedro nos guió muy bien por las partes más conocidas de la ciudad y respondió a todas nuestras preguntas de una manera muy profesional. 100% recomendado!</p>
                                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                </div>
                            <div class="person-text rel">
                               <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/03/0a/18/dc/facebook-avatar.jpg" width="80">    
                              <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html#REVIEWS">DavidDonLopez</a>
                          <!--     <i>from Glasgow, Scotland</i> -->
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 hidden-xs">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Excelentes guías</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>El guía tenía un amplio conocimiento histórico de Cusco y de los sitios visitados. Los sitios escogidos para el recorrido son muy interesantes. Me gusto especialmente la plaza de mercado, es un muy buen sitio para comprar recordatorios a buen precio y para ver las costumbres autóctonas.  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="/img/reviews/review-cusco.jpg" width="80">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Clara Lam</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>

                  <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">What a great tour</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>A really informative and personable guide Angie, Cusco native , took us for really amazing tour of the city! The market where we learned about the traditions and local food ,tried local fruit , learned all we needed to know about coca leaves for attitude sickness, botanical garden with colorful explanation of SanPedro ceremony , visiting quechua museum...</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/03/89/95/d3/hawaiisurfbabe.jpg" width="80">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">HawaiiSurfBabe</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>

          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or10-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">Excelentes guías</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>El guía tenía un amplio conocimiento histórico de Cusco y de los sitios visitados. Los sitios escogidos para el recorrido son muy interesantes. Me gusto especialmente la plaza de mercado, es un muy buen sitio para comprar recordatorios a buen precio y para ver las costumbres autóctonas.  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="/img/reviews/review-cusco.jpg" width="80">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or10-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">HenryCamilo</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>
          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">What a great tour</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>A really informative and personable guide Angie, Cusco native , took us for really amazing tour of the city! The market where we learned about the traditions and local food ,tried local fruit , learned all we needed to know about coca leaves for attitude sickness, botanical garden with colorful explanation of SanPedro ceremony , visiting quechua museum...</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/03/89/95/d3/hawaiisurfbabe.jpg" width="80">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">HawaiiSurfBabe</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>
          </div>



                    <div class="item ">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Great free walking tour in Cusco</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Elvis was brilliant, funny and provided us with all the background information to cusco,  Incan history. The pre Incan, Incan and post colonial history. It has been one of the best walking tours I had.</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                  <img alt="" src="/img/reviews/review-cusco3.jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Jalil-Ahmad Sharif</a>
              <!--   <i>from Glasgow, Scotland</i> -->
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Cusco tours by foot</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>My group had Pedro as our guide. It was such a great historical and cultural tour. He gave us a great lay of the city for us to be able to navigate easily on our own. I highly recommend taking this tour it was amazing!  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-cusco1.jpg" width="80">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Krystal Dace</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Educational walking tour</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>It was a great Tour! Our guide was very friedly, gave us a lot of interesting information and aswered all of our questions. We liked the most that he went to the market with us and explained something about the different fruits for example. My two friends and i totally recommand!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/10/e4/32/cc/sunshinegirl2929.jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Kathrin Neumann</a>
              </div>
            </div>
                    </div>


          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Cusco tours by foot</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>My group had Pedro as our guide. It was such a great historical and cultural tour. He gave us a great lay of the city for us to be able to navigate easily on our own. I highly recommend taking this tour it was amazing!  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-cusco1.jpg" width="80">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Krystal Dace</a>
              </div>
            </div>
          </div>


          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
              <div class="block-text rel zmin">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Educational walking tour</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>It was a great Tour! Our guide was very friedly, gave us a lot of interesting information and aswered all of our questions. We liked the most that he went to the market with us and explained something about the different fruits for example. My two friends and i totally recommand!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/10/e4/32/cc/sunshinegirl2929.jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1">Kathrin Neumann</a>
              </div>
            </div>
          </div>
                    <div class="item">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.facebook.com/pg/freewalkingtourscusco/reviews/?ref=page_internal">Getting to know Cusco by walking</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>Great walking tour. Easy to find. Our guide Elvis was very knowledgeable. Even though our group was not too big, he had a microphone so it was easy to hear him. At the end he brought us to a shop where we tried local fruit. Highly recommended for those visiting Cusco!</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/02/3a/76/42/sweetd82.jpg" width="80">
                <a title="" href="https://www.facebook.com/pg/freewalkingtourscusco/reviews/?ref=page_internal">Megan Adam</a>
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="#">Afternoon Free Walking Tour</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Good little walking tour, and the guide made It fun by quizzing us on the things he had told us, along the way. I had been to Cusco before but definitely learned some new things on this tour. Finishing in the shop was a bit cheesy and the guide was blatantly checking the tips but whatever. A good way to spend a couple of spare hours in Cusco and a good introduction to the history of the Incas.</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-cusco2.jpg" width="80">
                    <a title="" href="#">SDRJvoy </a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or40-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">First thing to do in Cusco</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>I’ve done this tour several times. It’s a great intro to Cusco. This was the first time with Angela as our guide and she really did a great job especially with the San Pedro Market. I’ve spent a lot of time in Cusco and I still learned new things about the market this time. Thanks, Angela 
Roy </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/01/d6/c1/9d/roy-mccutchen.jpg" width="80">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or40-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">Roy M</a>
              </div>
            </div>
                    </div>

                    <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                <div class="block-text rel zmin">
                    <a title="" href="#">Afternoon Free Walking Tour</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Good little walking tour, and the guide made It fun by quizzing us on the things he had told us, along the way. I had been to Cusco before but definitely learned some new things on this tour. Finishing in the shop was a bit cheesy and the guide was blatantly checking the tips but whatever. A good way to spend a couple of spare hours in Cusco and a good introduction to the history of the Incas.</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-cusco2.jpg" width="80">
                    <a title="" href="#">SDRJvoy </a>
              </div>
            </div>
          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
              <div class="block-text rel zmin">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or40-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">First thing to do in Cusco</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>I’ve done this tour several times. It’s a great intro to Cusco. This was the first time with Angela as our guide and she really did a great job especially with the San Pedro Market. I’ve spent a lot of time in Cusco and I still learned new things about the market this time. Thanks, Angela 
Roy </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/01/d6/c1/9d/roy-mccutchen.jpg" width="80">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-or40-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">Roy M</a>
              </div>
            </div>
          </div>


                                    
                </div>
                <a class="left carousel-control" href="#carousel-reviews" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-reviews" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </div>
    </div>
</div> 
<section class="booknow visible-xs">
<div class="btn-reserva">
  <a href="#titlea-side"><button type="button" class="btn btnreserva2 active">Book Now </button></a>
  <p style="text-align: center; font-size: 1.2em !important;color: #181818;">We are not just a WebSite, We are REVIEWED by more than 250 testimonials, decide wisely¡¡¡</p>
</div>
</section>

<section class="booknow visible-lg">
<div class="btn-reserva">
  <a href="#derecha"><button type="button" class="btn btnreserva2 active">Book Now </button></a>
  <p style="text-align: center; font-size: 1.2em !important;color: #181818;">We are not just a WebSite, We are REVIEWED by more than 250 testimonials, decide wisely¡¡¡</p>
</div>
</section>
 <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Home</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/cusco/" itemprop="url" title="Lima" class="linkgeneral">
                                      <span itemprop="title">Cusco</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Free Walking Tour Cusco at 10:00 am</strong>
                                  </div>
  </div>
           
   <div class="banners mt-5">
         <img src="../img/imgfooter.jpg" alt="publicidad logos">
      </div>
    <?php include('../footer.php');?>

    </div>

    </div>


<script src="https://code.jquery.com/jquery-2.2.3.min.js"></script> 

    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/easy-responsive-tabs.js"></script>
      <script src="../js/script-efectos.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 
   <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>
<script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>
 <script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submitcusco.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>


<style>
    #owl-demo .item{
        margin: 3px;
    }
    #owl-demo .item img{
        display: block;
        width: 100%;
        height: auto;
    }
    </style>



  </body>


</html>




