<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>FREE Walking Tour Cusco | FREE City Tour Cusco | Historical Centre Tours</title>
    <meta content="Join the best Free Walking Tour Cusco or simply a tip-based FREE TOUR, our Half Day Free City Tour Cusco runs in the historical city centre, organized by Charismatic & knowledgeable tour guides who will do their best to make your day a wonderful one in the city centre Tours Cusco." name="description" />
    <meta content="Free Walking Tour Cusco, free tour, half day city tour Cusco, city tour cusco, Tours Cusco, free tours cusco" name="keywords" />
    <meta content="en" name="language" />
   <meta name="author" content="Free Walking Tours" />
    <!-- Bootstrap -->
    <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />
     <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
<link href="../css/flag-icon.min.css" rel="stylesheet">
       <!-- favicons -->
        <link rel="apple-touch-icon" sizes="57x57" href="../favicons/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../favicons/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../favicons/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../favicons/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../favicons/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../favicons/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../favicons/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../favicons/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../favicons/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="../favicons/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="../favicons/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../favicons/favicon-16x16.png">
        <link rel="manifest" href="../favicons/manifest.json">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content="../favicons/ms-icon-144x144.png">
        <meta name="theme-color" content="#ffffff">
          <!-- end favicons -->
          <!-- open graph -->
                          <meta property="og:type" content="website">
                          <meta property="og:title" content="FREE Walking Tour Cusco | FREE City Tour Cusco | Historical Centre Tours">
                          <meta property="og:description" content="Join the best Free Walking Tour Cusco or simply a tip-based FREE TOUR, our Half Day Free City Tour Cusco runs in the historical city centre, organized by Charismatic & knowledgeable tour guides who will do their best to make your day a wonderful one in the city centre Tours Cusco.">
                          <meta property="og:url" content="https://www.freewalkingtoursperu.com/cusco/">
                          <meta property="og:image" content="https://www.freewalkingtoursperu.com/img/free-walks-cusco-3.jpg">
                          <meta property="fb:app_id" content="freewalkingtourscusco">
                              <!-- twitter -->
          <!-- end open graph -->

<script type="application/ld+json">
      {
        "@context": "http://schema.org/",
        "@type": "Review",
        "itemReviewed": {
          "@type": "Thing",
          "name": "Historical Center Walking Tour"
        },
        "author": {
          "@type": "Organization",
          "name": "Cusco"
        },
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": "4.9",
          "bestRating": "5"
        },
        "publisher": {
          "@type": "Organization",
          "name": "Free Walking Tours Peru"
        }
      }
      
    </script>


  </head>

  <body>

   <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>


     <script src="../js/mapa-cusco.js"></script>

    <div class="container px-0">
      <header class="cabecera">

         <?php include('../menu.php');?>
         
            <!-- <div class="idiomas">
        <span class="en"><a href="/cusco/"><img src="../img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/cusco/"><img src="../img/es.png" alt="ingles"></a></span>
      </div> -->

              <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                      <ul class="rslides" id="slider2">
                        <li><img src="../img/home-free-walking-tour-cusco.jpg" alt="free walking tours cusco"></li>
       <!--                  <li><img src="../img/cusco-slider-walking-tour.jpg" alt="free walking tours cusco"></li> -->
                      </ul>
                </div>
            </div>   

              
      </header>

    <div class="cuerpo">

      <section class="container izquierda">
             
            <div class="text-general col-lg-12 col-lg-12 col-xs-12">
              <h1><b>Free</b> Walking Tour Cusco | Half Day Free City Tour Cusco | Historical Centre Tours</h1> 
              
            <p>Explore Cusco city centre on foot, with the number one Free Walking Tour Cusco Company, when walking with us you will visit Must-Do attractions both from Inka & Colonial Heritage, we will walk into real Inka streets, Old Spanish buildings(House of Francisco Pizarro), Inka aqueducts, anti-earthquake Inka walls, South-American Camels, great intro to Inka Culinary(explanation), daily Life of Local Indigenous people, offerings to the Pachamama(explanation) and much more, all this inclusions and places to visit make our Free half day city tour very unique and enjoyable by all tourists who are keen to walk, keep in mind that this Cusco city tour it´s a free walking tour or simply a free tour based on gratuity, not bus Tours Cusco.
We are offering currently three Free Tour Departures in Cusco, all of them are the same, starting at 10am – 1pm – 3:30pm applies from Mon to Sat only - Every Sundays we only have one free tour departure at 10AM keep in mind, pls don´t book other Free city tours Cusco by foot.
</p>
<p>We are offering currently three Free Tour Departures in Cusco, all of them are the same, starting at 10am – 1pm – 3:30pm applies from Mon to Sat only - Every Sundays we only have one free tour departure at 10AM keep in mind, pls don´t book other Free city tours Cusco by foot.</p>


<h2>Free Tour Meet up Times:</h2>

<p>From Monday to Saturday at 10am & 1pm & 3:30pm - On Sundays at 10am only. </p>

<h2>Meeting Point: </h2>
<p>For all our Free Tours Cusco on foot, join us at Regocijo Plazoleta in front of Choco Museo.</p>
<h2>How to identify your Correct Tour Guide:</h2>
<ul>
  <li>Look for us at the Correct Meeting Point.</li>
<li>We wear the Inkan Milky Way Logo on the Yellow Vests.</li>
</ul>

<h2>Inclusions four our Tours Cusco on foot:</h2>
<p>All our Free Tours Cusco include Professional Tour Guide, Fantastic English, Must-do half day city tour Attractions, Culture and History – <span class="text-danger">NO Bars</span>, NO Drinks, we got history for you.</p>

<h2>Duration:</h2>
<p>2.5 to 3 hours max.</p>
<h2>Price:</h2>
<p>FREE - Donation Basis.</p>
<h2>Language:</h2>
<p>Groups in English & Spanish, you choose your language | Si hablas español debes de venir al free tour de las 10am(Lunes a Domingo), es 100% Español, los demás free tours son en Ingles.</p>
<div class="btn-reserva">
  

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#titlea-side"><button type="button" class="btn btnreserva active">Book Now</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>
<p><span style="color: #ff0000;">To Consider:</span>&nbsp;You might get confused with other people, pls show up at the correct meeting point &amp; Our free tours in Lima are operated by Inkan Milky Way Tours Cusco, a 100% Indigenous Peruvian Co,&nbsp;<a href="https://web.facebook.com/freewalkingtourscusco/">follow us here.</a></p>

              

            </div>

            <div class="row">

                                  <div class="ciudadfwt bot25">

                                                 <div class="center"> 
                                                  <a href="downtown-city-tour">
                                                  <h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking City Tour Cusco @ 10am</span></span></h3>
                                                  </a>
                                                 </div>
                                                <div class="slidert">
                                                      
                                                        <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                       <img class="efectoimg" src="../img/free-walking-tour-cusco-10-am.jpg" alt="free walking tour 10 am">
                                                      </div>

                                                        <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                          <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tour Type:</strong></span> Cultural Walking. <br>
                                                          <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> When:</strong></span> Monday to Saturday.<br>
                                                          <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Good For:</strong></span> All people capable & keen to walk.<br>
                                                          <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duration:</strong></span> 2.5 hours to 3 hours.<br>
                                                          <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Difficulty:</strong></span> None, flat walking 1.6 km – 1 mi.<br>
                                                          <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Meeting Point:</strong></span><span class="letrap">Regocijo Plazoleta in front of Choco Museo.</span><br>
                                                          <span><i class="fa fa-language" aria-hidden="true"></i><strong> Language: </strong></span>English - Español <br>
                                                          <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Look for:</strong></span> Inkan Milky Way Logo.<br>
                                                          
                                                          <div>
                                                              <div class="porciento50">
                                                              <span><a class="click-here" href="downtown-city-tour"><i class="fa fa-info-circle" aria-hidden="true"></i> More Info</a></span>
                                                     
                                                             </div> 
                                                              <div class="porciento50"><a href="/booking"><button type="button" class="btn btn-primary">Book Now</button></a></div>
                                                          </div>
                                                        </div>
                                               </div>
                                               
                                    </div>
                                      <div class="ciudadfwt bot25">
                                               <div class="center"> 
                                                  <a href="walking-tour-plaza-armas"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking City Tour Cusco @ 1pm</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/free-walking-tour-cusco-1-pm.jpg" alt="free walking tour 1pm">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                      <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tour Type:</strong></span> Cultural Walking.<br>

                                                      <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> When:</strong></span> Monday to Saturday.<br>

                                                      <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Good For:</strong></span> All people capable & keen to walk.<br>

                                                      <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duration:</strong></span> 2.5 hours to 3 hours.<br>

                                                      <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Difficulty:</strong></span> None, flat walking 1.6 km – 1 mi.<br>

                                                      <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Meeting Point:</strong></span><span class="letrap">Regocijo Plazoleta in front of Choco Museo</span><br>
                                                      <span><i class="fa fa-language" aria-hidden="true"></i><strong> Language: </strong></span>English <br>

                                                      <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Look for:</strong></span>Inkan Milky Way Logo. <br>

                                                      
                                                      <div>
                                                       <div class="porciento50">
                                                        <span><a class="click-here" href="walking-tour-plaza-armas"><i class="fa fa-info-circle" aria-hidden="true"></i> More Info</a></span>
                                                       </div> 
                                                        <div class="porciento50"><a href="/booking"><button type="button" class="btn btn-primary">Book Now</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>

                                  </div>


                                  <div class="ciudadfwt">

                                                 <div class="center"> 
                                                  <a href="walking-tour-historical-center"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking City Tour Cusco @ 3:30pm</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/historical-center-cusco-free-tour.jpg" alt="free walking tour 3.30pm">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tour Type:</strong></span>Cultural Walking<br>

                                                    <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> When:</strong></span> Monday to Saturday.<br>

                                                    <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Good For:</strong></span> All people capable & keen to walk.<br>

                                                    <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duration: </strong></span>2.5 hours to 3 hours.<br>

                                                    <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Difficulty: </strong></span>None, flat walking 1.6 km – 1 mi.<br>

                                                    <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Meeting Point:</strong></span><span class="letrap">Regocijo Plazoleta in front of Choco Museo.</span><br>
                                                    <span><i class="fa fa-language" aria-hidden="true"></i><strong> Language: </strong></span>English <br>

                                                    <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Look for:</strong></span>Inkan Milky Way Logo. <br>

                                                    
                                                    <div>
                                                       <div class="porciento50">
                                                        <span><a class="click-here" href="walking-tour-historical-center"><i class="fa fa-info-circle" aria-hidden="true"></i> More Info</a></span>
                                                       </div> 
                                                        <div class="porciento50"><a href="/booking"><button type="button" class="btn btn-primary">Book Now</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                        </div>
                                      <div class="ciudadfwt">
                                               <div class="center"> 
                                                  <a href="tour-sunday"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Sunday Free Walking City Tour Cusco @ 10AM</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/sunday-free-tour-cusco.jpg" alt="Sunday Walking Tour Cusco">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tour Type:</strong></span> Cultural Walking.<br>

                                                    <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> When:</strong></span> Only Sundays.<br>

                                                    <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Good For:</strong></span> All people capable & keen to walk.<br>

                                                    <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duration:</strong></span> 2.5 hours to 3 hours.<br>

                                                    <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Difficulty:</strong></span> None, flat walking 1.6 km – 1 mi.<br>

                                                    <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Meeting Point:</strong></span><span class="letrap">Regocijo Plazoleta in front of Choco Museo.</span><br>
                                                    <span><i class="fa fa-language" aria-hidden="true"></i><strong> Language: </strong></span>English - Español <br>

                                                    <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Look for:</strong></span> Inkan Milky Way Logo.<br>

                                                   
                                                    <div>
                                                       <div class="porciento50">
                                                        
                                                        <span><a class="click-here" href="tour-sunday"><i class="fa fa-info-circle" aria-hidden="true"></i> More Info</a></span>
                                                       </div> 
                                                        <div class="porciento50"><a href="/booking"><button type="button" class="btn btn-primary">Book Now</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>

                                  </div>

                </div>
            <!-- /.row -->
            <div class="mapasciudad">
                    <!-- <div class="centrarimg">
                  <img src="../img/maps-inkan-mily-way-en.jpg" alt="cusco walks maps">
                  </div> -->

                  <div class="row">

                      <div class="col-lg-12">
                          
                              <div class="col-lg-12 col-md-12 col-xs-12">
                              <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="Free Tours by Foot Cusco 10am - 1pm - 3.30pm - Sunday 10am " data-caption="free walking cusco" data-image="../img/maps-inkan-mily-way-en.jpg" data-target="#image-gallery">
                                  <img class="img-responsive" src="../img/maps-inkan-mily-way-en.jpg" alt="Another alt text">
                              </a>
                        </div>


                  <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <div class="modal-dialogo">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span><span class="sr-only">Close</span></button>
                                  <h4 class="modal-title" id="image-gallery-title"></h4>
                              </div>
                              <div class="modal-body">
                                  <img id="image-gallery-image" class="img-responsive" src="">
                              </div>
                              
                          </div>
                      </div>
                  </div>


                </div>
           </div>

           </div>

      </section>
    <br>
    <br>
    
      <aside class="derecha" id="titlea-side">
<?php include('../cuadro-reservas-cusco.php');?>
      <div class="tripadvisor" style="margin-top: 0px;">
      
  <div id="TA_cdsratingsonlynarrow512" class="TA_cdsratingsonlynarrow">
<ul id="2xvW74xHXBz" class="TA_links MGvigEd5X">
<li id="4HsZTTH10pTu" class="i5JXV1o1lXkV">
<a target="_blank" href="https://www.tripadvisor.com/"><img src="https://www.tripadvisor.com/img/cdsi/img2/branding/tripadvisor_logo_transp_340x80-18034-2.png" alt="TripAdvisor"/></a>
</li>
</ul>
</div>
<script src="https://www.jscache.com/wejs?wtype=cdsratingsonlynarrow&amp;uniq=512&amp;locationId=7238744&amp;lang=en_US&amp;border=true&amp;shadow=true&amp;display_version=2"></script>

</div>

<!-- <div class="facebookpubli">
  <div class="fb-page" data-href="https://www.facebook.com/CuscoFTF/" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/CuscoFTF/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/CuscoFTF/">Free Tours by Foot Cusco</a></blockquote></div> -->
  

<br>


  <div class="fb-page" data-href="https://www.facebook.com/freewalkingtourscusco/" data-width="380" 
  data-hide-cover="false"
  data-show-facepile="false" 
  data-show-posts="false"></div>

     <div class="chalecoc text-center mt-5 mb-5">
          <img src="../img/chaleco-img.png" alt="chalecos fwt" width="250px" >
        </div>

</div>
<br>
<!-- <div class="conditionsdv">
<h4 class="titulo-conditions">Our Conditions to join our free tour in Cusco</h4>
<ul>
<li>Our free tour itineraries include history, if history is what you want, join us.</li>
<li>At our company we don’t offer drinks, samples of choco or coffee, we do 100% history.</li>
<li>All our free tour itineraries include explanation of the city (from outdoor areas), that means we are NOT going inside the museums or churches.</li>
<li>Tourists who love ESCAPING WAY from walking tours after having taken 80% of the tour are NOT allowed, because tour guides work on tips.</li>
<li><b>Tourists who are very bossy, intolerant, high demanding and picky are not allowed.</b></li>
<li>All people have the right to be upset although if you come to our free tours don’t expect our tour guides to make you laugh, because they are not comedians.</li>

</ul>
<p>
  All above said is with all the due respect to all our customers, we love our people therefore we exist, we are passionate team, fun to be with people but from time to time we’ve got tourists abusing of the free tour condition.
Inkan Milky Way – Free Tours by Foot Cusco<br>
The Management


</p>

</div> -->
      </aside>
      <div class="maps-c mb-5">
       <div class="contenedormap"><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15517.202489400717!2d-71.980109!3d-13.5171337!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x49be8bcaa264818d!2sInkan+Milky+Way+Cusco%2C+Free+Walking+Tour!5e0!3m2!1ses!2spe!4v1520118233554" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>
     </div>
          <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Home</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Cusco</strong>
                                  </div>
                  </div>
     <section class="mt-5 pt-5 mb-5" style="display: block;float: left;">

         <div id="wrap">
            <div class="card mb-5">
              <div class="thumb" id="one" style="background-image: url(../img/free-walking-tour-lima-10-30-am.jpg);}"></div>
              <div class="option">
                <i class="material-icons"></i>
                <i class="material-icons"></i>
                <i class="material-icons"></i>
              </div>
              <h3 class="text-center">Free Tour Lima</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Going to Lima? Join our free tour Partner, offering the best tip based walks, full on history & culture</p>
              <div class="add"><a target="_blank" href="/es/lima/">More Info</a></div>
              <div class="buy"> <a target="_blank" href="/es/reservar/">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="two" style="background-image: url(../img/free-walking-tour-arequipa-3-pm.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Free Tour Arequipa</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3" >Are you planning to visist Arequipa? Be part of the finest free walking tours operated by our Partner</p>
              <div class="add"> <a target="_blank" href="/es/arequipa/">More Info</a></div>
              <div class="buy"><a target="_blank" href="/es/reservar/">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="three" style="background-image: url(../img/cusco-private-tour.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Private Walks Cusco</h3>
              
              <p class="price">$35.00</p>
              
              <p class="desc mt-1 mb-3">Want a private walk? Then join our premier private walking tours, operated by a Local Indigenous Co</p>
              <div class="add"> <a target="_blank" href="#">More Info</a></div>
              <div class="buy"><a target="_blank" href="#">Book Know</a></div>
            </div>
          </div>

  
     </section>

    <div class="banners mt-5">
       <img src="../img/imgfooter.jpg" alt="img footer">
    </div>
    <?php include('../footer.php');?>


    </div>
<script src="https://code.jquery.com/jquery-2.2.3.min.js"></script>  
    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>

 <script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>
<script language="javascript">
$(document).ready(function() {
    $().ajaxStart(function() {
        $('#loading').show();
        $('#result').hide();
    }).ajaxStop(function() {
        $('#loading').hide();
        $('#result').fadeIn('slow');
    });
    $('#form, #fat, #fo3').submit(function() {
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function(data) {
                $('#result').html(data);

            }
        })
        
        return false;
    }); 
})  
</script>

  
<script>
  
 $(document).ready(function(){

    loadGallery(true, 'a.thumbnail');

    //This function disables buttons when needed
    function disableButtons(counter_max, counter_current){
        $('#show-previous-image, #show-next-image').show();
        if(counter_max == counter_current){
            $('#show-next-image').hide();
        } else if (counter_current == 1){
            $('#show-previous-image').hide();
        }
    }


    function loadGallery(setIDs, setClickAttr){
        var current_image,
            selector,
            counter = 0;

        $('#show-next-image, #show-previous-image').click(function(){
            if($(this).attr('id') == 'show-previous-image'){
                current_image--;
            } else {
                current_image++;
            }

            selector = $('[data-image-id="' + current_image + '"]');
            updateGallery(selector);
        });

        function updateGallery(selector) {
            var $sel = selector;
            current_image = $sel.data('image-id');
            $('#image-gallery-caption').text($sel.data('caption'));
            $('#image-gallery-title').text($sel.data('title'));
            $('#image-gallery-image').attr('src', $sel.data('image'));
            disableButtons(counter, $sel.data('image-id'));
        }

        if(setIDs == true){
            $('[data-image-id]').each(function(){
                counter++;
                $(this).attr('data-image-id',counter);
            });
        }
        $(setClickAttr).on('click',function(){
            updateGallery($(this));
        });
    }
});
</script>




  </body>


</html>
