<?php
if($_POST)
{
    $fname = $_POST['name2'];
    $email = $_POST['email4'];
    $nombretours = $_POST['ciudad2'];
    $fecha=$_POST['date2'];
    $lname = $_POST['size2'];
    $phno = $_POST['message2'];

    

$from = $_POST['email4'];

$subject = 'Free Walks Arequipa - English';
$subject2= 'Your CONFIRMATION Details Arequipa';
$message = 
'<table width="300" border="1" align="center" cellpadding="1" cellspacing="1"
  <tr>
    <th colspan="2">Free Tour Downtown Arequipa<br></th>
  </tr>
  <tr>
    <td>Name<br></td>
    <td>'.$fname.'</td>
  </tr>
  <tr>
    <td>Tour<br></td>
    <td>'.$nombretours.'</td>
  </tr>
  <tr>
    <td>Date<br></td>
    <td>'.$fecha.'</td>
  </tr>
  <tr>
    <td>Nro Pax<br></td>
    <td>'.$lname.'</td>
  </tr>
  <tr>
    <th colspan="2">Message<br></th>
  </tr>
   <tr>
   <th colspan="2">'.$phno.'<br></th>
  </tr>
</table>';

$message2 = 
'<table style="height: 173px; width: 456.767px;" border="1">
<tbody>
<tr>
<td style="width: 130px;">Company:</td>
<td style="width: 304.767px; text-align: center;"><strong> Recommended company</strong><br /> Free Tour Downtown Arequipa</td>
</tr>
<tr>
<td style="width: 130px;">Pax Name:</td>
<td style="width: 304.767px;">&nbsp;'.$fname.'</td>
</tr>
<tr>
<td style="width: 130px;">Size of Group:</td>
<td style="width: 304.767px;">&nbsp;'.$lname.'</td>
</tr>
<tr>
<td style="width: 130px;">Date of the Tour:</td>
<td style="width: 304.767px;">&nbsp;'.$fecha.'</td>
</tr>
<tr>
<td style="width: 130px;">Starting Time:</td>
<td style="width: 304.767px;">&nbsp;'.$nombretours.'</td>
</tr>
<tr>
<td style="width: 130px;">Meeting Point:</td>
<td style="width: 304.767px; text-align: left;">Santa Catalina street #204, inside the Chaqchao <strong>Choco Museo</strong></td>
</tr>
</tbody>
</table>
<p style="margin-top: 0px; margin-bottom: 0px; color: #000000; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; font-family: Calibri,Arial,Helvetica,sans-serif;">&nbsp;</p>
<p style="margin-top: 0px; margin-bottom: 0px; color: #000000; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; font-family: Calibri,Arial,Helvetica,sans-serif;"><span style="font-size: 18px;"><strong><span style="color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="color: #888888; font-family: Calibri,Arial,Helvetica,sans-serif;"><span style="color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="color: #006fc9; font-family: Calibri,Arial,Helvetica,sans-serif;"><span style="font-family: Calibri,Arial,Helvetica,sans-serif;"><span style="color: #000000;">NOTE:</span></span></span></span></span></span></strong></span></p>
<p>Thanks for booking with our free tour partner in Arequipa city, please show up at the correct meeting point.</p>
<ul>
<li>If you miss your free tour, you can still join us at the following meet up times: From mon to Sunday(7 days) at: 10am &ndash; 3pm.</li>
<li>Any testimonial for our free tours in Arequipa, please write <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5388673,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786!9m1!1b1">here</a>.</li>
<li>See our meeting point in <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5388673,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786">Google maps here</a>.</li>
</ul>
<p style="text-align: center;"><span style="background-color: #ff0000; color: #ffffff;">WARNING for LIMA CITY!:</span></p>
<ul>
<li>If you are coming to Lima, Don&rsquo;t get confused with fake guides wearing Fake yellow vests withOUT our Logo: Inkan Milky Way Tours Lima.</li>
<li>We speak decent ENGLISH in Lima, not like the fake guides in Lima who speak POOR ENGLISH, we don&rsquo;t either ask 60 soles tip pp, that is not us.</li>
<li>For our free tours in Lima, DO join <a href="https://www.freewalkingtoursperu.com/lima/">Inkan Milky Way Tours Lima</a> reviewed by <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1">200+ real &amp; great testimonials</a> and have a decent walking tour with a licensed company.</li>
</ul>
<p>&nbsp;<span style="font-size: 12pt;"><strong style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #888888;"><span style="font-size: 14px; color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><img src="http://www.inkanmilkyway.com/wp-content/uploads/2018/05/free-walking-tours-map-arequipa-en.png" alt="Meeting Point Arequipa" width="428" height="248" /></span></strong></span></p>
<p style="margin-top: 0px; margin-bottom: 0px; color: #000000; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; font-family: Calibri, Arial, Helvetica, sans-serif;"><strong style="font-size: 14px; font-family: Arial, Helvetica, sans-serif;">Free Tour Downtown&nbsp; Arequipa <br /></strong></p>
<p style="margin-top: 0px; margin-bottom: 0px; color: #000000; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; font-family: Calibri, Arial, Helvetica, sans-serif;"><strong style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt;"><span style="color: #bd1398;">Contact Number</span></strong><span style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt; color: #bd1398;">:</span></p>
<p style="margin-top: 0px; margin-bottom: 0px; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #666666; font-family: Calibri, Arial, Helvetica, sans-serif;"><span style="font-size: 12px; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="color: #1b4260;"><span style="background-color: #ffffff; color: #000000;">Whatsapp: +51 959305262</span></span><span style="background-color: #ffffff; color: #000000;"> -&nbsp; Bedgard - Tour Guide - Owner</span></span></p>
<p style="margin-top: 0px; margin-bottom: 0px; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #666666; font-family: Calibri, Arial, Helvetica, sans-serif;"><span style="font-size: 12px; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="background-color: #ffffff; color: #000000;">Whatsapp: +1(514) 6631229&nbsp; -&nbsp; Alex - Owner<br /></span></span></p>
';
$from3=$fname."<".$email.">";

$headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers .= "From: ". $from3 . "\n";

$from2='Free Tour Downtown Arequipa<info@freewalkingtoursperu.com>';
$headers2 = 'MIME-Version: 1.0' . "\r\n";
    $headers2 .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers2 .= "From: ". $from2 . "\n";

mail ('info@freewalkingtoursperu.com', $subject, $message, $headers);

mail ($from, $subject2, $message2, $headers2);




    ?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2" class="resultado">Thanks for booking with Inkan Milky Way Tours Arequipa, operated by our free tour partner in Arequipa, we just replied you with all your Confirmation Details, Check your Inbox or Spam Box, so that you get to the Correct Meeting Point – If no reply show up at the Correct Meeting Point, we already got you in our system – Double check your meet up times.
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">NOTICE: Double check your Meeting Point Map for each city.</span></td>
    </tr>
    </tbody></table>
    <?php
    
}

?>