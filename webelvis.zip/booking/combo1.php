<?php
// esta es una  vista html lo sustituyes con tu consulta
$rpta="";
if ($_POST["elegido"]=="lima") {
	$rpta= '
	<option value="Lima_10:30_am">Free Tours by Foot Lima 10:30 am</option>
	<option value="Lima_11:30_am">Free Tours by Foot Lima 11:30 am</option>
	';	
}
if ($_POST["elegido"]=="miraflores") {
	$rpta= '
	<option value="Miraflores_4:15_pm">Free Tours by Foot Miraflores 4:15 pm</option>
	';	
}
if ($_POST["elegido"]=="arequipa") {
	$rpta= '
	<option value="arequipa_10:00_am">Free Tours by Foot Arequipa 10:00 am</option>
	<option value="arequipa_3:00_pm">Free Tours by Foot Arequipa 3:00 pm</option>
	';	
}
if ($_POST["elegido"]=="cusco") {
	$rpta= '
	<option value="cusco_10:00_am">Downtown Walking City Tour at 10:00 am</option>
	<option value="cusco_1:00_pm">Puma Walking Tour at 1:00 pm</option>
	<option value="cusco_3:30_pm">Historical Center Walking Tour at 3:30 pm</option>
	<option value="cusco_10:00_am">Free Tours Sunday Cusco 10:00 am</option>
	';	
}
echo $rpta;	
?>