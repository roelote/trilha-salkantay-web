<?php
if($_POST)
{
    $fname = $_POST['name'];
    $email = $_POST['email'];
    $nombretours = $_POST['ciudad'];
    $fecha=$_POST['date'];
    $lname = $_POST['size'];
    $phno = $_POST['message'];
 

    

$from = $_POST['email'];

$subject = 'Free Walks Cusco - English';
$subject2= 'Your CONFIRMATION Details Cusco';
$message = 
'<table width="300" border="1" align="center" cellpadding="1" cellspacing="1"
  <tr>
    <th colspan="2">Booking Free Tour by Foot Cusco<br></th>
  </tr>
  <tr>
    <td>Name<br></td>
    <td>'.$fname.'</td>
  </tr>
  <tr>
    <td>Tour<br></td>
    <td>'.$nombretours.'</td>
  </tr>
  <tr>
    <td>Date<br></td>
    <td>'.$fecha.'</td>
  </tr>
  <tr>
    <td>Nro Pax<br></td>
    <td>'.$lname.'</td>
  </tr>
  <tr>
    <th colspan="2">Message<br></th>
  </tr>
   <tr>
   <th colspan="2">'.$phno.'<br></th>
  </tr>
</table>';

$message2 = 
'<table style="height: 173px; width: 456.767px;" border="1">
<tbody>
<tr>
<td style="width: 130px;">Company:</td>
<td style="width: 304.767px; text-align: center;"><strong>Inka Milky Way Tours Cusco</strong></td>
</tr>
<tr>
<td style="width: 130px;">Pax Name:</td>
<td style="width: 304.767px;">&nbsp;'.$fname.'</td>
</tr>
<tr>
<td style="width: 130px;">Size of Group:</td>
<td style="width: 304.767px;">&nbsp;'.$lname.'</td>
</tr>
<tr>
<td style="width: 130px;">Date of the Tour:</td>
<td style="width: 304.767px;">&nbsp;'.$fecha.'</td>
</tr>
<tr>
<td style="width: 130px;">Starting Time:</td>
<td style="width: 304.767px;">&nbsp;'.$nombretours.'</td>
</tr>
<tr>
<td style="width: 130px;">Meeting Point:</td>
<td style="width: 304.767px; text-align: center;"><a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.980109,15z/data=!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">Regocijo Plazoleta&nbsp;</a>(Kusipata) in front of the&nbsp;<a href="https://www.google.com.pe/maps/place/Museo+del+Chocolate/@-13.5172359,-71.9804421,15z/data=!4m2!3m1!1s0x0:0x2f9797c884894ed0?sa=X&amp;ved=0ahUKEwjtmsrA0MzZAhVyUd8KHRaDDQAQ_BIIuQEwDg">Choco Museo</a>&nbsp;or City Hall.</td>
</tr>
</tbody>
</table>
<p style="text-align: center;"><strong><span style="color: #000000;">NOTE:</span></strong></p>
<ul>
<li>We are&nbsp;<strong>Inkan Milky Way Tours Cusco</strong>, your booking is confirmed, we already got u on our system, we will be waiting for you at the Correct Meeting Point, don&rsquo;t make us wait for you for nothing, if you cannot come, let us know.</li>
<li>Our Official Tour Guides Elvis or Richard wear the&nbsp;<span style="background-color: #ffff00;">Inkan Milky Way Logo</span>, on the Yellow Vests, then look for our Logo, they are the only ones who can assign u a different qualified REAL tour guides.</li>
<li>If you miss our free tour, you can still join us at the following departures: From Mon to Sat at:&nbsp;<strong>10am &ndash; 1pm &ndash; 3:30pm</strong>&ndash; on&nbsp;<em>Sundays at&nbsp;10am only.</em></li>
<li>We offer original historical walks: NO Bars - No Restaurants - NO&nbsp;Drinks.</li>
<li><span style="color: #ff0000;">Dont get confused with other people claiming to work with us at Plaza de Armas,&nbsp;Plaza Espinar, they are not our team, they wear blue t-shirts, white t-shirts, ogange t-shirts, purple vests.</span></li>
<li>Google us here<a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.980109,15z/data=!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">Cusco Meeting Point Map</a>.</li>
</ul>
<p><strong>How to find our Meeting Point in Cusco?</strong>&nbsp;You can check our&nbsp;<a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.980109,15z/data=!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">google map for REGOCIJO&nbsp;</a>or use as Landmark&nbsp;<a href="https://www.google.com.pe/maps/place/Museo+del+Chocolate/@-13.5172359,-71.9804421,15z/data=!4m5!3m4!1s0x0:0x2f9797c884894ed0!8m2!3d-13.5172359!4d-71.9804421">Choco Museo</a>, note that to get to our meeting point takes from 2 min to 15 min on foot.</p>
<h3 style="text-align: center;"><strong>Keep free walking with us in three cities:&nbsp;</strong><a href="https://www.freewalkingtoursperu.com/lima/">Lima</a><strong>,&nbsp;</strong><a href="https://www.freewalkingtoursperu.com/arequipa/">Arequipa</a><strong>&nbsp;and&nbsp;</strong><a href="https://www.freewalkingtoursperu.com/cusco/">Cusco</a><strong>,&nbsp;</strong><a href="https://www.freewalkingtoursperu.com/booking/">BOOK NOW</a><strong>!</strong></h3>
<p>&nbsp;<span style="font-size: 12pt;"><strong style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #888888;"><span style="font-size: 14px; color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><img src="https://www.freewalkingtoursperu.com/img/maps-inkan-mily-way-en.jpg" alt="Meeting Point Cusco" width="497" height="288" /></span></strong></span></p>
<p><strong>www.freewalkingtoursperu.com is operated by:</strong></p>
<p><strong>Inkan Milky Way Tours Cusco</strong><br /> <span style="color: #ff00ff;">Contact Numbers:</span><br /> <span style="color: #008000;">Whatsapp: +51 958745640 &amp; +51 984479073&nbsp;</span></p>
';

$from3=$fname."<".$email.">";
$headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers .= "From: ". $from3 . "\n";

$from2='Inkan Milky Way Tours<info@freewalkingtoursperu.com>';
$headers2 = 'MIME-Version: 1.0' . "\r\n";
    $headers2 .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers2 .= "From: ". $from2 . "\n";

mail ('info@freewalkingtoursperu.com', $subject, $message, $headers);

mail ($from, $subject2, $message2, $headers2);


    ?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2" class="resultado">Thanks for booking with Inkan Milky Way Tours Cusco, we just replied you with all your Confirmation Details, Check your Inbox or Spam Box, so that you get to the Correct Meeting Point – If no reply show up at the Correct Meeting Point, we already got you in our system – Double check your meet up times, especially on Sundays.
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">NOTICE: Double check your Meeting Point Map for each city.</span></td>
    </tr>
    </tbody></table>
    <?php
    
}

?>



