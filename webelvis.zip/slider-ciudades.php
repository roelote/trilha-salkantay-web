              <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                <!-- Slideshow 1 -->
                      <ul class="rslides" id="slider2">
                        <li><img src="../img/fondo1.jpg" alt="free walking tours lima"> <div class="texto-slider"><img alt="Feel Free Tours" src="../img/chalecos.png" class="img-responsive logo">
                        <h2 class="h2slider"> Free Tours by Foot Lima - FTF Lima </h2> 
                        <h2 class="contenido-texts">Hi Dear Lima Walkers, we do have two Free Walking Tours in Lima every day at 10:30am&11:30am, Meet us at Ovalo Miraflores by 10:30 and at Plaza de Armas(by the fountain) by 11:30am, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused. </h2></div></li>

                        <li><img src="../img/fondo2.jpg" alt="free walking tours miraflores"> <div class="texto-slider"><img alt="Feel Free Tours" src="../img/chalecos.png" class="img-responsive logo">
                        <h2 class="h2slider textomaspequenio">Free Tours by Foot Miraflores - FTF Miraflores </h2> 
                        <h2 class="contenido-texts">Hi Dear Miraflores Walkers, we do have one Free Walking Tour in Miraflores District(Lima) every day at 04:15pm, Meet us at Ovalo Miraflores ONLY, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused. </h2></div></li>

                        <li><img src="../img/fondo2.jpg" alt="free walking tours arequipa"> <div class="texto-slider"><img alt="Feel Free Tours" src="../img/chalecos.png" class="img-responsive logo">
                        <h2 class="h2slider textomaspequenio">Free Tours by Foot Arequipa - FTF Arequipa  </h2> 
                        <h2 class="contenido-texts">Hi Dear Arequipa Walkers, we do have two Free Walking Tours in Arequipa every day at 10:00am&3:00pm, for all free tours meet us at Santa Catalina street #204-Choco Factory ONLY, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused. </h2></div></li>

                        <li><img src="../img/fondo2.jpg" alt="free walking tours cusco"> <div class="texto-slider"><img alt="Feel Free Tours" src="../img/chalecos.png" class="img-responsive logo">
                        <h2 class="h2slider">Free Tours by Foot Cusco - FTF Cusco  </h2> 
                        <h2 class="contenido-texts">Hi Dear Cusco Walkers, we do have three Free Walking Tours in Cusco from Mon to Sat at 10:00am&1:00pm&3:30pm, On Sun at 12:20pm only. For all free tours meet us at Plaza Regocijo ONLY, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused.  </h2></div></li>
                      </ul>
                </div>
            </div>     
