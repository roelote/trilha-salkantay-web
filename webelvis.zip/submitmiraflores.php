<?php
if($_POST)
{
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phno = $_POST['phno'];
    $fecha=$_POST['date'];
    $nombretours = $_POST['nombretour'];
    

$from = $_POST['email'];
$subject = 'Booking in English Miraflores';
$message = 'Nombre: ' . $fname . 
"\n". 'Email: ' . $email. 
"\n". 'Tour:' . $nombretours.
"\n". 'Date:' . $fecha.  
"\n". 'Nro Pax:' . $lname. 
"\n". 'Message:' . $phno;

$headers = "From: ". $from . "\n";
mail ('info@freewalkingtoursperu.com ', $subject, $message, $headers);


	?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2">Your booking for Miraflores free tour is CONFIRMMED, just show up at the CORRECT Meeting Point.
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">NOTICE: Double check your Meeting Point Map for each city.</span></td>
    </tr>
    </tbody></table>
    <?php
	
}

?>