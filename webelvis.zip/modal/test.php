<?php
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    echo "Thank you " . $first_name . " " . $last_name . " for your submission.";
?>