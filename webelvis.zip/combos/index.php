<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Combos dependientes</title>
<script src="js/jquery-1.2.6.min.js"></script>
<script>
$(document).ready(function(){
	// Estos son los parametros para el pimer combo
   $("#combo1").change(function () {
   		$("#combo1 option:selected").each(function () {
				elegido=$(this).val();
				$.post("combo1.php", { elegido: elegido }, function(data){
				$("#combo2").html(data);
				$("#combo3").html("");
			});			
        });
   })
});
</script>
</head>
<body>					
						<form method="post" action="mailcombo.php">

						<select name="combo1" id="combo1">	
							<option value="op1_1">ciudad 1</option>
						    <option value="op1_2">ciudad 2</option>
						
						</select>
						<select name="combo2" id="combo2">	
						</select>
					 <button type="submit" class="btn btn-default">Send</button>
                  </form>
						
</body>
</html>
