<?php
$from = $_POST['email'];
$subject = 'subject';
$message = 'Nombre: ' . $_POST["elegido"] . 
"\n". 'Mensaje:' . $_POST['combo1'].
"\n". 'Mensaje2:' . $_POST['combo2']

;

$headers = "From: ". $from . "\n";
mail ('jroelx@gmail.com', $subject, $message, $headers);
header('Location: thanks.html');
?>