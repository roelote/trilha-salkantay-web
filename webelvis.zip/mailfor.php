<?php
$from = $_POST['email'];
$subject = 'Reserva free walks';
$message = 'Nombre: ' . $_POST['name'] . 
"\n". 'E-mail: ' . $_POST['email']. 
"\n". 'Numero de Pasajeros:' . $_POST['size']. 
"\n". 'Ciudad:' . $_POST['country'].
"\n". 'Hora:' . $_POST['combo2'].
"\n". 'Fecha:' . $_POST['date'].
"\n". 'Mensaje:' . $_POST['data']

;

$headers = "From: ". $from . "\n";
mail ('jroelxx@gmail.com', $subject, $message, $headers);


// header('Location: thanks.html');
?>