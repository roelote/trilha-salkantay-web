<style>
  .form-control
  {
    font-size: 12px;
  }
</style>
<section class="confirmation mt-2">
  <div class="confirmation-text mt-3 mb-3">
 <h3  class="mt-1 mb-0" style="font-size: 1.6em;margin-bottom: 6px !important; text-align: center;"><span class="flag-icon flag-icon-pe"></span>
 Why to reserve with us? <span class="flag-icon flag-icon-pe"></span></h3>
    <div class="mb-0">
      <ul style="list-style: none;margin-left: 0px !important;padding-left: 10px;">
        <li><i class="fas fa-bullhorn"></i> 100% Indigenous Peruvian Organization.</li>
        <li><i class="fas fa-bullhorn"></i> It is completely FREE to book.</li>
        <li><i class="fas fa-bullhorn"></i> It takes less than 1 min.</li>
        <li><i class="fas fa-bullhorn"></i> Instant Confirmation.</li>
      </ul>
    </div>
  </div>
</section>





<div  id="cuadro-reservas">
    <section>
        <hgroup class="boooking">
            <span>Booking Now</span>
        </hgroup>

<div id="container">
  <div id="form" class="result">

  <?php
function dameURL(){
$url="http://".$_SERVER['HTTP_HOST'].":".$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];
return $url;
}
$urlweb=dameURL();

$resultado = substr($urlweb, 39);
$nombretour=str_replace("-"," ",$resultado);
$nombretour1=str_replace("/","-",$nombretour);

?>
      <form method="post" id="reg-form">

<!--                     <input type="hidden" name="nombretour" value=<?=$resultado?> />  -->
        
                   <div class="form-group top15 padding10">
                      <input type="text" name="fname" id="lname" placeholder="Your Name:" required data-error="Please enter your name" />
                    </div>
                    <div class="form-group padding10">
                      <input type="email" name="email" id="email" placeholder="write well your email" required data-error="Please enter your email" />
                    </div>

                  
                    
                       <div class="form-group padding10">
                               
                        <input type="text" id="datepicker" name="date" placeholder="Date" />
                      </div>
                    <!-- <div class="form-group padding10">
                      <input type="text" name="lname" id="lname" placeholder="Subject:" />
                    </div> -->
                    <div class="form-group padding10">
                     <div class="controls">
                            <select class="form-control" id="lname" name="lname">
                            <option value="" disabled selected>Size of Group</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                              <option>6</option>
                              <option>7</option>
                              <option>8</option>
                              <option>9</option>
                              <option>10</option>
                            </select>
                           </div>
              </div>

                     <div class="form-group padding10">
                      <select class="form-control" name="nombretour" id="nombretour" >
                         <option value="" disabled selected>Choose your free tour departure</option>
                          <option value="lima-10am">Free Tour Lima Centre 10am(pick up in Mrflres)</option>
                          <option value="lima-11am">Free Tour Lima Centre 11am</option>
                          <option value="lima-3pm">Free Tour Lima Centre 3pm</option>
                      </select>
                    </div>

                      <div class="form-group padding10">
                        <textarea class="form-control" name="phno" rows="3" placeholder="" id="comment" ></textarea>
                      </div> 

                    <div class="centrarsend"><button type="submit">Send</button></div>
        </form>
    </div>
</div>
        

<style type="text/css">

.confirmation-text {
    /*border: 1px solid;*/
    margin: 0 auto;
padding: 7px;

width: 95%;

color: #131515;

border-radius: 4px;

font-size: 13px;

background-color: #dedede;
}
.centrarsend button
{
  background-color: #fc0;
  color: #2f2d2d;
  border: 1px solid #a59898;
  font-weight: initial;
}

#cuadro-reservas
{
  margin-top: 5% !important;
}


input
{
  width:100%;
  height:35px;
  text-align:center;
  border:solid #cddcdc 2px;
  font-family:Verdana, Geneva, sans-serif;
  border-radius:3px;
}
button
{
  text-align:center;
  width:50%;
  height:35px;
  border:0;
  font-family:Verdana, Geneva, sans-serif;
  border-radius:3px;
  background:#00a2d1;
  color:#fff;
  font-weight:bolder;
  font-size:18px;
}
hr
{
  border:solid #cecece 1px;
}
#header
{
  width:100%;
  height:50px;
  background:#00a2d1;
  text-align:center;
}
#header label
{
  font-family:Verdana, Geneva, sans-serif;
  font-size:35px;
  color:#f9f9f9;
}
.form-control
{
  color:#4e4e4e;
}
a{
  color:#00a2d1;
  text-decoration:none;
}
</style>

</section>
</div>