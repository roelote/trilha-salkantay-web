<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>404 Not Found</title>
    <meta content="en" name="language" />
   <meta name="author" content="Free Walking Tours" />
    <!-- Bootstrap -->
    <link rel="icon" type="image/ico" href="/img/favicon.ico" />
    <link href="css/styles.css" rel="stylesheet">
    <style type="text/css">
        #error{padding:150px;text-align: center;}
        #suges{}
        h1{
        	font-size: 11px;
        	color: lightgrey;
        }
        header
        {
        	text-align: initial;
        }
        .error404{
        	background-color: rgba(0, 128, 128, 0.9);
		    background-image: url("img/fondo.png");
		    border-color: rgba(0, 0, 0, 0.2);
		    border-style: solid;
		    border-width: 1px 0 0;
		    box-shadow: 0 1px 0 rgba(255, 255, 255, 0.1) inset;
		    box-sizing: border-box;
		    float: left;
		    font-family: Verdana;
		    line-height: 1;
		    max-width: 1600px;
		    position: relative;
		    width: 100%;
		    height: 500px;
        }
        a {
    color: seashell;
   }
   #suges
   {
   	font-size: 12px;
   }
    </style>
  </head>
  <body>


    <div class="container">
      <header>
      		<h1>Free Walking Tours Peru ::<h1>
      </header>
    <div class="error404">
			<section>	     
		        <div id="error">
            <b>ERROR 404: Page Not Found</b><br /><br />
            There was an error loading the requested page, it is possible that this page not found or not available at this time. We show you some interesting links for easy navigation.<br /><br />
            <div id="suges">
                <a href="/" title=""><b>Home</b></a> -
                <a href="/lima/" title=""><b>Free Walking Tours Lima</b></a> -
                <a href="/miraflores/" title=""><b>Free Walking Tours Miraflores</b></a> -
                <a href="/arequipa/" title=""><b>Free Walking Tours Arequipa</b></a> -
                <a href="/cusco/" title=""><b>Free Walking Tours Cusco</b></a> -

            </div>
        </div>
		                  
		      </section>
  
  

		      <footer>
		          <!--   <img src="img/footer.JPG" style="width:100%" alt=""> -->

		       </footer>

    </div>

   
   
    
</body>


</html>