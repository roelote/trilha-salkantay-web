<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tour Peru | Lima | Cusco| Arequipa |Half Day City Tour & Tours on foot </title>
    <meta content="We are the ORIGINAL company who offers the finest Free Walking Tour Lima, Miraflores, Arequipa and Cusco, recommended by 1600+ reviews on TripAdvisor | in our Half Day City Tour, you will explore our cities on Foot therefore our City Tours Lima, Arequipa or our Tours Cusco on foot are enjoyable by most tourists | we also have tours in Barranco." name="description" />
    <meta content="Free Walking Tour Lima, Arequipa, Cusco, Miraflores, Barranco, free tour, city tour lima, city tour Arequipa, city tour Lima Miraflores, city tour Cusco, Lima half day city tour hop on hop off, city tours lima, tours lima, tours Cusco, tours Arequipa, half day city tour Cusco, Best Cusco city tour, Cusco day tours, Lima bus tours" name="keywords" />


        <link rel="alternate" hreflang="es" href="https://www.freewalkingtoursperu.com/es/" />
        <link rel="alternate" hreflang="en" href="https://www.freewalkingtoursperu.com">

       <meta name="author" content="Free Walking Tours" />
       <meta name="google-site-verification" content="iIbpJqCSXHlTp60GgHllMtYl_S7Sw5j_zHNDeIqsxXw" />
        <!-- Bootstrap -->
        <link rel="icon" type="image/ico" href="/img/favicon.ico" />
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link href="css/responsiveslides.css" rel="stylesheet">
        <link href="css/stylefwt.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />


        <link rel="apple-touch-icon" sizes="57x57" href="/favicons/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="/favicons/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="/favicons/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="/favicons/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="/favicons/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="/favicons/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="/favicons/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="/favicons/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="/favicons/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="/favicons/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/favicons/favicon-16x16.png">
        <link rel="manifest" href="/favicons/manifest.json">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content="/favicons/ms-icon-144x144.png">
        <meta name="theme-color" content="#ffffff">

        <!-- open graph -->
                <meta property="og:type" content="website">
                <meta property="og:title" content="Free Walking Tour Peru | Lima | Cusco| Arequipa |Half Day City Tour & Tours on foot ">
                <meta property="og:description" content="We are the ORIGINAL company who offers the finest Free Walking Tour Lima, Miraflores, Arequipa and Cusco, recommended by 1600+ reviews on TripAdvisor | in our Half Day City Tour, you will explore our cities on Foot therefore our City Tours Lima, Arequipa or our Tours Cusco on foot are enjoyable by most tourists | we also have tours in Barranco.">
                <meta property="og:url" content="https://www.freewalkingtoursperu.com/">
                <meta property="og:image" content="https://www.freewalkingtoursperu.com/img/free-walking-tour-cusco-10-am.jpg">
                <meta property="fb:app_id" content="FreeWalkingToursPeru">
                    <!-- twitter -->
                <meta name="twitter:card" content="summary_large_image">
                <meta name="twitter:site" content="@freetoursperu">
                <meta name="twitter:title" content="Free Walking Tour Peru | Lima | Cusco| Arequipa |Half Day City Tour & Tours on foot ">
                <meta name="twitter:description" content="We are the ORIGINAL company who offers the finest Free Walking Tour Lima, Miraflores, Arequipa and Cusco, recommended by 1600+ reviews on TripAdvisor | in our Half Day City Tour, you will explore our cities on Foot therefore our City Tours Lima, Arequipa or our Tours Cusco on foot are enjoyable by most tourists | we also have tours in Barranco.">
                <meta name="twitter:image" content="https://www.freewalkingtoursperu.com/img/free-walking-tour-cusco-10-am.jpg">
                <meta name="twitter:image:alt" content="Free walks peru">
        <!-- end open graph -->


  </head>
  <body>
  <script type="application/ld+json">
   
    {
          "@context" : "http://schema.org",
          "@type" : "LocalBusiness",
          "name" : "Free walking Tours Peru",
          "image" : "https://www.freewalkingtoursperu.com/img/maker-cusco.png",
          "telephone" : "+51 958745640",
          "email" : "info@freewalkingtoursperu.com",
          "address" : {
            "@type" : "PostalAddress",
            "streetAddress" : "Calle San Agustin N° 269",
            "addressLocality" : "Cusco",
            "addressCountry" : "Peru",
            "postalCode" : "08003"
          },
          "url" : "https://www.freewalkingtoursperu.com",
          "sameAs" : [
          "https://twitter.com/freetoursperu",
          "https://plus.google.com/+Inkanmilkyway-freewalkingtourscusco",
          "https://www.facebook.com/FreeWalkingToursPeru",
          "https://es.pinterest.com/freetoursperu/",        
          "https://www.youtube.com/channel/UCw96I0FBc-Bo3NY6ipUkHVg"
          ]
        }

    </script>

  <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- <div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center">NOTE:</h4>
            </div>
            <div class="modal-body">
        <p class="text-center">
          Note 28th of July<br>
Lima: Join us at 10am in Tarata street | Only on this day we will do Miraflores tour, we won't go to Lima centre, tours will in English only, keep in mind only on this day.<br>
No other meet up times pls<br>
Cusco & Arequipa: We are operating.
        </p>

                
            </div>
        </div>
    </div>
</div> -->

    <div class="container px-0">
      <header class="cabecera">
        <?php include('menu.php');?>
     <!--  <div class="idiomas">
        <span class="en"><a href="/"><img src="img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/"><img src="img/es.png" alt="ingles"></a></span>
      </div> -->

            <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-tour-cusco-centro.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-central-tours.jpg">
        <img src="../img/free-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/cusco-tour-lima.jpg">
        <img src="../img/tours-peru-free.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>
          

      </header>
    <div class="cuerpo">

      <section class="container izquierda">

                    <div class="margin0 home row col-lg-12 col-lg-12 col-xs-12">
                      <section class="content">

                      <h1>FREE WALKING CITY TOUR LIMA | MIRAFLORES | BARRANCO | AREQUIPA | CUSCO</h1>
                      <article>

                        <p>Thanks for taking your precious time to check our world-famous Original <strong>FREE Walking Tour concept</strong>(in Lima, Arequipa, Cusco and more) in the hands of Locally-born & Licensed Indigenous Tour Guides by InkanMilkyWay, with over 5 years in the Market, we are the first stop on each city for many tourists, delivering the best gratuity-based Model that puts the power back into the hands of the modern-day travelers | In our daily FREE city tour Lima, Cusco or Arequipa, <strong>History & Culture </strong>comes on Top(No Bars), this is what it makes different our company from the competitors therefore you can see our great reviews on TripAdvisor, Facebook or Google Maps, making our half day city tours on foot enjoyable, useful and memorable.</p>

                        <p><b>NOTE! </b>Whenever you book our free walking city tour in Peru, make sure you get to the correct meeting point and have the a decent authorized Tour Guide, if you cannot attend your free tour, let us know so that your tour guide doesn’t waste his/her precious time waiting for you.</p>

                        
<br>
                        <h2 class="text-center"><b>FREE WALKING CITY TOUR LIMA</b></h2>
                        
                       <h4 style="text-align: center;">Best <a href="https://www.freewalkingtoursperu.com/lima/">free walking tour</a> organized by:&nbsp;Indigenous Tour Guides | Inkan Milky Way Tours Lima</h4>

                       <p>Coming to Lima city? Already in Lima city? Then join our best Lima free walking city tour 100% cultural focused tours by foot, we have guided groups in Spanish &amp; English, you choose your language | Our Lima half day city tour on foot &amp; donation basis will give you a great historical introduction to the Peruvian capital city (our tours on foot last 2.5 to 3.5 hours), this free tour Lima takes place mainly in Lima historical centre, if you are in Miraflores or Barranco, no worries we have a great option for you so that you can get picked and take the bus and get to Lima centre, so that you enjoy the most our city Tours Lima | We have fantastic <strong>REVIEWS</strong> on <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294316-d14918493-Reviews-Inkan_Milky_Way_Tours_Lima-Lima_Lima_Region.html">TripAdvisor</a>, <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.028598,16z/data=!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598?hl=es-US">Google Maps starting in Miraflores</a> or <a href="https://www.google.com/maps/place/Inkan+Milky+Way,+Free+Walking+Tour+Lima/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-US">Google Maps starting in Lima center</a>, still doubting on our service? Then check our reviews on <a href="https://www.facebook.com/limafreewalkingtour/">Facebook</a> and Make a Wise Decision&iexcl; Don&rsquo;t gamble with your precious time, trust a company with over 300+ testimonials.</p>
<br>
                        <h2 class="text-center"><b>FREE WALKING CITY TOUR AREQUIPA</b></h2>
                        
                        <h4 style="text-align: center;">Premium <a href="https://www.freewalkingtoursperu.com/arequipa/">free walking tour</a> operated by: Indigenous Tour Guides |&nbsp;Free Tour Downtown Arequipa</h4>

                        <p>While in Peru you can&rsquo;t miss this outstanding city, make the best of your journey to Arequipa by joining our free walking city tour in Arequipa, recommended by more than 500&nbsp;<a href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">reviewers on tripadvisor</a>. If you are looking for a half day city tour, join our 2.5 hours tour in Arequipa, we priorize this city&acute;s history, our itinerary will take you to the must-do attractions guided by professional tour guides who will assure you a great Free city tour Arequipa.</p>

                        <br>
                       <h2 class="text-center"><b>FREE WALKING CITY TOUR CUSCO</b></h2>

                      <h4 style="text-align: center;">Ultimate <a href="https://www.freewalkingtoursperu.com/cusco/">free walking tour</a> operated by: Indigenous Tour Guides |&nbsp;Inkan Milky Way Tours Cusco</h4>

                      <p>Explore Cusco city, the heart of the Inka Empire on foot within the historical centre, in our free walking tour Cusco you will have the opportunity to explore Must-Do attractions like Mercado San Pedro or Inca Palace remains, most tourists choose the Classic half day city tour Cusco, then why should you choose our free tour? The reason is very simple: Quality, it is a walking tour where tour guides work on donation basis only which will be given in direct proportion to the quality of the tour as simple as that | Our Free city tour Cusco is peppered with History &amp; Culture only as they are in other cities (we don&rsquo;t waste your time on preparing drinks), we deliver relevant explanation about the Inka history therefore our non-classic half day city tour is enjoyable (Our Free city tour last 2.5 hours) | We are recommended by 1400&nbsp;<a href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html#REVIEWS">reviews on tripadvisor</a>, reviewed on <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.9822977,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109+">Google Maps</a> and <a href="https://www.facebook.com/freewalkingtourscusco">Facebook</a>, and moreover we are mentioned by very well-known Travel Books:&nbsp;<a href="https://books.google.com.pe/books?id=yE40DwAAQBAJ&amp;pg=PT364&amp;dq=Stefan+Loose+inkanmilkyway.com+cusco&amp;hl=es-419&amp;sa=X&amp;ved=0ahUKEwjq-Yy36LDaAhWG11MKHYYYAuMQ6AEIJjAA#v=onepage&amp;q=Stefan%20Loose%20inkanmilkyway.com%20cusco&amp;f=false">Stefan Loose</a>&nbsp;and&nbsp;<a href="http://www.routard.com/guide/code_dest/perou.htm">Le Routard</a>.</p>


                      </article>

                      <ul class="redes_sociales">
                        <li><a href="https://es.pinterest.com/freetoursperu/" target="_blank"><i class="fa fa-pinterest-square" aria-hidden="true"></i></a></li>
                        <li><a href="https://www.facebook.com/FreeWalkingToursPeru" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></li>    
                        <li><a href="https://www.youtube.com/channel/UCw96I0FBc-Bo3NY6ipUkHVg" target="_blank"><i class="fa fa-youtube-square" aria-hidden="true"></i></a></li>
                        <li><a href="https://twitter.com/freetoursperu" target="_blank"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
                        <li><a href="https://plus.google.com/+Inkanmilkyway-freewalkingtourscusco" target="_blank"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>

                            
                        </ul>
                    </section>

                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-lg-6 col-sm-6 col-xs-12">

                                 <div class="fotofwt a-fijo">
                                   
                                        <div class="center positiontitleimg"> 
                                         <a href="/lima/">
                                          <h2><span class="tours-time limancolor"><span class="rojo">Free Walking City Tour</span> Lima</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                          <div id="myCarousel2" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-lima-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                            
                                            </div>
                                            <!-- Left and right controls -->
                                            <a class="left carousel-control" href="#myCarousel2" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel2" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                               <!-- <img class="efectoimg"src="img/t2.jpg"> -->
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/lima/">
                                               <span class="time"><span class="days">Mon to Sat</span>10AM & 11AM & 3PM</span> 
                                            </a>
                                          </div>
                                       
                                </div>
                            
                               
                        
                                  <div class="fotofwt a-fijo">
                                  
                                       <div class="center positiontitleimg"> 
                                         <a href="/miraflores/">
                                          <h2><span class="tours-time limacolor"><span class="rojo">Free Walking City Tour</span> Miraflores</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                          <div id="myCarousel3" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-miraflores-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                            
                                            </div>
                                            <a class="left carousel-control" href="#myCarousel3" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel3" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                             <!--   <img class="efectoimg"src="img/t3.jpg"> -->
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/miraflores/">
                                               <span class="time"><span class="days">Dayly Walks</span>4:15pm</span> 
                                            </a>
                                          </div>
                                </div>
                     </div>

                      <div class="col-lg-6 col-lg-6 col-sm-6 col-xs-12">
                                <div class="fotofwt a-fijo">
                                           <div class="center positiontitleimg"> 
                                         <a href="/arequipa/">
                                          <h2><span class="tours-time arequipacolor"><span class="rojo">Free Walking City Tour</span> Arequipa</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                               <div id="myCarousel4" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-arequipa-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                            </div>
                                            <a class="left carousel-control" href="#myCarousel4" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel4" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/arequipa/">
                                               <span class="time"><span class="days">Dayly Walks</span>10am & 3pm</span> 
                                            </a>
                                          </div>
                                          
                                </div>

                                 <div class="fotofwt a-fijo">
                                         <div class="center positiontitleimg"> 
                                         <a href="/cusco/">
                                          <h2><span class="tours-time cuscocolor"><span class="rojo">Free Walking City Tour</span> Cusco</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                            <div id="myCarousel1" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-cusco-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                            </div>
                                            <a class="left carousel-control" href="#myCarousel1" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel1" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/cusco/">
                                                
                                                <span class="time"><span class="days dayly">Walks Mon to Sat</span>10am & 1:00pm & 3.30pm
                                                <span class="days dayly">on Sun</span>
                                                10:00am</span> 
                                            </a>
                                          </div>
                                </div>
                        
                                
                     </div>
            </div>
      </section>
      <aside class="derecha">
<div class="trip-ciudades">
 

  <a target="_blank" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html"><img src="img/trip-advisor-arequipa.png" alt="trip-advisor-arequipa"></a>
  <a target="_blank" href="https://www.tripadvisor.com.pe/Attraction_Review-g294316-d14918493-Reviews-Inkan_Milky_Way_Tours_Lima-Lima_Lima_Region.html"><img src="img/trip-advisor-lima-miraflores.png" alt="trip-advisor-lima-miraflores"></a>
  <a target="_blank" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Free_Tours_by_Foot_Cusco-Cusco_Cusco_Region.html"><img src="img/trip-advisor-cusco.png" alt="trip-advisor-cusco"></a>

</div>

<div class="facebookpubli">

  <div class="fb-page" 
  data-href="https://www.facebook.com/FreeWalkingToursPeru"
  data-width="380" 
  data-hide-cover="false"
  data-show-facepile="false" 
  data-show-posts="false"></div>
  
</div>


<div class="blog-wp">

         <section id="blog-ftw" class="cuadro-contenedor cuadro-texto">
                    <div>
                    <a href="/blog/">
                        <h3 class="title titlepeq"><span>Blog</span> Free Walks Peru </h3>
                      </a> 
                    </div>
                   <?php
                include('blog/wp-load.php');

                $recent_posts = wp_get_recent_posts(array(
                'numberposts' => 2,
                'post_status' => 'publish'
                ));
                echo '';
                foreach($recent_posts as $single_post) {?>
                <?php $j++;?>
                                <div class="contenido-blog">
                                      <a href="<?=get_permalink($single_post['ID']) ?> ">
                                            <h4 class="titulo-blog">
                                            <?php echo $single_post['post_title'];?>                                            
                                            </h4> </a>
                                            <div class="foto-blog">
                                            <?php 
                                          $get_post_images = get_attached_media( 'image', $single_post['ID'] );
                                          $get_post_images = array_shift( $get_post_images );
                                          $first_image_url = $get_post_images->guid;
                                          ?>    

                                          <img src="<?php echo $first_image_url; ?>" alt="blog fwt" />
                                            </div>
                                            <span class="fecha-blog">Posted on <?php echo get_the_time('d/F', $single_post['ID']); ?></span>
                </div>
                <?php }?> 
           </section> 

</div>


  
      </aside>

   <div class="banners">
       <img src="img/imgfooter.jpg" alt="publicidad free tours peru">
    </div>


    </div>

   <?php include('footer.php');?>
</div>
    <script src="https://code.jquery.com/jquery-2.2.3.min.js"></script>    
    <script src="js/script.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- <script type="text/javascript">
  $(document).ready(function(){
    $("#myModal").modal('show');
  });
</script>
 -->
    <script src="js/responsiveslides.min.js"></script>
        <script>
        // You can also use "$(window).load(function() {"
        $(function () {
          // Slideshow 1
            $("#slider2").responsiveSlides({
              maxwidth: 2600,
              speed: 1
            });
        });
    </script>


  </body>


</html>