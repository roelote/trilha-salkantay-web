<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tours Peru</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/responsiveslides.css" rel="stylesheet">
    <link href="css/stylefwt.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">


   
  </head>
  <body>

    <div id="fb-root"></div>

    <div class="container">
      <header class="cabecera">
                        <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                <!-- Slideshow 1 -->
                      <ul class="rslides" id="slider2">
                        <li><img src="img/fondo1.jpg" alt="free walking tours lima"> <div class="texto-slider"><img alt="Feel Free Tours" src="img/chalecos.png" class="img-responsive logo">
                        <h2 class="h2slider"> Free Tours by Foot Lima - FTF Lima </h2> 
                        <h2 class="contenido-texts">Hi Dear Lima Walkers, we do have two Free Walking Tours in Lima every day at 10:30am&11:30am, Meet us at Ovalo Miraflores by 10:30 and at Plaza de Armas(by the fountain) by 11:30am, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused. </h2></div></li>

                        <li><img src="img/fondo2.jpg" alt="free walking tours miraflores"> <div class="texto-slider"><img alt="Feel Free Tours" src="img/chalecos.png" class="img-responsive logo">
                        <h2 class="h2slider textomaspequenio">Free Tours by Foot Miraflores - FTF Miraflores </h2> 
                        <h2 class="contenido-texts">Hi Dear Miraflores Walkers, we do have one Free Walking Tour in Miraflores District(Lima) every day at 04:15pm, Meet us at Ovalo Miraflores ONLY, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused. </h2></div></li>

                        <li><img src="img/fondo2.jpg" alt="free walking tours arequipa"> <div class="texto-slider"><img alt="Feel Free Tours" src="img/chalecos.png" class="img-responsive logo">
                        <h2 class="h2slider textomaspequenio">Free Tours by Foot Arequipa - FTF Arequipa  </h2> 
                        <h2 class="contenido-texts">Hi Dear Arequipa Walkers, we do have two Free Walking Tours in Arequipa every day at 10:00am&3:00pm, for all free tours meet us at Santa Catalina street #204-Choco Factory ONLY, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused. </h2></div></li>

                        <li><img src="img/fondo2.jpg" alt="free walking tours cusco"> <div class="texto-slider"><img alt="Feel Free Tours" src="img/chalecos.png" class="img-responsive logo">
                        <h2 class="h2slider">Free Tours by Foot Cusco - FTF Cusco  </h2> 
                        <h2 class="contenido-texts">Hi Dear Cusco Walkers, we do have three Free Walking Tours in Cusco from Mon to Sat at 10:00am&1:00pm&3:30pm, On Sun at 12:20pm only. For all free tours meet us at Plaza Regocijo ONLY, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused.  </h2></div></li>
                      </ul>
                </div>
            </div>     


            <?php include('menu.php');?>
      </header>

    <div class="cuerpo">

      <section class="container izquierda">
            <div class="row col-lg-12 col-lg-12 col-xs-12">
              <h1>BOOKING NOW</h1>
                <div class="formularioc">


            



                </div>
            </div>


            <!-- /.row -->
      </section>

    </br>
    </br>

      <aside class="derecha">
        <h4 class="hh4"><a href="meeting-point.php">WHY TO BOOK WITH US?</a></h4>
      <form role="form" id="contactForm" class="contact-form" data-toggle="validator" class="shake">
              <div class="form-group">
                <div class="controls">
                  <input type="text" id="name" class="form-control" placeholder="Name" required data-error="Please enter your name">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <input type="email" class="email form-control" id="email" placeholder="Email" required data-error="Please enter your email">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <input type="text" id="msg_subject" class="form-control" placeholder="Subject" required data-error="Please enter your message subject">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <textarea id="message" rows="7" placeholder="Massage" class="form-control" required data-error="Write your message"></textarea>
                  <div class="help-block with-errors"></div>
                </div>  
              </div>

              <button type="submit" id="submit" class="btn btn-success"></i> Send Message</button>
              
              <div id="msgSubmit" class="h3 text-center hidden"></div> 
              <div class="clearfix"></div>   

            </form>   



       
      </aside>

       <?php include('footer.php');?>

    </div>

   
    <script src="js/jquery-min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/responsiveslides.min.js"></script>
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
     <script  src="js/form-validator.min.js"></script>  
    <script  src="js/contact-form-script.js"></script>




  <!-- mail -->


    <script>
    $(function () {
        $("#slider2").responsiveSlides({
          maxwidth: 1600,
          speed: 500
        });
    });
   </script>

      <script>
      $(document).ready(function(){
        // Estos son los parametros para el pimer combo
         $("#combo1").change(function () {
            $("#combo1 option:selected").each(function () {
              elegido=$(this).val();
              $.post("combo1.php", { elegido: elegido }, function(data){
              $("#combo2").html(data);
              $("#combo3").html("");
            });     
              });
         })
      });
      </script>

  <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>

  </body>


</html>
