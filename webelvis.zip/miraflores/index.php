<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tour Miraflores | Free Tour Miraflores</title>
    <meta content="Free Walking Tour Miraflores by Inkan Milky Way Tours Lima, We offer Miraflores Free Walking Tours based on 100% history & modernity." name="description" />
    <meta content="free walking tour miraflores, free walks, city tours, miraflores walking tour map, free walking tour barranco, free tour barranco" name="keywords" />
    <meta content="en" name="language" />
   <meta name="author" content="Free Walking Tours" />

    <!-- Bootstrap -->
      <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
       <link href="../css/stylefwt.css" rel="stylesheet">
    
  </head>
  <body>

<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

    <div id="fb-root"></div>
    <div class="container">
      <header class="cabecera">
        <div class="idiomas">
        <span class="en"><a href="/miraflores/"><img src="../img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/miraflores/"><img src="../img/es.png" alt="ingles"></a></span>
      </div>
           <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                      <ul class="rslides" id="slider2">
                        <li><img src="../img/free-tours-miraflores.jpg" alt="free walking tours lima"></li>
                      </ul>
                </div>
            </div> 

               <?php include('../menu.php');?>
      </header>

    <div class="cuerpo">

      <section class="container izquierda">
       <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Home</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Miraflores</strong>
                                  </div>
                  </div>
            <div class="row col-lg-12 col-lg-12 col-xs-12">
              <h1>FREE WALKING TOUR IN MIRAFLORES DISTRICT</h1>

             <p class="text-danger">For the mean time our free walking tours FOR Miraflores district are suspended until further notice (Keep in mind! We mean Miraflores free tours, NOT Lima free tours).</p>
         <p class="text-danger">We say it once again, ONLY our free tours FOR Miraflores district are suspended, However you can always take and join our <a href="https://www.freewalkingtoursperu.com/lima/">Free Walking Tours FOR Lima downtown</a>. For Lima downtown walking tour you can join us either in <a href="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-from-miraflores">Miraflores district(PICK UP only)</a> or in <a href="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-downtown">downtown Lima</a>.</p>

         <p>
           Join our unique free Walking Tour in Miraflores district, we start at 04:30pm, we will walk through the most modern area of this district. We will talk about the influence of the terrorism in Peru back in the 80’s and 90’s.
         </p>

             <!-- <p style="font-weight: 600; font-size:14px" class="text-danger">For the meantime we are NOT operating Miraflores free walks until further notice.</p>
<p style="font-weight: 600; font-size:14px" class="text-danger">Por el momento NO estamos operando Miraflores free walks hasta un nuevo aviso.</p> -->

           
            </div>

            <div class="row">

                                     <div class="ciudadfwt">

                                                 <div class="center"> 
                                                  <a href="free-walking-tour-miraflores-4-15-pm"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking Tour Miraflores at 4.15pm</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/free-walking-tour-miraflores-4-15-pm.jpg">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <span class="negrita-span"><strong>Tour Type:</strong></span>Culture & Modernity. <br>
                                                    <span class="negrita-span"><strong>Good For:</strong></span> All hikers including families with children.<br>
                                                    <span class="negrita-span"><strong>Duration:</strong></span>3 hours to 3.5 hours.<br>
                                                    <span class="negrita-span"><strong>Difficulty:</strong></span> None, flat walking 1.6 km – 1 mi.<br>
                                                    <span class="negrita-span"><strong>Meeting Point:</strong></span> <br>
                                                    <span class="negrita-span"><strong>Look for:</strong></span> <br>
                                                    <span class="negrita-span"><strong>Description-more info:</strong> <a class="click-here" href="free-walking-tour-miraflores-4-15-pm">Click here</a></span>
                                                    <div>
                                                        <div class="porciento50">
                                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Enquiry</button>

                                                   
                                                        <div class="modal fade" id="myModal" role="dialog">
                                                          <div class="modal-dialog modal-sm">
                                                            <div class="modal-content">
                                                              <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                <h4 class="modal-title">Enquiry Form</h4>
                                                              </div>
                                                              <div class="modal-body">
                                                                 <?php include('../enquiry.php');?> 
                                                              </div>
                                                              
                                                            </div>
                                                          </div>
                                                        </div>
                                                       
                                                        </div>
                                                        <div class="porciento50"><a href="/booking/"><button type="button" class="btn btn-primary">Book Now</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>

                    

                                  </div>
                    <!--     <div class="mapasciudad mirafloresmapalado">
                  
                       
                          <div class="row">

                      <div class="col-lg-12">
                          
                              <div class="col-lg-12 col-md-12 col-xs-12">
                              <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="Free Walking Tour Miraflores 4.15pm " data-caption="free walking cusco" data-image="../img/miraflores-walks.png" data-target="#image-gallery">
                                  <img class="img-responsive" src="../img/miraflores-walks.png" alt="Another alt text">
                              </a>
                  </div>


                  <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <div class="modal-dialogo">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span><span class="sr-only">Close</span></button>
                                  <h4 class="modal-title" id="image-gallery-title"></h4>
                              </div>
                              <div class="modal-body">
                                  <img id="image-gallery-image" class="img-responsive" src="">
                              </div>
                              
                          </div>
                      </div>
                  </div>


                </div>
           </div>
                
                
                       </div>   -->


                </div>
      </section>
    <br>
    <br>


      <aside class="derecha">
       
       <div class="facebookpubli">


  <div class="fb-page" 
  data-href="https://www.facebook.com/FTFWALKINGTOURSLIMA/"
  data-width="380" 
  data-hide-cover="false"
  data-show-facepile="false" 
  data-show-posts="false"></div>
  
</div>
<div class="blogpage">

</div>
       
      </aside>

<!-- <div class="maps-c">
       <div id="map" style="width:100%;height:500px;"></div>
       <div class="contenedormap"></div>
     </div> -->

   
    <div class="banners">
       <img src="../img/imgfooter.jpg" alt="">
    </div>
  <?php include('../footer.php');?>


</div>

   
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
    <script src="../js/mapa-lima.js"></script>

<script language="javascript">
$(document).ready(function() {
    $().ajaxStart(function() {
        $('#loading').show();
        $('#result').hide();
    }).ajaxStop(function() {
        $('#loading').hide();
        $('#result').fadeIn('slow');
    });
    $('#form, #fat, #fo3').submit(function() {
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function(data) {
                $('#result').html(data);

            }
        })
        
        return false;
    }); 
})  
</script>


    <script>
    // You can also use "$(window).load(function() {"
    $(function () {
      // Slideshow 1
        $("#slider2").responsiveSlides({
          maxwidth: 1600,
          speed: 500
        });
    });
</script>

<script>
  
 $(document).ready(function(){

    loadGallery(true, 'a.thumbnail');

    //This function disables buttons when needed
    function disableButtons(counter_max, counter_current){
        $('#show-previous-image, #show-next-image').show();
        if(counter_max == counter_current){
            $('#show-next-image').hide();
        } else if (counter_current == 1){
            $('#show-previous-image').hide();
        }
    }

    /**
     *
     * @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
     * @param setClickAttr  Sets the attribute for the click handler.
     */

    function loadGallery(setIDs, setClickAttr){
        var current_image,
            selector,
            counter = 0;

        $('#show-next-image, #show-previous-image').click(function(){
            if($(this).attr('id') == 'show-previous-image'){
                current_image--;
            } else {
                current_image++;
            }

            selector = $('[data-image-id="' + current_image + '"]');
            updateGallery(selector);
        });

        function updateGallery(selector) {
            var $sel = selector;
            current_image = $sel.data('image-id');
            $('#image-gallery-caption').text($sel.data('caption'));
            $('#image-gallery-title').text($sel.data('title'));
            $('#image-gallery-image').attr('src', $sel.data('image'));
            disableButtons(counter, $sel.data('image-id'));
        }

        if(setIDs == true){
            $('[data-image-id]').each(function(){
                counter++;
                $(this).attr('data-image-id',counter);
            });
        }
        $(setClickAttr).on('click',function(){
            updateGallery($(this));
        });
    }
});
</script>

  </body>


</html>