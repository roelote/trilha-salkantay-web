<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>Free Walking Tour Miraflores 4:15 pm | Tours by Foot Miraflores</title>
    <meta content="Gather us everyday at 04:15pm at PARQUE KENNEDY, Look for the FTF logo on the Yellow Vests. Our tours include History, Modernity, Culture and Inquires" name="description" />
    <meta content="free walking tour miraflores, free walks, city tours" name="keywords" />
    <meta content="en" name="language" />

    <!-- Bootstrap -->
      <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">
     
  <!--   estilos slider pekeño -->
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">



  </head>
  <body>

    <div id="fb-root"></div>

    <div class="container">
      <header class="cabecera">
     <div class="idiomas">
        <span class="en"><a href="/"><img src="../img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/"><img src="../img/es.png" alt="ingles"></a></span>
      </div>

       <div class="slider">
            <div id="wrappers" class="relativo over-effect">
          <!-- Slideshow 1 -->
                <ul class="rslides" id="slider2">

                  <li><img src="../img/free-tours-miraflores.jpg" alt="free walking tours peru"> </li>
   
                </ul>
          </div>
      </div>
            <?php include('../menu.php');?>
      </header>

 
    <div class="cuerpo">

      <section class="container izquierda">
       <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Home</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/lima/" itemprop="url" title="miraflores" class="linkgeneral">
                                      <span itemprop="title">Miraflores</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Free Walking Tour Miraflores at 4:15 pm</strong>
                                  </div>
                  </div>

        <section class="cuadro-texto cuadro-contenedor">

          <h1>Free Walking Tour Miraflores 4:15 pm</h1>

            <div class="slidertours">
              <div id="demo">
                <div class="container">
                  <div class="row">
                    <div class="span12">

                      <div id="owl-demo" class="owl-carousel">
                        <div class="item"><img src="../img/free-tour-miraflores-01.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-tour-miraflores-02.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-tour-miraflores-03.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-tour-miraflores-04.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-tour-miraflores-05.jpg" alt="Owl Image"></div>

                      </div>
                      
                    </div>
                  </div>
                </div>
           </div>

          </div>

          <div class="wecolmetour">
         <p class="text-danger">For the mean time our free walking tours FOR Miraflores district are suspended until further notice (Keep in mind! We mean Miraflores free tours, NOT Lima free tours).</p>
        <p class="text-danger">We say it once again, ONLY our free tours FOR Miraflores district are suspended, However you can always take and join our <a href="https://www.freewalkingtoursperu.com/lima/">Free Walking Tours FOR Lima downtown</a>. For Lima downtown walking tour you can join us either in <a href="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-from-miraflores">Miraflores district(PICK UP only)</a> or in <a href="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-downtown">downtown Lima</a>.</p>
        <p>Get to know why this District is called so (Miraflores, &ldquo;Watch the Flowers&rdquo; although originally called &ldquo;San Miguel de Miraflores&rdquo;) and learn why this is the most important one, from the Financial Viewpoint, our Financial Center National wide, Join our Miraflores walking tour every day.</p>
        <p>A highly entertaining&nbsp;<strong>Free Tour Downtown Miraflores</strong>&nbsp;which is combining Lima&acute;s Colonial Aristocratic background, modernity and parks such us &ldquo;Parque Del Amor&rdquo; (Love Park by the sea) with spectacular views of Pacific Ocean and the Green Coast &ldquo;La Costa Verde&rdquo;, toping it with Larcomar, best spot for night photos.</p>

          </div>

          <div id="verticalTab">
                <ul class="resp-tabs-list">
                <li> <span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> ITINERARY</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> INCLUSIONS</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> REMARKS & FAQ’S</li>
                </ul>
                <div class="resp-tabs-container">
                    <div>
                    <h2 class="h2-tours-detalle"> Spots we are going to visit: </h2> 

                   <p class="texto-ciudades">This itinerary is changeable-flexible as per many reasons (festivals, strikes, holydays, high season & low season, car traffics, rainy season, etc.) it can even be cancelled but it barely happens if you are a BLOGGER, TOP RATED CRITICIZER ON TRIPAVISOR, LONELY PLANET AGENT or JUST A PERSON THAT LOVES WRITING HIS/HER TRAVEL EXPERIENCES, PLEASE HAVE A LOOK TO OUR POLICIES, that way you avoid MISSUNDERSTANDINGS  NONETHELESS we will DO OUR BEST so that you can HAVE A GREAT EXPERIENCE with us. Thank you so much.</p>

                         <ul style="list-style-type: none" class="bi-ciudades">

                        <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span></li>
                        <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Secrets of Miraflores</li>
                        <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Cats Park, get to see this unique park, where you are going to see lots of abandoned pussy cats.</li>
                        <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Terrorism of 80 in Tarata, The communist party use to be called THE SHINING PATH(SENDERO LUMINOSO-ABIMAEL GUZMAN,  Former Chief in charge of this Terrorist organization)</li>
                        <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>The Ricardo Palma Cultural Center, the most modern in Lima</li>
                        <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>The extremely romantic Park of Love, take a pic with the Pacific Sea as background, some talking about phenomenon “El Niño"</li>
                        <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>The Larcomar, built on the cliff and get to see amazing genuine brands at very fair prices (Note, this is not a shopping tour, we olny pass by this place so that you can enjoy modernity of Peru since that this Tour about)</li>
                      
                         </ul>
                       <h2 class="h2-tours-detalle"> This tour includes also:</h2> 
                         <ul style="list-style-type: none">
                           
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Local Guide Perspective.</li>
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Reliable recommendations to have dinner at original Peruvian Restaurants of Miraflores.</li>
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>FREE tickets to the best Discos of Miraflores and Barranco.</li>
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Tasting Peruvian chocolates, an innovative cocktail  Chocopisco, and 100% Aguaymanto (Golden Cherrys) jam or passion fruit (Maracuya).</li>
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Different surprises every day and much more</li>

                         </ul>
                    </div>
                              <div>
                                <div class="imagesit">
                                <img src="../img/ico-miraflores-4-15pm/modernity-free-walks-miraflores.png" alt="modernity-free-walks-miraflores">
                                <img src="../img/ico-miraflores-4-15pm/panoramic-views-free-walks-miraflores.png" alt="panoramic-views-free-walks-miraflores">
                                <img src="../img/ico-miraflores-4-15pm/pacific-sea-free-walks-miraflores.png" alt="pacific-sea-free-walks-miraflores">
                                <img src="../img/ico-miraflores-4-15pm/history-free-walks-lima.png" alt="history-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/travel-tips-free-walks-lima.png" alt="travel-tips-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/acomodation-tips-free-walks-lima.png" alt="acomodation-tips-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/geo-orientation-free-walks-lima.png" alt="geo-orientation-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/inquires-free-walks-lima.png" alt="inquires-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/lisenced-company-free-walks-lima.png" alt="lisenced-company-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/pisco-sours-free-walks-lima.png" alt="pisco-sours-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/profesional-guides-free-walks-lima.png" alt="profesional-guides-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/chocolate-tastings-free-walks-lima.png" alt="chocolate-tastings-free-walks-lima">
                                
                                   

                              </div>
                              </div>
                    <div>
                    <ul style="list-style-type: none">
                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Where do I meet my tour guide? (<a href="#" class="alternar-respuesta">View</a>)</p>
                   <!--  <p class="respuesta" style="display:none">Meet us at PARQUE KENNEDY right in front of VIRGEN MILAGROSA CHURCH. Please use our Google Lima City Map for more directions to the tour starting point.</p> -->
                  </li>

                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>How to recognize our Tour Guides at the Meeting Point in Miraflores District?(<a href="#" class="alternar-respuesta">View</a>)</p>
                    <!-- <p class="respuesta" style="display:none">LOOK FOR THE “FTF” LOGO ON THE YELLOW VESTS, DO NOT GET CONFUSED.
                    </p> -->
                  </li>

                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Where does the free tour end up?(<a href="#" class="alternar-respuesta">View</a>)</p>
                    <!-- <p class="respuesta" style="display:none">This free tour ends up near larcomar alongside the cliff nex to the pacific ocean.</p> --></li>

                     <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>How much should I pay?(<a href="#" class="alternar-respuesta">View</a>)</p>
                   <!--  <p class="respuesta" style="display:none">All our free tours are financially supported by your DECENT TIPS, this is OUR POLICY, if you don’t agree, you can always choose other options, everybody is invited to take part on our free tours but tourists got the last word.<br>

                    DECENT TIPS means NO COINS, if you want to tip 2 soles or 5 soles please this is not your cup of tea, all decent tips is 10 to 15 soles minimum PER PERSON, this is our POLICY remember that, only our policy, our terms, nothing personal.<br>

                    <b>* We do know that free tours philosophy worldwide is “pay what you like as much as how you love our free walks” on top of that they are voluntary, HOWEVER most tourists while traveling in South America do not tip decently</b> (this is most likely because they think that we are underdeveloping countries from the third world and 1 dollar means a lot because of the exchange rate to local currency which not true at all, cost of living either in Peru or in Brazil has increased very much the last 20 years), <b>many of those Attendees tip COINS such as quarter dollars or 5 soles; We cannot assure you the quality of our service based on some COINS, because good to great tour guides are not cheap to hire, so your nice tips are their salary on top of that they have to share it because we are a team, apart from that our tour guides are family men, they also eat.</b><br>

                    *This is a PRIVATE INICIATIVE, we do not have sponsoring or support from nobody not even from the Government.
                    </p> --></li>

                     <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Things to be brought(<a href="#" class="alternar-respuesta">View</a>)</p>
                    <!-- <p class="respuesta" style="display:none">We kindly ask our tourists to bring or to put on the following items:<br>
                      - Always WARM CLOTHES<br>
                      - Sun Block Lotions<br>
                      - Sun Glasses<br>
                      - Huts – Cups<br>
                      - Bottles of Water<br>
                      - Walking Shoes<br>
                      - BIG SMILE and WILLINGNESS TO WALK<br>
                    </p> --></li>

                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Available Languages(<a href="#" class="alternar-respuesta">View</a>)</p>
                   <!--  <p class="respuesta" style="display:none"> English and Spanish, for both languages we need a considerable amount of tourists, so that we can make a unilingual guided group, otherwise will be in English only, 07 tourists minimum.</p> --></li>
 
                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>When is this happening? (<a href="#" class="alternar-respuesta">View</a>)</p>
                    <!-- <p class="respuesta" style="display:none">@ 04:15 pm every day from Mon to Sun. </p> --></li>
                     
                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>How long does it last?(<a href="#" class="alternar-respuesta">View</a>)</p>
                   <!--  <p class="respuesta" style="display:none">All our Miraflores Walking Tours last about 3 hours and to even 3.5 hours, approximately 1.6 km – 1 mi. in distance, flat walking.</p> --></li>


                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Minimum walkers required to run the tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
                   <!--  <p class="respuesta" style="display:none">07 tourists, otherwise will be cancelled, for more info go to: OUR POLICIES.<br>
                    A todos nuestros pasajeros de habla hispana, les pedimos muy encarecidamente que se requiere de al menos 10 pasajeros para ser realizado y hacer un grupo unilingüe o bilingüe, caso contrario el guiado será solamente en Ingles; Esto es debido a que es MUY DIFICIL ENCONTRAR un guía que pueda TRABAJAR A LA GORRA y hacer un BUEN SERVICIO, para más informes sobre nuestras políticas vaya a: OUR POLICIES (NUESTRAS POLITICAS) Muchas Gracias.
                    </p> --></li>

                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Maximum walkers allowed per group?(<a href="#" class="alternar-respuesta">View</a>)</p>
                    <!-- <p class="respuesta" style="display:none"> 20 tourists either for English or Spanish, for more info go to: OUR POLICIES
</p> --></li>

                    <a href="#" class="alternar-todo"id="alternar-todo">Show and hide all answers</a>

                    </ul>
                    </div>
                </div>
            </div>

                <br />
                <div style="height: 30px; clear: both"></div>
          
          
         </section>

      </section>

      <aside class="derecha">
     <?php include('../cuadro-reservas-miraflores.php');?>
     <div class="blogpage">

</div>
      <div class="mapadetalle">
        <h2> <span class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span>Click The Map to See</h2>
       <!--  <div class="centrarmapa"><img id="myImg" src="../img/miraflores-walks.png" alt="Free Walking Tour Miraflores 4:15 pm" width="300" height="200"></div> -->

        <!-- The Modal -->
        <div id="myModal" class="modal">
          <span class="close">×</span>
          <img class="modal-content" id="img01" alt="modal imagen mapa">
          <div id="caption"></div>
        </div>
        </div>

      </aside>

      <div class="banners">
         <img src="../img/imgfooter.jpg" alt="publicidad logos">
      </div>
    <?php include('../footer.php');?>

    </div>
    </div>

<script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>

<!--      <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>   --> 
    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/easy-responsive-tabs.js"></script>

      <script src="../js/script-efectos.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

     <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>

 <script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submitmiraflores.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>


<style>
    #owl-demo .item{
        margin: 3px;
    }
    #owl-demo .item img{
        display: block;
        width: 100%;
        height: auto;
    }

 
    </style>


  </body>


</html>