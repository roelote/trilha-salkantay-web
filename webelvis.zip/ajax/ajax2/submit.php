<?php

if($_POST)
{
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phno = $_POST['phno'];

    $subject = 'Free Walks Arequipa - English';

    $message = 
'<table width="300" border="1" align="center" cellpadding="1" cellspacing="1"
  <tr>
    <th colspan="2">Free Tour by Foot Lima<br></th>
  </tr>
  <tr>
    <td>Name<br></td>
    <td>'.$fname.'</td>
  </tr>
  <tr>
    <td>Tour<br></td>
    <td>'.$lname.'</td>
  </tr>
  <tr>
    <td>Date<br></td>
    <td>'.$email.'</td>
  </tr>
  <tr>
    <td>Nro Pax<br></td>
    <td>'.$phno.'</td>
  </tr>
  <tr>
    <th colspan="2">Message<br></th>
  </tr>
   <tr>
   <th colspan="2">'.$phno.'<br></th>
  </tr>
</table>';

$from3=$fname."<".$email.">";
$headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers .= "From: ". $from3 . "\n";

mail ('jroelx@gmail.com', $subject, $message, $headers);

	?>
    
    <table border="0">
    
    <tr>
    <td colspan="2">Succedd !!!</td>
    </tr>
    
    <tr>
    <td colspan="2"><hr /></td>
    </tr>
    
    <tr>
    <td>First Name</td>
    <td><?php echo $fname ?></td>
    </tr>
    
    <tr>
    <td>Last Name</td>
    <td><?php echo $lname ?></td>
    </tr>
    
    <tr>
    <td>Your eMail</td>
    <td><?php echo $email; ?></td>
    </tr>
    
    <tr>
    <td>Contact No</td>
    <td><?php echo $phno; ?></td>
    </tr>
    
    </table>
    <?php
	
}

?>