<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>FREE Walking Tour Lima | FREE City Tour Lima | Historical centre</title>
    <meta content="Join the number one Free Walking Tour Lima, our Free Tour Lima is focused on the city´s history only, while taking our Lima half day city tour you will explore Lima like a Local on foot, this is what is makes different our Free city tour Lima from the classic city tours Lima." name="description" />
    <meta content="Free Walking Tour Lima, city tour lima, Lima half day city tour, free tour, tours lima, city tour lima" name="keywords" />
    <meta content="en" name="language" />
   <meta name="author" content="Free Walking Tours" />
    <!-- Bootstrap -->
      <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
<link href="../css/flag-icon.min.css" rel="stylesheet">
     <!-- favicons -->
        <link rel="apple-touch-icon" sizes="57x57" href="../favicons/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../favicons/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../favicons/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../favicons/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../favicons/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../favicons/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../favicons/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../favicons/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../favicons/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="../favicons/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="../favicons/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../favicons/favicon-16x16.png">
        <link rel="manifest" href="../favicons/manifest.json">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content="../favicons/ms-icon-144x144.png">
        <meta name="theme-color" content="#ffffff">
          <!-- end favicons -->
          <!-- open graph -->
                          <meta property="og:type" content="website">
                          <meta property="og:title" content="Free Walking Tour Lima | 10am & 11am by Inkan Milky Way Tours">
                          <meta property="og:description" content="Free Walking Tour Lima by Inkan Milky Way Tours Lima, We offer one free walking tour Lima, Gather us at Calle Schell by Oechsle Mall and La Merced Church in downtown Lima, Look for Inkan Milky Way Logo-sign.">
                          <meta property="og:url" content="https://www.freewalkingtoursperu.com/lima/">
                          <meta property="og:image" content="https://www.freewalkingtoursperu.com/img/free-walks-lima-3.jpg">
                          <meta property="fb:app_id" content="limafreewalkingtour">
                              <!-- twitter -->
          <!-- end open graph -->

<script type="application/ld+json">
      {
        "@context": "http://schema.org/",
        "@type": "Review",
        "itemReviewed": {
          "@type": "Thing",
          "name": "Free Walking Tour Lima"
        },
        "author": {
          "@type": "Organization",
          "name": "Lima"
        },
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": "4.9",
          "bestRating": "5"
        },
        "publisher": {
          "@type": "Organization",
          "name": "Free Walking Tours Peru"
        }
      }
      
    </script>

  </head>
  <body>

  <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>

<!-- <div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center">NOTE:</h4>
            </div>
            <div class="modal-body">
        <p class="text-center">
          Note 28th of July<br>
Lima: Join us at 10am in Tarata street | Only on this day we will do Miraflores tour, we won't go to Lima centre, tours will in English only, keep in mind only on this day.<br>
No other meet up times pls<br>
Cusco & Arequipa: We are operating.
        </p>

                
            </div>
        </div>
    </div>
</div> -->


    <div class="container px-0">
      <header class="cabecera">
<?php include('../menu.php');?>
        <!-- div class="idiomas">
        <span class="en"><a href="/lima/"><img src="../img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/lima/"><img src="../img/es.png" alt="ingles"></a></span>
      </div> -->
        
        <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/free-tour-city-lima.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/free-tour-lima.jpg">
        <img src="../img/free-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/free-tour-lima-centro.jpg">
        <img src="../img/tours-peru-free.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>



           
      </header>

    <div class="cuerpo">

      <section class="container izquierda">
                   
            <div class="text-general col-lg-12 col-lg-12 col-xs-12">
              <h1><b>Free</b> Walking Tour Lima | Free City Tour Lima | Historical Centre Tours</h1>

             <p>Join our best free walking tour Lima organized by a pioneering company, 100% Indigenous Peruvian Tour Guides, what’s more Licensed Guides(in Peru, you must study Tourism & Hospitality Career to become a licensed Guide by the government to work as Tour Guide, this means NOT everyone can just be guiding in the streets, if this happens, there are inspections in Lima centre if they catch fake guides “guiding”, they will be sanctioned and the tour will be totally cancelled, then you got the last word) | In our Free City Tour Lima taking place mainly in the historical centre(don´t worry if you are staying in Miraflores or Barranco, check your meeting points below, we will pick you up) we will walk into the Must-Do attractions such us the Old Train Station, Palace of Jose Bernardo Torre Tagle, Rimac river or The Palace of Francisco Pizarro.</p>

            

             <h2>Free Tour Meet up Times and Meeting Points</h2>
             <p>From Monday to Saturday  10am & 11am & 3pm <span class="text-danger">No Sundays.</span></p>
                <ol>
                <li style="font-weight: 400;"><span style="font-weight: 400;">For all tourists who are staying in at Miraflores District or nearby, please join us at </span><strong>10AM</strong><span style="font-weight: 400;"> in </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.1226699,-77.0328484,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.1226699!4d-77.0306597"><span style="font-weight: 400;">Calle Schell</span></a><span style="font-weight: 400;"> by Oechsle Mall, just 1 min AWAY by foot from Kennedy Park &ndash; </span><span style="font-weight: 400;"><span style="color: #800080; font-family: sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">Bring 2.50 soles(0.70 cents USD, this is for your Bus Transportation).</span></span></li>
                <li style="font-weight: 400;"><span style="font-weight: 400;">For all tourists who are staying in downtown Lima, join us at </span><strong>11AM</strong><span style="font-weight: 400;"> in front of </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">La</span> <span style="font-weight: 400;">Merced Church</span></a> <span style="font-weight: 400;">at Jir&oacute;n de La Union.</span></li>
                <li style="font-weight: 400;"><span style="font-weight: 400;">If you want to take our AFTERNOON free walking tour Lima, join us at </span><strong>3PM,</strong><span style="font-weight: 400;"> also in front of </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">La Merced Church</span></a><span style="font-weight: 400;"> (</span><strong>No other meeting point neither meet up time, so make sure you come Directly to La Merced Church </strong><span style="font-weight: 400;">from anywhere you are in Lima city).</span></li>
                <li style="font-weight: 400;"><span style="font-weight: 400;">How about if I am Staying in Barranco? If this is your case follow me for your free walking tour </span><a href="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-barranco"><span style="font-weight: 400;">Lima from Barranco</span><span style="font-weight: 400;">.</span></a></li>
                </ol>

            <h2>How to identify your Correct Tour Guide:</h2>
            <ul>
              <li> Look for us at the Correct Meeting Point.</li>
<li> We wear the Inkan Milky Way Logo-Sign</li>

            </ul>

          <h2>Inclusions four our Tours Lima on foot:</h2>
 <p>All our Free Tours Lima include Professional Tour Guide, Fantastic English, Must-do city tour Attractions, Culture and History – <span class="text-danger">NO Bars, NO Drinks</span>, we got history for you.</p>
 <h2>Duration: </h2>
 <p>If you start your free tour in Lima centre takes 2.5 hours however if you start your free tour Lima in Miraflores takes 3.5h because we take the Bus to get to Lima centre), don’t forget to check your Lima Walking Tour Map below(both tours have are the same, different meeting points).</p>
<h2>Price:</h2>
 <p>FREE - Donation Basis.</p>
 <h2>Language: </h2><p>Groups in English & Spanish, you choose your language.</p>
<div class="btn-reserva">
  

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#titlea-side"><button type="button" class="btn btnreserva active">Book Now</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>
 <p><span style="color: #ff0000;">To Consider:</span>&nbsp;You might get confused with other people, pls show up at the correct meeting point &amp; Our free tours in Lima are operated by Inkan Milky Way Tours Lima, a 100% Indigenous Peruvian Co,&nbsp;<a href="https://www.facebook.com/limafreewalkingtour/">follow us here.</a></p>


 <p>Join our best free walking tour Lima organized by a pioneering company, 100% Indigenous Peruvian Tour Guides, what’s more Licensed Guides(in Peru, you must study Tourism & Hospitality Career to become a licensed Guide by the government to work as Tour Guide, this means NOT everyone can just be guiding in the streets, if this happens, there are inspections in Lima centre if they catch fake guides “guiding”, they will be sanctioned and the tour will be totally cancelled, then you got the last word) | In our Free City Tour Lima taking place mainly in the historical centre(don´t worry if you are staying in Miraflores or Barranco, check your meeting points below, we will pick you up) we will walk into the Must-Do attractions such us the Old Train Station, Palace of Jose Bernardo Torre Tagle, Rimac river or The Palace of Francisco Pizarro.</p>

              
            </div>

            <div class="row">

                                  <div class="ciudadfwt bot25">

                                                <div class="center"> 
                                                  <a href="free-walking-tour-lima-10-30-am"><h3 class="titulociudad"><span class="tours-time limat"><span class="rojo">Free Walking City Tour Lima at 10am</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/tours-en-lima-free.jpg" alt="free walking tours lima 10.30 am">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <span><i class="fa fa-tag" aria-hidden="true"></i><strong>Tour Type:</strong></span> Cultural Walking. <br>
                                                    <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> When:</strong></span>From Mon to Sat only.<br>
                                                    <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Good For:</strong></span> All people capable & keen to walk.<br>
                                                    <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duration:</strong></span>3.5 hours.<br>
                                                    <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Difficulty:</strong></span> None, flat walking 1.6 km – 1 mi.<br>
                                                    <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Meeting Point:</strong></span> Calle Schell, by Oechsle Mall. <br>
                                                    <span><i class="fa fa-language" aria-hidden="true"></i><strong> Language: </strong></span>English - Español <br>
                                                    <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Look for:</strong></span> Inkan Milky Way Logo-Sign<br>
                                                    
                                                    <div>
                                                        <div class="porciento50">
                                                        
                                                       <span><a class="click-here" href="free-walking-tour-lima-10-30-am"><i class="fa fa-info-circle" aria-hidden="true"></i> More Info</a></span>
                                                        </div>
                                                        <div class="porciento50"><a href="/booking"><button type="button" class="btn btn-primary">Book Now</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>

                                  </div>

                                   <div class="ciudadfwt bot25">

                                                 <div class="center"> 
                                                  <a href="free-walking-tour-lima-11-30-am"><h3 class="titulociudad"><span class="tours-time limat"><span class="rojo">Free Walking City Tour Lima at 11am</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/lima-tours-walks.jpg" alt="free walking tours lima 10.50 am">
                                                  </div>

                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                      <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tour Type:</strong></span> Cultural Walking.<br>
                                                      <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> When:</strong></span> From Mon to Sat only.<br>

                                                      <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Good For:</strong></span> All people capable & keen to walk.<br>

                                                      <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duration:</strong></span> 2.5 hours.<br>

                                                      <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Difficulty:</strong></span> None, flat walking 1.6 km – 1 mi.<br>

                                                      <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Meeting Point:</strong></span> in front of La Merced Church at Jirón de La Union.<br>
                                                      <span><i class="fa fa-language" aria-hidden="true"></i><strong> Language: </strong></span>English - Español <br>

                                                      <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Look for:</strong></span> Inkan Milky Way Logo-Sign.<br>

                                                      
                                                      <div>
                                                         <div class="porciento50">

                                                          <span><a class="click-here" href="free-walking-tour-lima-11-30-am"><i class="fa fa-info-circle" aria-hidden="true"></i> More Info</a></span>
                                                        </div>
                                                        <div class="porciento50"><a  href="/booking"><button type="button" class="btn btn-primary">Book Now</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                  </div>
                                  <div class="ciudadfwt">

                                                 <div class="center"> 
                                                  <a href="free-walking-tour-lima-afternoon"><h3 class="titulociudad"><span class="tours-time limat"><span class="rojo">Free Walking City Tour Lima at 3pm</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/lima-tours-walks.jpg" alt="free walking tours lima 10.50 am">
                                                  </div>

                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                      <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tour Type:</strong></span> Cultural Walking.<br>
                                                      <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> When:</strong></span> From Mon to Sat only.<br>

                                                      <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Good For:</strong></span> All people capable & keen to walk.<br>

                                                      <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duration:</strong></span> 2.5 hours.<br>

                                                      <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Difficulty:</strong></span> None, flat walking 1.6 km – 1 mi..<br>

                                                      <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Meeting Point:</strong></span> in front of La Merced Church at Jirón de La Union.<br>
                                                      <span><i class="fa fa-language" aria-hidden="true"></i><strong> Language: </strong></span>English - Español <br>

                                                      <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Look for:</strong></span> Inkan Milky Way Logo-Sign.<br>

                                                      
                                                      <div>
                                                         <div class="porciento50">

                                                          <span><a class="click-here" href="free-walking-tour-lima-afternoon"><i class="fa fa-info-circle" aria-hidden="true"></i> More Info</a></span>
                                                        </div>
                                                        <div class="porciento50"><a  href="/booking"><button type="button" class="btn btn-primary">Book Now</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                  </div>


                </div>
            <!-- /.row -->

             <div class="lima2">
          <!-- <img src="../img/lima-walks-10-30am.jpg" alt="">
          <img src="../img/lima-walks-11am.jpg" alt=""> -->

           <div class="row">

                      <div class="col-lg-12">
                          
                              <div class="col-lg-6 col-md-6 col-xs-12">
                              <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="Free Walking Tour Lima 10 am" data-caption="free walking tour lima 10 am" data-image="../img/maps-lima-walking-tour-10am.jpg" data-target="#image-gallery">
                                  <img class="img-responsive" src="../img/maps-lima-walking-tour-10am.jpg" alt="Another alt text">
                              </a>
                          </div>

                              <div class="col-lg-6 col-md-6 col-xs-12">
                              <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="Free Walking Tour Lima 10.50 am" data-caption="free walking tour lima 10.50 am" data-image="../img/map-lima-free-tour-11am-3pm.png" data-target="#image-gallery">
                                  <img class="img-responsive" src="../img//map-lima-free-tour-11am-3pm.png" alt="Another alt text">
                              </a>
                          </div>
                  </div>


                  <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <div class="modal-dialogo">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span><span class="sr-only">Close</span></button>
                                  <h4 class="modal-title" id="image-gallery-title"></h4>
                              </div>
                              <div class="modal-body">
                                  <img id="image-gallery-image" class="img-responsive" src="">
                              </div>
                              
                          </div>
                      </div>
                  </div>
                </div>
          </div>
  
      </section>

   

      <aside class="derecha" id="titlea-side">
      <?php include('../cuadro-reservas-lima.php');?>
        <div class="facebookpubli hidden-xs">
       <!--    <div class="fb-page" data-href="https://www.facebook.com/limafreewalkingtour/" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/limafreewalkingtour/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/limafreewalkingtour/">Free Walking Tour Lima</a></blockquote></div>
 -->
         <div class="fb-page" 
  data-href="https://www.facebook.com/limafreewalkingtour/"
  data-width="380" 
  data-hide-cover="false"
  data-show-facepile="false" 
  data-show-posts="false"></div>
          
        </div>

<!-- <div class="blogpage hidden-xs">
<a target="_blank" href="/blog" ><img src="../img/blogger-free-tour-cusco.jpg" alt="blog-free-walking-tour-cusco"></a>
</div> -->

      
       
      </aside>


      
      
<div class="maps-c mb-5 mt-4">
    <div class="row m-0">
        <div class="col-xs-12 col-sm-6">
          <div class="border-map mb-2 mt-4">
            <h3 class="text-center mt-2">Free Tour Lima 10am - Pick up in Calle Schell,by Oechsle Mall, Mrflrs</h3>
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3900.83395271387!2d-77.03090888518663!3d-12.123511191416247!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x3e2cd448586ebf0b!2sInkan+Milky+Way+Lima%2C+Free+Walking+Tour!5e0!3m2!1ses!2spe!4v1523139123996" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
        </div>
      <div class="col-xs-12 col-sm-6">
        <div class="border-map">
          <h3 class="text-center mt-2">Free Tour Lima 11am - in La Mercerd Church</h3>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.9325044777484!2d-77.0350338851874!3d-12.048164991466383!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x260b4404fb6284e!2sInkan+Milky+Way+Lima!5e0!3m2!1ses!2spe!4v1523139111848" width="600" height="450" frameborder="0" style="border:0" allowfullscreen>
            </iframe>
        </div>
      </div>
    </div>
     </div>

      <section class="mt-5 pt-5 mb-5">

         <div id="wrap">
            <div class="card mb-5">
              <div class="thumb" id="one" style="background-image: url(../img/free-walking-tour-cusco-10-am.jpg);}"></div>
              <div class="option">
                <i class="material-icons"></i>
                <i class="material-icons"></i>
                <i class="material-icons"></i>
              </div>
              <h3 class="text-center">Free Tour Cusco</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Going to Cusco? Join our free tour Partner, offering the best tip based walks, full on history & culture</p>
              <div class="add"><a target="_blank" href="/cusco/">More Info</a></div>
              <div class="buy"> <a target="_blank" href="/booking">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="two" style="background-image: url(../img/free-walking-tour-arequipa-3-pm.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Free Tour Arequipa</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Are you planning to visist Arequipa? Be part of the finest free walking tours operated by our Partner</p>
              <div class="add"> <a target="_blank" href="/arequipa/">More Info</a></div>
              <div class="buy"> <a target="_blank" href="/booking">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="three" style="background-image: url(../img/cusco-private-tour.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Private Walks Cusco</h3>
              
              <p class="price">$35.00</p>
              
              <p class="desc mt-1 mb-3">Want a private walk? Then join our premier private walking tours, operated by a Local Indigenous Co</p>
              <div class="add"> <a target="_blank" href="#">More Info</a></div>
              <div class="buy"><a target="_blank" href="#">Book Know</a></div>
            </div>
          </div>

  
     </section>
 <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Home</span>
                                    </a> »  
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Lima</strong>
                                  </div>
                  </div>
    <div class="banners mt-5">
       <img src="../img/imgfooter.jpg" alt="">
    </div>
    <?php include('../footer.php');?>


    </div>

   
<script src="https://code.jquery.com/jquery-2.2.3.min.js"></script>  
    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>


 
<!--   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $("#myModal").modal('show');
  });
</script> -->

   <!-- script reservas -->
<script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>
<script language="javascript">
$(document).ready(function() {
    $().ajaxStart(function() {
        $('#loading').show();
        $('#result').hide();
    }).ajaxStop(function() {
        $('#loading').hide();
        $('#result').fadeIn('slow');
    });
    $('#form, #fat, #fo3').submit(function() {
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function(data) {
                $('#result').html(data);

            }
        })
        
        return false;
    }); 
})  
</script>


<script>
  
 $(document).ready(function(){

    loadGallery(true, 'a.thumbnail');

    //This function disables buttons when needed
    function disableButtons(counter_max, counter_current){
        $('#show-previous-image, #show-next-image').show();
        if(counter_max == counter_current){
            $('#show-next-image').hide();
        } else if (counter_current == 1){
            $('#show-previous-image').hide();
        }
    }

    /**
     *
     * @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
     * @param setClickAttr  Sets the attribute for the click handler.
     */

    function loadGallery(setIDs, setClickAttr){
        var current_image,
            selector,
            counter = 0;

        $('#show-next-image, #show-previous-image').click(function(){
            if($(this).attr('id') == 'show-previous-image'){
                current_image--;
            } else {
                current_image++;
            }

            selector = $('[data-image-id="' + current_image + '"]');
            updateGallery(selector);
        });

        function updateGallery(selector) {
            var $sel = selector;
            current_image = $sel.data('image-id');
            $('#image-gallery-caption').text($sel.data('caption'));
            $('#image-gallery-title').text($sel.data('title'));
            $('#image-gallery-image').attr('src', $sel.data('image'));
            disableButtons(counter, $sel.data('image-id'));
        }

        if(setIDs == true){
            $('[data-image-id]').each(function(){
                counter++;
                $(this).attr('data-image-id',counter);
            });
        }
        $(setClickAttr).on('click',function(){
            updateGallery($(this));
        });
    }
});
</script>

  </body>


</html>