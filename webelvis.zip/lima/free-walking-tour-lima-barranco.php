<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tour Lima from Barranco | Free Tours by Foot Lima</title>
    <meta content="Join our free walking tour Lima from Barranco district and make the best of your visit to Lima." name="description" />
    <meta content="free walking tour lima, free walks, city tours" name="keywords" />
    <meta content="en" name="language" />


    <!-- Bootstrap -->
      <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">
     
  <!--   estilos slider pekeño -->
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
    <link href="../css/flag-icon.min.css" rel="stylesheet">
    

                  <!-- favicons -->
        <link rel="apple-touch-icon" sizes="57x57" href="../favicons/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../favicons/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../favicons/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../favicons/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../favicons/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../favicons/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../favicons/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../favicons/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../favicons/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="../favicons/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="../favicons/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../favicons/favicon-16x16.png">
        <link rel="manifest" href="../favicons/manifest.json">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content="../favicons/ms-icon-144x144.png">
        <meta name="theme-color" content="#ffffff">
          <!-- end favicons -->
          <!-- open graph -->
                          <meta property="og:type" content="website">
                          <meta property="og:title" content="Free Walking Tour Lima from Barranco | Free Tours by Foot Lima">
                          <meta property="og:description" content="Join our free walking tour Lima from Barranco district and make the best of your visit to Lima.">
                          <meta property="og:url" content="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-10-30-am">
                          <meta property="og:image" content="https://www.freewalkingtoursperu.com/img/free-tours-lima-1.jpg">
                          <meta property="fb:app_id" content="FTFWALKINGTOURSLIMA">
                              <!-- twitter -->
          <!-- end open graph -->

<script type="application/ld+json">
      {
        "@context": "http://schema.org/",
        "@type": "Review",
        "itemReviewed": {
          "@type": "Thing",
          "name": "Free Walking Tour Lima at 10:30 am"
        },
        "author": {
          "@type": "Organization",
          "name": "Lima"
        },
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": "4.8",
          "bestRating": "5"
        },
        "publisher": {
          "@type": "Organization",
          "name": "Free Walking Tours Peru"
        }
      }
      
    </script>


  </head>
  <body>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>
    <div id="fb-root"></div>

    <div class="container px-0">
      <header class="cabecera">
      <?php include('../menu.php');?>
       <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima10am-free-city-tour.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima10am-city-tour.jpg">
        <img src="../img/free-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima10am-free-tour.jpg">
        <img src="../img/tours-peru-free.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>
      </header>

 
    <div class="cuerpo">

      <section class="container izquierda">
             

        <section class="cuadro-texto cuadro-contenedor">

          <h1><b>Free</b> Walking Tour in Lima Center at 11am & 3pm, <span>for tourists who are staying in Barranco District.</span></h1>
          

          <div class="wecolmetour">
    <h2 class="text-center">How can I join your free tour in Lima city center, if I am staying at Barranco District?</h2>

<p>Please, make your way STRAIGHT to La Merced Church in Jirón de La Union (Lima Center), use Metropolitano Bus, follow below instructions: 
</p>

<ol>
<li>Get to <a href="https://www.google.com.pe/maps/place/V%C3%ADa+del+Metropolitano,+Distrito+de+Chorrillos+15063/@-12.1524862,-77.0215828,17.25z/data=!4m5!3m4!1s0x9105b78d321ddd21:0x19c570f99a80a15c!8m2!3d-12.1524134!4d-77.019738">Bulevard Metropolitano</a> Bus station which is just right across the Main Plaza of Barranco, (Be there the latest by 10am) it will take 5 to 10 min to get to the bus station by foot.</li>
<li>At the Bus station, Buy your Card from the Operator counter, price is 4.50 soles and REFILL it, <strong>How much should you refill? </strong>Ticket price to any destination is 2.50 soles, this will be charged anytime you swipe your card, (2.50 soles will be deducted). So if you are 2 people, you must refill 5 soles in your card &ndash; <span style="color: #ff0000;">Note</span>, if you are 10 people you don&rsquo;t need 10 cards, one is enough but make sure you refill it, 10 times 2.50 soles.</li>
<li>Once your card is refilled, swipe your card at the spin door, so you enter, <strong>how about your other mates?</strong> Borrow them your card and let them swipe also.</li>
<li>Once all of you are at the Bus station, MAKE SURE you get on <strong>Line C</strong>, heading to the NORTH (<strong>Hacia al Norte</strong>). Just ask local people by saying in Spanish: <span style="color: #800080;">De d&oacute;nde tomo el Bus para Jir&oacute;n de la Union?</span></li>
<li>Once you are in the Bus, it will take 30 min to get to Jir&oacute;n de la Union bus station, get OFF at this station, the name of the stations are displayed on the screen of the buses and also announced verbally.</li>
<li>Finally from the Jir&oacute;n de la Union Bus station make your way to La Merced Church, we will be there at 11am or 3pm, so when you book a free tour in Lima center (if you are in Barranco)&nbsp;<a href="https://www.freewalkingtoursperu.com/booking/">book for 11am</a> or <a href="https://www.freewalkingtoursperu.com/booking/">3pm</a>&nbsp;free tour meet up time.</li>
<li>If you want extra help in English, regarding this matter dial the following numbers: +51 958745640 or +51 958745640&nbsp;<a href="https://www.freewalkingtoursperu.com/contact-us">check calling hours here</a>, we speak English.</li>
</ol>

<div class="btn-reserva">
  

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#titlea-side"><button type="button" class="btn btnreserva active">Book Now</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>

<p><span style="color: #ff0000;">VERY IMPORTANT:</span> if you take a taxi in Barranco, you pay 25 to 30 soles total price, takes minimum 1 HOUR, then make sure you take the taxi ON TIME.</p>
<p class="text-center"><strong style="color: #e318e0;">Alluring Spots we’ll see¡</strong></p>
<div class="slidertours">
              <div id="demo">
                <div class="container">
                  <div class="row">
                    <div class="span12">

                      <div id="owl-demo" class="owl-carousel">

                        <div class="item"><img src="../img/free-tour-lima-14.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Learn About Metro-Bus System</div></div>
                        <div class="item"><img src="../img/free-tour-lima-01.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Meet Local People</div></div>
                        <div class="item"><img src="../img/free-tour-lima-02.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Peruvian Literature House</div></div>
                        <div class="item"><img src="../img/free-tour-lima-03.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Meet other Travelers</div></div>
                        <div class="item"><img src="../img/free-tour-lima-04.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Rimac River</div></div>
                        <div class="item"><img src="../img/free-tour-lima-05.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Town Hall</div></div>
                        <div class="item"><img src="../img/free-tour-lima-06.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">San Francisco Church</div></div>
                        <div class="item"><img src="../img/free-tour-lima-07.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Meet other Travelers</div></div>
                        <div class="item"><img src="../img/free-tour-lima-08.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palace of Torre Tagle Marquis</div></div>
                        <div class="item"><img src="../img/free-tour-lima-09.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Change of Guard</div></div>
                        <div class="item"><img src="../img/free-tour-lima-10.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Plaza de Armas</div></div>
                        <div class="item"><img src="../img/free-tour-lima-11.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palace of President </div></div>
                        <div class="item"><img src="../img/free-tour-lima-12.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Santo Domingo Church</div></div>
                        <div class="item"><img src="../img/free-tour-lima-13.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Meet other Travelers</div></div>
                        

            </div>
                      
                    </div>
                  </div>
                </div>
           </div>

          </div>
          </div>
          


                <br>
                <div style="height: 30px; clear: both"></div>

         </section>

      </section>

      <aside class="derecha" id="titlea-side">
      <?php include('../cuadro-reservas-lima.php');?>
<div class="blogpage">

</div>
       <!--  <div class="mapadetalle">
        <h2> <span id="mytext" class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span> Click the Map to See</h2>
        <div class="centrarmapa mb-5"><img  id="myImg" src="../img/lima-walks-10-30am.jpg" alt="Free Walking Tour Lima 10:30 am" width="300" height="200"></div>


        <div id="myModal" class="modal">
          <span class="close">×</span>
          <img class="modal-content" id="img01" alt="mapa ubicacion">
          <div id="caption"></div>
        </div>
        </div> -->
      </aside>

      <!-- <div class="maps-c mb-5">
       <div id="map" style="width:100%;height:500px;"></div>
       <div class="contenedormap"></div>
     </div> -->

     <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Home</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/lima/" itemprop="url" title="Lima" class="linkgeneral">
                                      <span itemprop="title">Lima</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Free Walking Tour Lima From Barranco</strong>
                                  </div>
                  </div>
    <div class="banners mt-5">
         <img src="../img/imgfooter.jpg" alt="publicidad logos">
      </div>
    <?php include('../footer.php');?>

    </div>
    </div>


    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>

<!--      <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>   --> 
    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/easy-responsive-tabs.js"></script>
      <script src="../js/mapa-lima1.js"></script>
      <script src="../js/script-efectos.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

          <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });

   </script>
<script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>
   <script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submitlima.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>
     
<style>
    #owl-demo .item{
        margin: 3px;
    }
    #owl-demo .item img{
        display: block;
        width: 100%;
        height: auto;
    }
    </style>


  </body>


</html>