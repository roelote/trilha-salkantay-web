<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>FREE City Tour Lima Peru | Free Walking Tour Lima | Hop on Hop off on foot.</title>
    <meta content="How about a City Tour Lima Peru with Free Walking Tour Lima? Our tours on foot are way more popular than most classic tours in Lima, you will hop on hop off on Foot, help us to support sustainable tourism and local communities by taking our city tour Lima in the hands of Local Guides." name="description" />
    <meta content="City Tour Lima Peru, Free Walking Tour Lima, lima city tour hop on hop off, free walking tour" name="keywords" />
    <meta content="en" name="language" />

    <!-- Bootstrap -->
      <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">
   
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
    <link href="../css/flag-icon.min.css" rel="stylesheet">

                      <!-- favicons -->
        <link rel="apple-touch-icon" sizes="57x57" href="../favicons/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../favicons/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../favicons/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../favicons/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../favicons/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../favicons/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../favicons/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../favicons/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../favicons/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="../favicons/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="../favicons/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../favicons/favicon-16x16.png">
        <link rel="manifest" href="../favicons/manifest.json">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content="../favicons/ms-icon-144x144.png">
        <meta name="theme-color" content="#ffffff">
          <!-- end favicons -->
          <!-- open graph -->
                          <meta property="og:type" content="website">
                          <meta property="og:title" content="Free Walking Tour Lima 11am | Free Tours by Foot Lima">
                          <meta property="og:description" content="Join us from mon to sat at 11am at Downtown Lima, Look for the Inkan milky way Logo. Our free walks include History, Culture and Inquires"">
                          <meta property="og:url" content="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-11-30-am">
                          <meta property="og:image" content="https://www.freewalkingtoursperu.com/img/free-walks-lima-3.jpg">
                          <meta property="fb:app_id" content="FTFWALKINGTOURSLIMA">
                              <!-- twitter -->
          <!-- end open graph -->

<script type="application/ld+json">
      {
        "@context": "http://schema.org/",
        "@type": "Review",
        "itemReviewed": {
          "@type": "Thing",
          "name": "Free Walking Tour Lima at 11am"
        },
        "author": {
          "@type": "Organization",
          "name": "Lima"
        },
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": "4.7",
          "bestRating": "5"
        },
        "publisher": {
          "@type": "Organization",
          "name": "Free Walking Tours Peru"
        }
      }
      
    </script>
<style>
  .redes-s .tex-center {
    color: #382626 !important;
}

.carousel-control.left,.carousel-control.right  {background:none;width:25px;}
.carousel-control.left {color: #3e3b3b;}
.carousel-control.right {color: #3e3b3b;}

.block-text {
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 3px 0 #2c2222;
    color: #626262;
    font-size: 14px;
    margin-top: 0px;
    padding: 5px 18px;
}
.block-text a {
    color: #45517b;
    font-size: 21px;
    line-height: 21px;
    text-decoration: none;
}
.rating-input {
    color: #e7711b;
}
.mark {
    padding: 12px 0;background:none;
}
.block-text p {
    color: #585858;
    font-family: Georgia;
    font-style: italic;
    line-height: 20px;
}
.sprite {

}
.sprite-i-triangle {
    background-position: 0 -1298px;
    height: 44px;
    width: 50px;
}
.block-text ins {
    bottom: -44px;
    left: 50%;
    margin-left: -60px;
}


.block {
    display: block;
}
.zmin {
    z-index: 1;
}
.ab {
    position: absolute;
}

.person-text {
    padding: 10px 0 0;
    text-align: center;
    z-index: 2;
}
.person-text a {
    color: #3a4872;
    display: block;
    font-size: 14px;
    margin-top: 3px;
}
.person-text i {
    color: #fff;
    font-family: Georgia;
    font-size: 13px;
}
.rel {
    position: relative;
}
.person-text.rel img {

    border-radius: 5px;

}
</style>
  </head>
  <body>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>
    <div id="fb-root"></div>

    <div class="container px-0">
      <header class="cabecera">
         <?php include('../menu.php');?>

                                        <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima11am-tour-lima.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima11am-lima-free.jpg">
        <img src="../img/free-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima11am-city-tour.jpg">
        <img src="../img/tours-peru-free.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>

          
      </header>

 
    <div class="cuerpo">

      <section class="container izquierda">
      

        <section class="cuadro-texto cuadro-contenedor">

          <h1><b>Free</b> Walking Tour Lima Centre at 11am | city tour Lima Peru</h1>

          

          <div class="wecolmetour">
         <p>Thinking of a <strong>free walking tour Lima in the historical centre</strong>?, then our <strong>FREE city tour Lima Peru</strong> is your cup of tea, come and unveil our millenary city with an itinerary out from the beaten path, we include must-seen attractions for sure, but also hidden attractions that usually most tourists miss such as the Rimac River or the Inka Obelisk, this FREE city tour Lima Peru will be better than hop on hop off since it is on foot where you will have more interactions with the attractions.</p>
<p>While free walking with Indigenous Licensed Tour Guides, you will experience Lima city tour hop on hop off on FOOT, unlike many free tours we make sure our walks are 100% cultural focused ones.</p>
<p>Our&nbsp;<strong>11am FREE Lima Walking Tour</strong>&nbsp;is scheduled for tourists who are staying at Lima Downtown,&nbsp;<a href="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-from-miraflores">if you are in Miraflores District check here</a>, if you are in&nbsp;Barranco&nbsp;take a glance to <a href="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-barranco">Lima city tour from Barranco</a>.</p>



<h2 class="text-center">BEFORE JOINING OUR FREE TOUR YOU SHOULD KNOW:</h2>

<p><b>Free Tour Meet up Time</b>: 11am from Monday to Saturday – <span class="text-danger">No Sundays</span></p>
<p><b>Meeting Place</b>: Join us in front of <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima/@-12.048165,-77.032845,14z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES">La Merced Church</a> at Jirón de La Union, just 5 min AWAY (by foot) from the Plaza Mayor de Lima - <span class="text-danger">Don´t be late.</span></p>
<p><b>Walking Tour Length</b>: Starting from Lima downtown, takes 2.5 hours approx.</p>

<p><b>Our Happy Official Tour Guide wears:</b> Inkan Milky Way Logo-Sign, look for this at the Correct Meeting Place.</p>
<p><b>To bring</b>: Hats, sunglasses, walking shoes and a jumper.</p>
<p><b>Price</b>: FREE – Donation basis.</p>
<p><b>Language</b>: Groups in English & Spanish, you choose your language.</p>

<div class="btn-reserva">
  

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#titlea-side"><button type="button" class="btn btnreserva active">Book Now</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>


<p><span style="color: #ff0000;">To Consider:&nbsp;</span>You might get confused with other people, pls show up at the correct meeting point &amp; Our free tours in Lima are operated by Inkan Milky Way Tours Lima, a 100% Indigenous Peruvian Co,&nbsp;<a href="https://www.facebook.com/limafreewalkingtour/">follow us here.</a></p>

                        <p class="text-danger">  </p>

              <p class="text-danger"> </p> 
              <p class="text-center"><strong style="color: #e318e0;">Alluring Spots we’ll see¡</strong></p>
               <div class="slidertours">
              <div id="demo">
                <div class="container">
                  <div class="row">
                    <div class="span12">

                      <div id="owl-demo" class="owl-carousel">

                        <div class="item"><img src="../img/free-tour-lima-14.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Learn About Metro-Bus System</div></div>
                        <div class="item"><img src="../img/free-tour-lima-01.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Meet Local People</div></div>
                        <div class="item"><img src="../img/free-tour-lima-02.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Peruvian Literature House</div></div>
                        <div class="item"><img src="../img/free-tour-lima-03.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Meet other Travelers</div></div>
                        <div class="item"><img src="../img/free-tour-lima-04.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Rimac River</div></div>
                        <div class="item"><img src="../img/free-tour-lima-05.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Town Hall</div></div>
                        <div class="item"><img src="../img/free-tour-lima-06.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">San Francisco Church</div></div>
                        <div class="item"><img src="../img/free-tour-lima-07.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Meet other Travelers</div></div>
                        <div class="item"><img src="../img/free-tour-lima-08.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palace of Torre Tagle Marquis</div></div>
                        <div class="item"><img src="../img/free-tour-lima-09.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Change of Guard</div></div>
                        <div class="item"><img src="../img/free-tour-lima-10.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Plaza de Armas</div></div>
                        <div class="item"><img src="../img/free-tour-lima-11.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palace of President </div></div>
                        <div class="item"><img src="../img/free-tour-lima-12.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Santo Domingo Church</div></div>
                        <div class="item"><img src="../img/free-tour-lima-13.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Meet other Travelers</div></div>
                        

                    </div>
                      
                    </div>
                  </div>
                </div>
           </div>

          </div>

          </div>

         
          
            <div id="verticalTab">
                <ul class="resp-tabs-list">
                <li> <span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> ITINERARY</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> INCLUSIONS</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> REMARKS & FAQ’S</li>
                </ul>
                <div class="resp-tabs-container">
                    <div>
                    <h2 class="h2-tours-detalle"> Spots we are going to visit:  </h2> 

                   <p class="texto-ciudades">Below itinerary is changeable because of many reasons: festivals, strikes, holydays, car traffics, etc. if you are a Blogger, Top rated TripAdvisor Criticizer, Lonely Planet Agent or just a highly demanding customer, then we ask you kindly to check our policies to avoid misunderstandings; Nonetheless we will do our best so that you can have a great experience with us.</p>

                   <ul style="list-style-type: none" class="bi-ciudades">

                  <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span><b>Staying in downtown Lima?</b> <b>Already in downtown Lima?</b> Then join us by 11am <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima/@-12.048165,-77.0350339,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452">in front of La Mercerd Church</a>, at Jiron de La Union (This is the name of the street), Look for Inkan Milky Way Lima logo, <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima/@-12.048165,-77.0350339,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452">See our Google Map for Lima downtown,</a> best Free Tours by Foot in this city.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span><b><span class="text-danger">Don´t be late, come on time¡</span></b> once we gather all our attendees from Lima center and Miraflores, we will start the original free walking tour in Lima.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We will visit the Plaza Mayor of Lima & Presidential Palace(outdoor)</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>The Santo Domingo Church (indoor explanation) and the Rimac River as well.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>San Francisco Church (outdoor explanation) and the Congress Building (outdoor explanation).</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Palacio de José Bernardo Torre Tagle (Outdoor explanation).</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Remember this is free with only a tip at the end so don’t expect bells and whistles¡</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We finish our walk near the Plaza Mayor of Lima, just 1 min by walking.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Tourists who want to get back to Miraflores by using the Metropolitano Bus system, will be helped, you can have our word for it.</li>


                   </ul>
                    </div>

                    <div>
                       <div class="imagesit">
                        <img src="../img/ico-lima-11-30am/gothic-free-walks-lima.png" alt="gothic-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/best-picture-free-walks-lima.png" alt="best-picture-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/hoverment-palace-free-walks-lima.png" alt="hoverment-palace-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/history-free-walks-lima.png" alt="history-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/catholicis-free-walks-lima.png" alt="catholicis-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/inquires-free-walks-lima.png" alt="inquires-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/geo-orientation-free-walks-lima.png" alt="geo-orientation-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/travel-tips-free-walks-lima.png" alt="travel-tips-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/acomodation-tips-free-walks-lima.png" alt="acomodation-tips-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/peruvian-curine-free-walks-lima.png" alt="peruvian-curine-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/lisenced-company-free-walks-lima.png" alt="lisenced-company-free-walks-lima">
                        <img src="../img/ico-lima-11-30am/profesional-guides-free-walks-lima.png" alt="profesional-guides-free-walks-lima">

                        </div>
                    </div>

                    <div>
                    <ul style="list-style-type: none">
                   <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Where is our Meeting Point in Lima and Miraflores?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">
  
<span style="color: #e40ef2;font-weight: 600;">-10am Lima free tour:</span> If you staying in Miraflores, GET PICKED UP at <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Calle Schell</a> by Oechsle Mall at 10am &ndash; Keep in mind, you will be PICKED UP here for Lima downtown free walking tour, we will take the bus.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -<span style="color: #008080;">How to find our meeting point in Miraflores district?</span> We are just 2min to 5min AWAY from Kennedy Park(on foot). Use as Landmark Calle Schell, everybody knows this street,  <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Use our Google Maps</a><br>
<span>--------------------------------------------------------------------------------------------</span>
<br /> <span style="color: #e40ef2;font-weight: 600;">-11am Lima free tour:</span> If you are staying in downtown Lima, JOIN US in front of <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima/@-12.048165,-77.0350339,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452">La Merced Church</a> at 11am (in Jiron de la Union street).<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #008080; ">-How to find La Merced Church in downtown Lima?</span> We are just 2min to 3min AWAY from Plaza Mayor(on foot). Ask for Jiron de la Union, walk 3 blocks to the south from plaza mayor, ask for La Merced Church. <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima/@-12.048165,-77.0350339,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452">Use our Google Maps.</a><br>
<span>--------------------------------------------------------------------------------------------</span>
<br>
<span style="color: #e40ef2;font-weight: 600;">- How about if I am staying in Barranco?</span> please check this <a href="free-walking-tour-lima-barranco">link for Barranco</a> and make your booking for 11am and join us at la Merced church in downtown Lima, <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima/@-12.048165,-77.0350339,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452">Use our Google Maps.</a><br>
<br /> <span style="color: #ff0000;">Don&rsquo;t get confused with fake tour guides in Plaza Mayor.</span><br /> If you need further assistance, send us a <span style="color: #008000;">Whatsapp message to: +51 958745640 </span>or<span style="color: #008000;"> +51 984479073</span><br /> Keep in mind that our free tours are operated from Monday to Saturday &ndash;<span style="color: #ff0000;"> we don&rsquo;t operate on Sundays.</span>

 </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>How to recognize our Tour Guides at the Meeting Point in Lima and Miraflores?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> Look for Inkan Milky Way Logo-Sign, look for this sign at the Correct Meeting Place.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Where does the free tour end up in Lima?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> Tour ends near the Plaza Mayor, just 1 minute on foot.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>What’s an appropriate amount of tip for our free tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">This is our Philosophy for our Free Tour: <span style="color: #008080;">Pay what you think the tour was worth&iexcl;</span>, our free tours are from good to great quality, in simple terms, they are decent tours and a decent tour should be rewarded Generously, <span style="color: #ff0000;">Not with coins such as 2 soles or 5 soles.</span><br><br> Let us mean ourselves clear: <span style="color: #008080;">Pay What It's Worth is Not Pay what you can or what you like&rdquo;</span>. In New York, some free tour companies have the philosophy of &ldquo;Pay what you like&rdquo;, and this really good because New Yorkers are big Tippers however we are in South America where many people don&rsquo;t even have the Tipping culture.<br><br> Apart from this consider that your tour guide relies entirely on your tips, since no one of them are funded by NGO&acute;s or the government. Tips are also shared among the whole team.<br> Most tourists tip between twenty soles to thirty soles, this is subject to change according to the quality of the tour. Thanks</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Things to be brought:(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">
- Bring 2.50 soles if you meet us in Miraflores, this is for the bus ticket.<br>
- Sun Block Lotions.<br>
- Sun Glasses.<br>
- Hats.<br>
- Bottles of Water.<br>
- Walking Shoes.<br>
- BIG SMILE and WILLINGNESS TO WALK.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Available Languages in Lima:(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> English and Spanish, for both languages we need a considerable amount of tourists, so that we can make a unilingual guided group, otherwise will be in English only. </p>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>When is this happening?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> Our Lima free tour meet up times:<br>
At 10am & 11am every day from Mon to Sat only – Same free tour with 2 different meeting points - we don’t operate on Sundays. </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Do the free tours in Lima (10am & 11am) have different itinerary?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> No, our 10am & 11am free tour in Lima have the same itinerary, what it changes is the meeting point, the rest is the same.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Can we leave the free tour because we have other scheduled tours?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> You can always leave our free tour, if you have other tours or activities, however Don’t forget to tip your tour guide, Don’t escape, Don’t run away, Don’t walk away, Don’t ignore your tour guide, Don’t pretend that you don’t know our walks are tip based, Don’t pretend that you forgot to bring some tip.</p></li>
Thanks
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>What is the duration of our free tours in Lima?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> 
- If your free tour starts in Miraflores, it takes 3.5 hours approx. - If your free tour starts from downtown Lima, it takes 2.5 hours approx. </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Minimum walkers required to run the tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> 05 tourists, otherwise will be cancelled, for more info go to: <a href="../terms-conditions">our policies.</a> </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Maximum walkers allowed per group?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> 20 tourists either for English or Spanish, for more info go to: <a href="../terms-conditions">our policies.</a> From time to time we have large groups and one tour guide to manage the whole group, please don’t blame on your guide or the team, simply because most attendees don’t book in advance so cannot take a decision beforehand. </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We are a group of 11 or more. Can we make a reservation online?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> Groups or Families of 11 or more are more than welcome to <a href="../contact-us">contact us</a> before reserving and according to our available tour guides and available spot in our free tour whether we will accept or reject your participation in our free tours. From experience we know that large groups have the tendency to NOT pay attention to the Tour Guide´s explanation which is so disrespectful for both the guide and other attendees.<br>

However if you happen to forget to book your large group, you can always show up at the meeting point, we will take care of you, just don’t expect the best of the best, remember it is free tour, if you want the best from the best look for a private tour. </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We are a group of 11 or more. Can we have a private free tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> NO, our free tour service is a group service, you will join other attendees.<br>
Even if you are 20 people, we still say no, because from experience we know that big groups of friends or mates Do Not pay attention to our Tour Guide’s explanation.<br>
Because of this reason, we advise you to take a Private tour (pre-paid) however if you want to take our free tour, you must <a href="../contact-us">contact us</a> in advance so that you can join our GROUP service (Not private).</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Can our free tours ever get cancelled because of weather, protests or festivities in Lima?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">
- When it comes to Protests we might cancel our free tour, this can happen without a previous notification, so we ask for your understanding in advance.<br>
- If there are Festivities, we might cancel also.<br>
- No weather conditions can affect our free tour in Lima, because no rain in this city.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We use crutches, can we participate in your free tours?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> Yes, you can as long as you are capable to walk and stand on your feet for some minutes while your guide explains about some historical spots. </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We use wheelchair, can we participate in your free tours?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none"> Unfortunately the answer is NO, because most streets in Peru are not yet designed for Wheelchair users, this issue is out from our hands to solve. We kindly encourage you to take a private tour instead, make sure you have a person that can help you. </p></li>

                     
                    <a href="#" class="alternar-todo"id="alternar-todo">Show and hide all answers</a>

                    </ul>
                    </div>
                </div>
            </div>



         </section>

      </section>

      <aside class="derecha">
        <div class="redes-movil mt-3 visible-xs">
        <section class="redes-s" style="width: 100%;font-size: 12px; border-radius: 5px;">
  <div class="row text-center mt-2 mb-3">
  <span class="tex-center">
  <h4 id="titlea-side">Make a wise decision in Lima, see our awesome 200+ reviews at:</h4>

   <a href="https://web.facebook.com/inkanmilkywaylimafreewalkingtour/"><i class="fab fa-facebook"></i></a>
   <a href="https://www.youtube.com/channel/UCjCwOb8Uayzl2pCLsntighg"><i class="fab fa-youtube-square"></i></a>
   <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294316-d14918493-Reviews-Inkan_Milky_Way_Tours_Lima-Lima_Lima_Region.html"><img src="/img/trip-advisor.jpg" class="mt-1" alt="" width="38" height="35"></a>
   <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1"><img src="/img/google-b.png" alt="" style="" width="40" height="38"></a>
   <a href="https://plus.google.com/+FreeWalkingToursLimaDistritodeLima"><i class="fab fa-google-plus-square"></i></a>
</span>
  </div>
</section>
        </div>
        <?php include('../cuadro-reservas-lima.php');?>
        <div class="blogpage hidden-xs">

</div>
        <div class="mapadetalle">
        <h2 class="hidden-xs"> <span class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span> Click the Map to See</h2>
        <div class="centrarmapa mb-5"><img id="myImg" src="../img/map-lima-free-tour-11am-3pm.png" alt="Free Walking Tour Lima 11am"  height="200"></div>

        <!-- The Modal -->
        <div id="myModal" class="modal">
          <span class="close">×</span>
          <img class="modal-content" id="img01" alt="mapa ubicacion">
          <div id="caption"></div>
        </div>
        </div>

      </aside>
      <section class="redes-s hidden-xs" style="float: left;
width: 100%;
border: 2px solid #c8cbc4;
background-color: #ede58a;font-size: 1.7em;">
  <div class="row text-center mt-2 mb-3">
  <span class="tex-center">
  Make a wise decision in Lima, see our awesome 200+ reviews at:

   <a href="https://web.facebook.com/inkanmilkywaylimafreewalkingtour/"><i class="fab fa-facebook"></i></a>
   <a href="https://www.youtube.com/channel/UCjCwOb8Uayzl2pCLsntighg"><i class="fab fa-youtube-square"></i></a>
   <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294316-d14918493-Reviews-Inkan_Milky_Way_Tours_Lima-Lima_Lima_Region.html"><img src="/img/trip-advisor.jpg" class="mt-1" alt="" width="38" height="35"></a>
   <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1"><img src="/img/google-b.png" alt="" style="" width="40" height="38"></a>
   <a href="https://plus.google.com/+FreeWalkingToursLimaDistritodeLima"><i class="fab fa-google-plus-square"></i></a>
</span>
  </div>
</section>
       <div class="maps-c mb-5">
        <h3 class="text-center mt-1" style="float: left;width: 100%;font-size: 1.6em;">Meeting Point Map for our Lima Free Tours at 11am – Google maps</h3>
       <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15607.730017414839!2d-77.0328452!3d-12.048165!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x260b4404fb6284e!2sInkan+Milky+Way+Lima!5e0!3m2!1sen!2spe!4v1522845935126" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
       <div class="contenedormap"></div>
     </div>
    <div class="carousel-reviews broun-block hidden-xs">
 <h3 class="text-center mt-3" style="float: left;width: 100%;font-size: 1.6em;">What our customers are saying about us¡</h3>     
    <div class="container">
        <div class="">
            <div id="carousel-reviews1" class="carousel slide" data-ride="carousel"  data-interval="5000">
            
                <div class="carousel-inner">
                    <div class="item active">
                            <div class="col-md-4 col-sm-6">
                                  <div class="block-text rel zmin">
                                  <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Free Walking Tour Lima with Richard</a>
                                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                                  <p>We went on the walking tour with Richard. He met us in Miraflores and we took the bus to central Lima. This was very helpful as we learnt how to use the metro bus. We met the rest of the group and spent almost 3 hours seeing the main sights of Lima. Richard was very detailed and gave us lots of interesting information about the city and its history. Highly recommended. We also did a walking tour of Cusco with Incan Milky Way which is also great!</p>
                                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                </div>
                            <div class="person-text rel">
                               <img alt="" src="../img/reviews/free-walking-tour-lima (9).jpg" width="80">    
                              <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Stephanie Kelsall</a>
                          <!--     <i>from Glasgow, Scotland</i> -->
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 hidden-xs">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Decent Free Walking Tour in Lima center</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>Richard gave a quality tour where he took us around the historic part of downtown Lima, and we got to know the important buildings and their corresponding history. I'm glad we got to do the tour, otherwise without it, I would have missed out on a lot of historic information I would have liked to know about Peru. He speaks in both Spanish and English so it's certainly for everyone!  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="../img/reviews/free-walking-tour-lima (6).jpg" width="80">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Clara Lam</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>

                  <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Extremely knowledgeable tour Guide</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>Richard was an amazing tour guide! He is extremely knowledgeable and provided a highly comprehensive and entertaining tour. I learned so much about Lima and Peru on this tour and saw things I would’ve not noticed on my own. Highly highly recommend you do this on one of your first days in the city to get an overview - your trip will be all the richer after!<br>

                    The same company operates in Cusco! We will be taking that one there as well</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="../img/reviews/free-walking-tour-lima (5).jpg" width="80">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wendy Yang</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>

          </div>

          

    



                    <div class="item ">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Fantastic experience by walking</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                  <img alt="" src="../img/reviews/free-walking-tour-lima (3).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Ariana S</a>
              <!--   <i>from Glasgow, Scotland</i> -->
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wonderful free tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>I completed the Free Walking Tours Lima and Ricardo was a VERY informative guide. He may have spoken a little quickly, but from experience; I know this is how the folk from S. America speak. I think he tried to lose me during the "Changing of the guards" at the Presidential Palace, but I was fortunate to find the group and continue on. Ricardo even spoke of great restaurants to eat at and even had the pleasure and dining with him. He was a very cordial individual and would recommend his tour highly more than anyone else's on the web. Thanks again for a wonderful tour!!! Your friend--Matt.  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (1).jpg" width="80">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Matt Moore</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Tours a pie con Elvis</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Buen tour. 3 horas de información interesante e historias sobre Lima y Peru que no conocíamos en muy buen inglés. Realizamos el tour con Elvis. Muy buen guía, agradable y auténtico. ¡Definitivamente vale la pena! Good tour. 3 hours of interesting information and stories about Lima and Peru we did not know, in a very good English. We made the tour with Elvis. Very good guide, nice and authentic. Definitely I recommend it!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (4).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">TereDattari MargaPineda</a>
              </div>
            </div>
                    </div>



                    <div class="item">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="#">Enthusiastic Tour Guide, Elvis</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>It was a nice and very informative tour and our guide Elvis was very enthusiastic. It lasted for 3,5 hours and ended with the choice of having lunch together. It would have been nice with a short break for refreshments during the tour. Otherwise I'm very satisfied and would definitely recommend it.</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (8).jpg" width="80">
                <a title="" href="#">Hilma Hård af Segerstad</a>
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="#">Super informative tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (7).jpg" width="80">
                    <a title="" href="#">Ariana Joy </a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="#">Historia y Cultura en tour Lima</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Richard nos introdujo en la historia y arquitectura y vida social del centro histórico de Lima demostrando un gran conocimiento de la historia y la sociedad limeña. Con muchas anécdotas y amenas historias nos acompañó en este tour que nos resultó excelente. Felicitaciones!!! </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (2).jpg" width="80">
                <a title="" href="#">Pablo Zorrilla</a>
              </div>
            </div>
                    </div>
         
                                    
                </div>
                <a class="left carousel-control" href="#carousel-reviews1" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-reviews1" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </div>
    </div>

</div>


<div class="carousel-reviews broun-block hidden-sm hidden-md hidden-lg">

<h3 class="text-center mt-1 hidden-xs " style="float: left;width: 100%;font-size: 1.6em;">What our customers are saying about us¡</h3>
    <div class="container">
        <div class="">
            <div id="carousel-reviews" class="carousel slide" data-ride="carousel"  data-interval="5000">
            
                <div class="carousel-inner">
                    <div class="item active">
                            <div class="col-md-4 col-sm-6">
                                  <div class="block-text rel zmin">
                                 <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Free Walking Tour Lima with Richard</a>
                                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                                  <p>We went on the walking tour with Richard. He met us in Miraflores and we took the bus to central Lima. This was very helpful as we learnt how to use the metro bus. We met the rest of the group and spent almost 3 hours seeing the main sights of Lima. Richard was very detailed and gave us lots of interesting information about the city and its history. Highly recommended. We also did a walking tour of Cusco with Incan Milky Way which is also great!</p>
                                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                </div>
                            <div class="person-text rel">
                               <img alt="" src="../img/reviews/free-walking-tour-lima (9).jpg" width="80">    
                              <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Stephanie Kelsall</a>
                          <!--     <i>from Glasgow, Scotland</i> -->
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 hidden-xs">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Decent Free Walking Tour in Lima center</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>Richard gave a quality tour where he took us around the historic part of downtown Lima, and we got to know the important buildings and their corresponding history. I'm glad we got to do the tour, otherwise without it, I would have missed out on a lot of historic information I would have liked to know about Peru. He speaks in both Spanish and English so it's certainly for everyone!  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="../img/reviews/free-walking-tour-lima (6).jpg" width="80">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Clara Lam</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>

                  <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Extremely knowledgeable tour Guide</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>Richard was an amazing tour guide! He is extremely knowledgeable and provided a highly comprehensive and entertaining tour. I learned so much about Lima and Peru on this tour and saw things I would’ve not noticed on my own. Highly highly recommend you do this on one of your first days in the city to get an overview - your trip will be all the richer after!<br>

                    The same company operates in Cusco! We will be taking that one there as well</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="../img/reviews/free-walking-tour-lima (5).jpg" width="80">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wendy Yang</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>

          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Decent Free Walking Tour in Lima center</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>Richard gave a quality tour where he took us around the historic part of downtown Lima, and we got to know the important buildings and their corresponding history. I'm glad we got to do the tour, otherwise without it, I would have missed out on a lot of historic information I would have liked to know about Peru. He speaks in both Spanish and English so it's certainly for everyone!  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="../img/reviews/free-walking-tour-lima (6).jpg" width="80">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Clara Lam</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>
          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Extremely knowledgeable tour Guide</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>Richard was an amazing tour guide! He is extremely knowledgeable and provided a highly comprehensive and entertaining tour. I learned so much about Lima and Peru on this tour and saw things I would’ve not noticed on my own. Highly highly recommend you do this on one of your first days in the city to get an overview - your trip will be all the richer after!<br>

                    The same company operates in Cusco! We will be taking that one there as well</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="../img/reviews/free-walking-tour-lima (5).jpg" width="80">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wendy Yang</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>
          </div>



                    <div class="item ">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Fantastic experience by walking</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                  <img alt="" src="../img/reviews/free-walking-tour-lima (3).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Ariana S</a>
              <!--   <i>from Glasgow, Scotland</i> -->
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wonderful free tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>I completed the Free Walking Tours Lima and Ricardo was a VERY informative guide. He may have spoken a little quickly, but from experience; I know this is how the folk from S. America speak. I think he tried to lose me during the "Changing of the guards" at the Presidential Palace, but I was fortunate to find the group and continue on. Ricardo even spoke of great restaurants to eat at and even had the pleasure and dining with him. He was a very cordial individual and would recommend his tour highly more than anyone else's on the web. Thanks again for a wonderful tour!!! Your friend--Matt.  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (1).jpg" width="80">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Matt Moore</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Tours a pie con Elvis</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Buen tour. 3 horas de información interesante e historias sobre Lima y Peru que no conocíamos en muy buen inglés. Realizamos el tour con Elvis. Muy buen guía, agradable y auténtico. ¡Definitivamente vale la pena! Good tour. 3 hours of interesting information and stories about Lima and Peru we did not know, in a very good English. We made the tour with Elvis. Very good guide, nice and authentic. Definitely I recommend it!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (4).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">TereDattari MargaPineda</a>
              </div>
            </div>
                    </div>


          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wonderful free tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>I completed the Free Walking Tours Lima and Ricardo was a VERY informative guide. He may have spoken a little quickly, but from experience; I know this is how the folk from S. America speak. I think he tried to lose me during the "Changing of the guards" at the Presidential Palace, but I was fortunate to find the group and continue on. Ricardo even spoke of great restaurants to eat at and even had the pleasure and dining with him. He was a very cordial individual and would recommend his tour highly more than anyone else's on the web. Thanks again for a wonderful tour!!! Your friend--Matt.  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (1).jpg" width="80">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Matt Moore</a>
              </div>
            </div>
          </div>


          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
              <div class="block-text rel zmin">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Tours a pie con Elvis</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Buen tour. 3 horas de información interesante e historias sobre Lima y Peru que no conocíamos en muy buen inglés. Realizamos el tour con Elvis. Muy buen guía, agradable y auténtico. ¡Definitivamente vale la pena! Good tour. 3 hours of interesting information and stories about Lima and Peru we did not know, in a very good English. We made the tour with Elvis. Very good guide, nice and authentic. Definitely I recommend it!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (4).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">TereDattari MargaPineda</a>
              </div>
            </div>
          </div>
                    <div class="item">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="#">Enthusiastic Tour Guide, Elvis</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>It was a nice and very informative tour and our guide Elvis was very enthusiastic. It lasted for 3,5 hours and ended with the choice of having lunch together. It would have been nice with a short break for refreshments during the tour. Otherwise I'm very satisfied and would definitely recommend it.</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (8).jpg" width="80">
                <a title="" href="#">Hilma Hård af Segerstad</a>
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="#">Super informative tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (7).jpg" width="80">
                    <a title="" href="#">Ariana Joy </a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="#">Historia y Cultura en tour Lima</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Richard nos introdujo en la historia y arquitectura y vida social del centro histórico de Lima demostrando un gran conocimiento de la historia y la sociedad limeña. Con muchas anécdotas y amenas historias nos acompañó en este tour que nos resultó excelente. Felicitaciones!!! </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (2).jpg" width="80">
                <a title="" href="#">Pablo Zorrilla</a>
              </div>
            </div>
                    </div>

                    <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                <div class="block-text rel zmin">
                    <a title="" href="#">Super informative tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (7).jpg" width="80">
                    <a title="" href="#">Ariana Joy </a>
              </div>
            </div>
          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
              <div class="block-text rel zmin">
                <a title="" href="#">Historia y Cultura en tour Lima</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Richard nos introdujo en la historia y arquitectura y vida social del centro histórico de Lima demostrando un gran conocimiento de la historia y la sociedad limeña. Con muchas anécdotas y amenas historias nos acompañó en este tour que nos resultó excelente. Felicitaciones!!! </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="../img/reviews/free-walking-tour-lima (2).jpg" width="80">
                <a title="" href="#">Pablo Zorrilla</a>
              </div>
            </div>
          </div>


                                    
                </div>
                <a class="left carousel-control" href="#carousel-reviews" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-reviews" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </div>
    </div>
</div> 


<section class="booknow visible-xs">
<div class="btn-reserva">
  <a href="#titlea-side"><button type="button" class="btn btnreserva2 active">Book Now </button></a>
  <p style="text-align: center; font-size: 1.2em !important;color: #181818;">We are not just a WebSite, We are REVIEWED by more than 250 testimonials, decide wisely¡¡¡</p>
</div>
</section>

<section class="booknow visible-lg">
<div class="btn-reserva">
  <a href="#derecha"><button type="button" class="btn btnreserva2 active">Book Now </button></a>
  <p style="text-align: center; font-size: 1.2em !important;color: #181818;">We are not just a WebSite, We are REVIEWED by more than 250 testimonials, decide wisely¡¡¡</p>
</div>
</section>

      <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Home</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/lima/" itemprop="url" title="Lima" class="linkgeneral">
                                      <span itemprop="title">Lima</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Free Walking Tour Lima at 11am</strong>
                                  </div>
                  </div>
    <div class="banners mt-5">
         <img src="../img/imgfooter.jpg" alt="publicidad logos">
      </div>
    <?php include('../footer.php');?>

    </div>

    </div>
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>

    
     <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/easy-responsive-tabs.js"></script>
     <script src="../js/script-efectos.js"></script>
     <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

         <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>

   <script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>

    <script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submitlima.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>

   <style>
    #owl-demo .item{
        margin: 3px;
    }
    #owl-demo .item img{
        display: block;
        width: 100%;
        height: auto;
    }
    </style>

    
  </body>

</html>


