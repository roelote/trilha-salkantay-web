<?php

if($_POST)
{
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phno = $_POST['phno'];

$from = $_POST['email'];
$subject = 'reserva tour';
$message = 'Nombre: ' . $fname . 
"\n". 'E-mail: ' . $email. 
"\n". 'Asunto:' . $lname. 
"\n". 'Mensaje:' . $phno;

$headers = "From: ". $from . "\n";
mail ('info@freewalkingtoursperu.com', $subject, $message, $headers);


	?>
    
    <table border="0">
    
    <tr>
    <td colspan="2">Succedd !!!</td>
    </tr>
    
    <tr>
    <td>Your Name:</td>
    <td><?php echo $fname ?></td>
    </tr>

    
    <tr>
    <td>Your eMail</td>
    <td><?php echo $email; ?></td>
    </tr>

    
    <tr>
    <td>Subject:</td>
    <td><?php echo $lname ?></td>
    </tr>
    
    <tr>
    <td>comment</td>
    <td><?php echo $phno; ?></td>
    </tr>
    
    </table>
    <?php
	
}

?>

<?php
$from = $_POST['email'];
$subject = 'Pregunta free walks';
$message = 'Nombre: ' . $_POST['name'] . 
"\n". 'E-mail: ' . $_POST['email']. 
"\n". 'Nacionalidad:' . $_POST['nationality']. 
"\n". 'Asunto:' . $_POST['subject'].
"\n". 'Mensaje:' . $_POST['data'];


$headers = "From: ". $from . "\n";
mail ('info@freewalkingtoursperu.com', $subject, $message, $headers);


?>