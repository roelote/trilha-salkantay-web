<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tours Peru | Lima | Miraflores | Arequipa | Cusco </title>
    <meta content="Free Walking Tours Peru offers Free Walks Lima, Miraflores, Arequipa and Cusco, They all take 2.5h to 3.5h approx. Look for the FTF Logo on the Yellow Vests" name="description" />
    <meta content="Free Walking Tour Peru, cusco, lima, arequipa, miraflores, free tours by foot, free walk" name="keywords" />
    <meta content="en" name="language" />
   <meta name="author" content="Free Walking Tours" />
    <!-- Bootstrap -->
    <link rel="icon" type="image/ico" href="/img/favicon.ico" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/responsiveslides.css" rel="stylesheet">
    <link href="css/stylefwt.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />



  </head>
  <body>

  <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');

</script>

    <div class="container">
      <header class="cabecera">

      <div class="slider">
            <div id="wrappers" class="relativo over-effect">
          <!-- Slideshow 1 -->
                <ul class="rslides" id="slider2">

                  <li><img src="img/fondo.jpg" alt="free walking tours peru"> <div class="texto-slider"> <img alt="Feel Free Tours" src="img/chalecos.png" class="img-responsive logo">
                  <h2 class="h2slider"> Free Tours by Foot Peru - FTF Peru </h2>
                  <h2 class="contenido-texts">Hi Dear Peru Walkers, we do have Free Walking Tours in Peru such us Lima, Miraflores, Arequipa and Cusco. At this company we DO NOT OVERPROMISE and UNDERDELIVER, All ours tour are at no upfront cost otherwise tip based ONLY, they take 2.5h to 3.5h and they include History, Culture, Lifestyle, Travel Emotions and Samples, led by Lincensed and Professional Tour Guides and Staff.</h2> </div></li>

                  <li><img src="img/fondo1.jpg" alt="free walking tours lima"> <div class="texto-slider"><img alt="Feel Free Tours" src="img/chalecos.png" class="img-responsive logo">
                  <h2 class="h2slider"> Free Tours by Foot Lima - FTF Lima </h2> 
                  <h2 class="contenido-texts">Hi Dear Lima Walkers, we do have two Free Walking Tours in Lima every day at 10:30am&11:30am, Meet us at Ovalo Miraflores by 10:30 and at Plaza de Armas(by the fountain) by 11:30am, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused. </h2></div></li>

                  <li><img src="img/fondo2.jpg" alt="free walking tours miraflores"> <div class="texto-slider"><img alt="Feel Free Tours" src="img/chalecos.png" class="img-responsive logo">
                  <h2 class="h2slider textomaspequenio">Free Tours by Foot Miraflores - FTF Miraflores </h2> 
                  <h2 class="contenido-texts">Hi Dear Miraflores Walkers, we do have one Free Walking Tour in Miraflores District(Lima) every day at 04:15pm, Meet us at Ovalo Miraflores ONLY, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused. </h2></div></li>

                  <li><img src="img/fondo2.jpg" alt="free walking tours arequipa"> <div class="texto-slider"><img alt="Feel Free Tours" src="img/chalecos.png" class="img-responsive logo">
                  <h2 class="h2slider textomaspequenio">Free Tours by Foot Arequipa - FTF Arequipa  </h2> 
                  <h2 class="contenido-texts">Hi Dear Arequipa Walkers, we do have two Free Walking Tours in Arequipa every day at 10:00am&3:00pm, for all free tours meet us at Santa Catalina street #204-Choco Factory ONLY, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused. </h2></div></li>

                  <li><img src="img/fondo2.jpg" alt="free walking tours cusco"> <div class="texto-slider"><img alt="Feel Free Tours" src="img/chalecos.png" class="img-responsive logo">
                  <h2 class="h2slider">Free Tours by Foot Cusco - FTF Cusco  </h2> 
                  <h2 class="contenido-texts">Hi Dear Cusco Walkers, we do have three Free Walking Tours in Cusco from Mon to Sat at 10:00am&1:00pm&3:30pm, On Sun at 12:20pm only. For all free tours meet us at Plaza Regocijo ONLY, Look for the FTF logo on the YELLOW VESTS ONLY, Do not get confused.  </h2></div></li>

                </ul>
          </div>
      </div>
          <?php include('menu.php');?>

      </header>
    <div class="cuerpo">

      <section class="container izquierda">

                    <div class="margin0 row col-lg-12 col-lg-12 col-xs-12">
                      <section class="content">

                      <h1>FREE WALKING TOURS PERU - LIMA - MIRAFLORES - AREQUIPA - CUSCO by FTF PERU </h1>
                      <article>
                      <p>You have a very nice warm welcome to <strong>Free Walking Tours Peru</strong> powered by <strong>Free Tours by Foot Peru</strong> - FTF, this is a private (non sponsored by no government) project that was established to teach history from Pre-Colombian Times, Incan Period, Colonial and Republican Times to our visitors from all over the world in <strong>Free Walking Tours LIMA</strong>, <strong>Free Walking Tours MIRAFLORES</strong>, <strong>Free Walking Tours AREQUIPA</strong> and <strong>Free Walking Tours CUSCO</strong>, through a new system based on pay what you like tours after the service, performed by a group of young well experienced travelers and tour guides specialized on both organized <strong>Walking Tours</strong> and bespoke Tours in Peru.</p>
                      
                      </article>

                      <ul class="redes_sociales">
                        <li><a href="https://es.pinterest.com/freetoursperu/" target="_blank"><i class="fa fa-pinterest-square" aria-hidden="true"></i></a></li>
                        <li><a href="https://www.facebook.com/FreeWalkingToursPeru" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></li>    
                        <li><a href="https://www.youtube.com/channel/UCw96I0FBc-Bo3NY6ipUkHVg" target="_blank"><i class="fa fa-youtube-square" aria-hidden="true"></i></a></li>
                        <li><a href="https://twitter.com/freetoursperu" target="_blank"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
                        <li><a href="https://plus.google.com/+Inkanmilkyway-freewalkingtourscusco" target="_blank"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>

                            
                        </ul>
                    </section>

                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-lg-6 col-sm-6 col-xs-12">

                                 <div class="fotofwt a-fijo">
                                   
                                        <div class="center positiontitleimg"> 
                                         <a href="/lima/">
                                          <h2><span class="tours-time limancolor"><span class="rojo">Free Walking Tours</span> Lima</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                          <div id="myCarousel2" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-lima-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                              <!-- <div class="item">
                                                <img src="img/free-walking-tour-lima-2.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                              <div class="item">
                                                <img src="img/free-walking-tour-lima-3.jpg" alt="Flower" width="460" height="345">
                                              </div> -->
                                            </div>
                                            <!-- Left and right controls -->
                                            <a class="left carousel-control" href="#myCarousel2" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel2" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                               <!-- <img class="efectoimg"src="img/t2.jpg"> -->
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/lima/">
                                               <span class="time"><span class="days">Dayly Walks</span>10:30am & 11:30am</span> 
                                            </a>
                                          </div>
                                       
                                </div>
                            
                               
                        
                                  <div class="fotofwt a-fijo">
                                  
                                         <div class="center positiontitleimg"> 
                                         <a href="/arequipa/">
                                          <h2><span class="tours-time arequipacolor"><span class="rojo">Free Walking Tours</span> Arequipa</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                               <!-- <img class="efectoimg"src="img/t4.jpg"> -->
                                               <div id="myCarousel4" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-arequipa-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                              <!-- <div class="item">
                                                <img src="img/free-walking-tour-arequipa-2.jpg" alt="Chania" width="460" height="345">
                                              </div> -->
                                             <!--  <div class="item">
                                                <img src="img/free-walking-tour-arequipa-3.jpg" alt="Flower" width="460" height="345">
                                              </div> -->
                                            
                                            </div>
                                            <!-- Left and right controls -->
                                            <a class="left carousel-control" href="#myCarousel4" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel4" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/arequipa/">
                                               <span class="time"><span class="days">Dayly Walks</span>10:00am & 3.00pm</span> 
                                            </a>
                                          </div>
                                </div>
                     </div>

                      <div class="col-lg-6 col-lg-6 col-sm-6 col-xs-12">
                            
                                <div class="fotofwt a-fijo">
                                   
                                         <div class="center positiontitleimg"> 
                                         <a href="/miraflores/">
                                          <h2><span class="tours-time limacolor"><span class="rojo">Free Walking Tours</span> Miraflores</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                          <div id="myCarousel3" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-miraflores-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                             <!--  <div class="item">
                                                <img src="img/free-walking-tour-miraflores-2.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                              <div class="item">
                                                <img src="img/free-walking-tour-miraflores-3.jpg" alt="Flower" width="460" height="345">
                                              </div> -->
                                            </div>
                                            <!-- Left and right controls -->
                                            <a class="left carousel-control" href="#myCarousel3" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel3" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                             <!--   <img class="efectoimg"src="img/t3.jpg"> -->
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/miraflores/">
                                               <span class="time"><span class="days">Dayly Walks</span>4:15pm</span> 
                                            </a>
                                          </div>
                                          
                                </div>

                                 <div class="fotofwt a-fijo">
                                         <div class="center positiontitleimg"> 
                                         <a href="/cusco/">
                                          <h2><span class="tours-time cuscocolor"><span class="rojo">Free Walking Tours</span> Cusco</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                            <div id="myCarousel1" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-cusco-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                              <!-- <div class="item">
                                                <img src="img/free-walking-tour-cusco-2.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                              <div class="item">
                                                <img src="img/free-walking-tour-cusco-3.jpg" alt="Flower" width="460" height="345">
                                              </div> -->
                                            </div>
                                            <!-- Left and right controls -->
                                            <a class="left carousel-control" href="#myCarousel1" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel1" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                              
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/cusco/">
                                                
                                                <span class="time"><span class="days dayly">Walks Mon to Sat</span>10:00am & 1:00pm & 3.30pm
                                                <span class="days dayly">on Sun</span>
                                                12.20pm </span> 
                                            </a>
                                          </div>
                                </div>
                        
                                
                     </div>
            </div>
      </section>
      <aside class="derecha">
<div class="tripadvisor">
  <div id="TA_cdsratingsonlynarrow448" class="TA_cdsratingsonlynarrow">
<ul id="lcqzktl5F" class="TA_links iHAorEkhX">
<li id="k14sp8OALJ" class="OQePi0jRk2l">
<a target="_blank" href="https://www.tripadvisor.com.pe/"><img src="https://www.tripadvisor.com.pe/img/cdsi/img2/branding/tripadvisor_logo_transp_340x80-18034-2.png" alt="TripAdvisor"/></a>
</li>
</ul>
</div>
<script src="https://www.jscache.com/wejs?wtype=cdsratingsonlynarrow&amp;uniq=448&amp;locationId=7238744&amp;lang=es_PE&amp;border=true&amp;shadow=false&amp;backgroundColor=white&amp;display_version=2"></script>

</div>

<div class="facebookpubli">
  <iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2FFreeWalkingToursPeru%2Fposts%2F549941675195650&width=500" width="95%" height="404" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
  
</div>

<div class="blog-wp">

<section id="blog-pirwa" class="cuadro-contenedor cuadro-texto">
                    <hgroup>
                    <a href="/blog/">
                        <h3 class="title titlepeq"><span>Blog</span> Free Walks Peru </h3>
                      </a> 
                    </hgroup>
                   <?php
                include('blog/wp-load.php');
                $recent_posts = wp_get_recent_posts(array(
                'numberposts' => 3,
                'post_status' => 'publish'
                ));
                echo '';
                foreach($recent_posts as $post1) {?>
                <?php $j++;?>
                                <div class="contenido-blog">
                                      <a href="<?=get_permalink($post1['ID']) ?> ">
                                            <h4 class="titulo-blog">
                                            <?php 
                      echo $post1['post_title'];?>                                            
                                            </h4> </a>
                                            <span class="fecha-blog">Posted on <?php echo get_the_time('d/F', $post1['ID']); ?></span>
                </div>
                <?php }?> 
           </section> 



           <h2>Recent Posts</h2>
<ul>
<?php
  $args = array( 'numberposts' => '3', 'tax_query' => array(
      array(
        'taxonomy' => 'post_format',
        'field' => 'slug',
        'terms' => 'post-format-aside',
        'operator' => 'NOT IN'
      ), 
      array(
        'taxonomy' => 'post_format',
        'field' => 'slug',
        'terms' => 'post-format-image',
        'operator' => 'NOT IN'
      )
  ) );
  $recent_posts = wp_get_recent_posts( $args );
  foreach( $recent_posts as $recent ){
    echo '<li><a href="' . get_permalink($recent["ID"]) . '">' .   ( __($recent["post_title"])).'</a> </li> ';
  }
?>
</ul>

</div>




  
      </aside>

   <div class="banners">
       <img src="img/imgfooter.jpg" alt="">
    </div>


    </div>

   <?php include('footer.php');?>
   
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/responsiveslides.min.js"></script>

        <script>
        // You can also use "$(window).load(function() {"
        $(function () {
          // Slideshow 1
            $("#slider2").responsiveSlides({
              maxwidth: 1600,
              speed: 500
            });
        });
    </script>
  </body>


</html>