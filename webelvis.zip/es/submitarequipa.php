
<?php
if($_POST)
{
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phno = $_POST['phno'];
    $fecha=$_POST['date'];
    $nombretours = $_POST['nombretour'];

    

$from = $_POST['email'];

$subject = 'Free Walks Arequipa - Español';
$subject2= 'Sus Detalles de CONFIRMACIÓN - Arequipa';
$message = 
'<table width="300" border="1" align="center" cellpadding="1" cellspacing="1"
  <tr>
    <th colspan="2">Tours a Pie Arequipa<br></th>
  </tr>
  <tr>
    <td>Nombre<br></td>
    <td>'.$fname.'</td>
  </tr>
  <tr>
    <td>Tour<br></td>
    <td>'.$nombretours.'</td>
  </tr>
  <tr>
    <td>Fecha<br></td>
    <td>'.$fecha.'</td>
  </tr>
  <tr>
    <td>Nro Pax<br></td>
    <td>'.$lname.'</td>
  </tr>
  <tr>
    <th colspan="2">Mensaje<br></th>
  </tr>
   <tr>
   <th colspan="2">'.$phno.'<br></th>
  </tr>
</table>';

$message2 = 
'<table style="height: 173px; width: 506.433px;" border="1">
<tbody>
<tr>
<td style="width: 169px;">Compa&ntilde;ia:</td>
<td style="width: 312.433px; text-align: center;"><strong>Compa&ntilde;ia que recomendamos es</strong><br />Free Tour Downtown Arequipa</td>
</tr>
<tr>
<td style="width: 169px;">Nombre:</td>
<td style="width: 312.433px;">&nbsp;'.$fname.'</td>
</tr>
<tr>
<td style="width: 169px;">Tama&ntilde;o del Grupo:</td>
<td style="width: 312.433px;">&nbsp;'.$lname.'</td>
</tr>
<tr>
<td style="width: 169px;">Fecha del Tour a Pie:</td>
<td style="width: 312.433px;">&nbsp;'.$fecha.'</td>
</tr>
<tr>
<td style="width: 169px;">Hora de Inicio de Tour:</td>
<td style="width: 312.433px;">&nbsp;'.$nombretours.'</td>
</tr>
<tr>
<td style="width: 169px;">Lugar de Encuentro:</td>
<td style="width: 312.433px; text-align: center;">Ub&iacute;quenos en la <a href="https://www.freewalkingtoursperu.com/es/arequipa/punto-de-partida-horarios/">Calle Santa Catalina #204</a> dentro de la <strong>factor&iacute;a de Chocolate Chaqchao<br /></strong></td>
</tr>
</tbody>
</table>
<p>Gracias por reservar con nuestro free tour partner en Arequipa, pres&eacute;ntese en el punto de encuentro correcto.</p>
<ul>
<li>Si se perdi&oacute; su free tour, recuerde que tenemos los siguientes horarios&nbsp; de Lunes a Domingo a 10am &ndash; 3pm, considere que todos los free tours los domingos son solamente en Ingles.</li>
<li>Cualquier comentario, escriba <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5388673,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786!9m1!1b1">aqu&iacute;</a> por favor, es muy valioso.</li>
<li>Vea nuestro Punto de encuentro en <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5388673,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786">Google maps</a>.</li>
</ul>
<p style="text-align: center;"><span style="background-color: #ff0000; color: #ffffff;">TENGA CUIDADO en LIMA!</span></p>
<ul>
<li>Si viene a Lima, <span style="color: #ff0000;">Tenga cuidado con Guias Falsos vistiendo chalecos Amarillos Falsos SIN</span> nuestro Logo: Inkan Milky Way Tours Lima.</li>
<li>Somos gu&iacute;as profesionales, graduados de Institutos y Universidades, somos una compa&ntilde;&iacute;a legalmente establecida, pagamos nuestros impuestos, la calidad en nuestros tours y la seguridad en su estad&iacute;a en Lima es nuestra prioridad.</li>
<li>Para nuestros free tours en Lima, &uacute;nase a <a href="https://www.freewalkingtoursperu.com/es/lima/">Inkan Milky Way Tours Lima</a> recomendado por m&aacute;s de <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1">200 comentarios reales</a> y tenga un free tour decente.</li>
</ul>
<p>&nbsp;<span style="font-size: 12pt;"><strong style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #888888;"><span style="font-size: 14px; color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><img src="http://www.inkanmilkyway.com/wp-content/uploads/2018/05/free-walking-tours-map-arequipa-es.png" alt="Meeting Point Cusco" width="433" height="251" /></span></strong></span></p>
<p><strong style="font-size: 14px; margin: 0px; font-family: Arial, Helvetica, sans-serif;">Operador del Free Tour en Arequipa: </strong><span style="font-family: Arial,Helvetica,sans-serif; font-size: 10pt;"><span style="color: #bd1398;"><br /></span><span style="color: #bd1398;">Free Tour Downtown Arequipa &ndash; <span style="color: #000000;">Cualquier inconveniencia responda al correo o cont&aacute;ctese con el n&uacute;mero abajo:</span></span><span style="font-size: 9pt; font-family: sans-serif; color: #000000; background: white none repeat scroll 0% 0%;"><br /></span></span></p>
<p style="margin-top: 0px; margin-bottom: 0px; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #666666; font-family: Calibri, Arial, Helvetica, sans-serif;"><span style="font-size: 12px; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="color: #1b4260;"><span style="background-color: #ffffff; color: #000000;">Whatsapp: +51 959305262</span></span><span style="background-color: #ffffff; color: #000000;"> -&nbsp; Bedgard - Guia - Due&ntilde;o<br /></span></span></p>
<p style="margin-top: 0px; margin-bottom: 0px; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #666666; font-family: Calibri, Arial, Helvetica, sans-serif;"><span style="font-size: 12px; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="background-color: #ffffff; color: #000000;">Whatsapp: +1(514) 6631229&nbsp; -&nbsp; Alex - Due&ntilde;o<br /></span></span></p>
<p><span style="font-family: Arial,Helvetica,sans-serif; font-size: 10pt;">&nbsp;</span></p>
';

$from3=$fname."<".$email.">";
$headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers .= "From: ". $from3 . "\n";

$from2='Free Tour Downtown Arequipa<info@freewalkingtoursperu.com>';
$headers2 = 'MIME-Version: 1.0' . "\r\n";
    $headers2 .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers2 .= "From: ". $from2 . "\n";

mail ('info@freewalkingtoursperu.com', $subject, $message, $headers);

mail ($from, $subject2, $message2, $headers2);





    ?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2" class="resultado1">Gracias por reservar con nuestro afiliado Free Tour Downtown Arequipa, Le acabamos de enviar los Detalles de su CONFIRMACION, revise su BANDEJA DE ENTRADA o su BANDEJA DE CORREOS NO DESEADOS para que llegue al Punto de Encuentro Correcto y tenga el Guía calificado..
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">IMPORTANTE: Verifique su Punto de Encuentro de su Free Tour de acuerdo a la ciudad</span></td>
    </tr>
    </tbody></table>
    <?php
    
}

?>










