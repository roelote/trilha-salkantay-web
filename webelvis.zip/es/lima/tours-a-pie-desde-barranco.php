<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tour Lima desde Barranco – Tours a Pie</title>
    <meta content="Disfrute del mejor Free Walking Tour Lima desde barranco" name="description" />
    <meta content="tour gratis lima, caminatas guiadas, centro historico lima" name="keywords" />
    <meta content="es" name="language" />


    <!-- Bootstrap -->
    <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">
     <link href="/css/flag-icon.min.css" rel="stylesheet">
  <!--   estilos slider pekeño -->
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">

  </head>
  <body>
   <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>

    <div id="fb-root"></div>

    <div class="container px-0">
      <header class="cabecera">
     <?php include('../menu.php');?>
     
        <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima11am-tour-lima.jpg">
        <img src="../img/mirafores-off-es.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima11am-lima-free.jpg">
        <img src="../img/mirafores-off-es.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima11am-city-tour.jpg">
        <img src="../img/mirafores-off-es.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
      </section>
      </header>

 
    <div class="cuerpo">

      <section class="container izquierda">
             

        <section class="cuadro-texto cuadro-contenedor">

          <h1>Free Walking Tour Lima desde Barranco – Venga directamente a la Iglesia La Merced</h1>
    

          <div class="wecolmetour">
            <h2 class="text-center">¿Cómo puedo unirme a su free tour en el centro de Lima si me alojo en el distrito de Barranco?</h2>

            <p>Por favor diríjase DIRECTAMENTE a la Iglesia La Merced en Jirón de La Unión (Lima Centro), use el Bus Metropolitano, siga las siguientes instrucciones: </p>


<ol>
<li>Dir&iacute;jase a la estaci&oacute;n de <a href="https://www.google.com.pe/maps/place/V%C3%ADa+del+Metropolitano,+Distrito+de+Chorrillos+15063/@-12.1524862,-77.0215828,17.25z/data=!4m5!3m4!1s0x9105b78d321ddd21:0x19c570f99a80a15c!8m2!3d-12.1524134!4d-77.019738">Bulevard Metropolitano</a> (estaci&oacute;n de bus), est&aacute; muy cerca de la plaza de armas de Barranco, (Llegue all&iacute; lo m&aacute;s tarde a las 10am) tardar&aacute; de 5 a 10 minutos en llegar a la estaci&oacute;n a pie.</li>
<li>En esta estaci&oacute;n, compre su tarjeta de Metropolitano, el precio est&aacute; 4.50 soles y luego RECARGUELO con el mismo operador, <strong>Cu&aacute;nto deber&iacute;a recargar?</strong> El precio del pasaje a cualquier destino es 2.50 soles, el cual ser&aacute; deducido de su tarjeta una vez que pase la tarjeta en la puerta giratoria. Es decir si son dos personas tiene que recargar 5 soles &ndash; <span style="color: #ff0000;">Nota</span>, Si son 10 personas, Ud. no necesita comprar 10 tarjetas, siempre puede prestar la tarjeta, pero recargue 10 veces 2.50 soles.</li>
<li>Una vez que ya tenga la tarjeta recargada, deslice sobre la puerta giratoria y preste la misma tarjeta a los dem&aacute;s si es que va con alguien m&aacute;s.</li>
<li>Ya dentro de la estaci&oacute;n, tome la <strong>L&iacute;nea C</strong>, en direcci&oacute;n NORTE (<strong>Hacia el Norte</strong>). Pregunte a cualquier Local, le ayudaran.</li>
<li>Una vez que est&eacute; en el autob&uacute;s, le tomar&aacute; 30 minutos llegar a Estaci&oacute;n Jir&oacute;n de la Uni&oacute;n, baje en esta estaci&oacute;n, el nombre de las estaciones se muestran en la pantalla de los autobuses y tambi&eacute;n se anuncian verbalmente.</li>
<li>Finalmente, desde la estaci&oacute;n de autobuses Jir&oacute;n de la Uni&oacute;n dir&iacute;jase a la iglesia La Merced, estaremos all&iacute; desde las 10:55am hasta las 11:05am, raz&oacute;n por la cual <a href="https://www.freewalkingtoursperu.com/es/reservar/">reserve nuestro free tour Lima de las 11am</a>.</li>
<li>Si desea ayuda adicional en ingl&eacute;s, con respecto a este asunto, marque los siguientes n&uacute;meros: +51 958745640 o +51 984745640, verifique <a href="https://www.freewalkingtoursperu.com/es/contactenos">horarios de llamadas aqu&iacute;</a>.</li>
</ol>

<div class="btn-reserva">
  
<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#booke"><button type="button" class="btn btnreserva active">¡Reserva Ya!</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>
<p><span style="color: #ff0000;">MUY IMPORTANTE:</span> Si toma un taxi en Barranco, el pasaje es 25 a 30 soles, es un precio total, tome en cuenta que dura <strong>1 hora</strong> llegar al centro de Lima en taxi, es decir si toma taxi, tome el taxi a tiempo.</p>    
        
          </div>
            <p class="text-center"><strong style="color: #e318e0;">Lugares Maravillosos que Veremos!</strong></p>
          <div class="slidertours">
              <div id="demo">
                <div class="container">
                  <div class="row">
                    <div class="span12">

                      <div id="owl-demo" class="owl-carousel">

                        <div class="item"><img src="../img/free-tour-lima-14.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Viaje como un Local en Metro-Bus</div></div>
                        <div class="item"><img src="../img/free-tour-lima-01.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Conozca Gente Local</div></div>
                        <div class="item"><img src="../img/free-tour-lima-02.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Casa de la Literatura Peruana</div></div>
                        <div class="item"><img src="../img/free-tour-lima-03.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Socialice con otros Viajeros</div></div>
                        <div class="item"><img src="../img/free-tour-lima-04.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Rio Rimac</div></div>
                        <div class="item"><img src="../img/free-tour-lima-05.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palacio Municipal</div></div>
                        <div class="item"><img src="../img/free-tour-lima-06.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Iglesia de San Francisco</div></div>
                        <div class="item"><img src="../img/free-tour-lima-07.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Conozca otros viajeros</div></div>
                        <div class="item"><img src="../img/free-tour-lima-08.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palacio del Marques Torre Tagle</div></div>
                        <div class="item"><img src="../img/free-tour-lima-09.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Cambio de Guardia</div></div>
                        <div class="item"><img src="../img/free-tour-lima-10.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Plaza de Armas</div></div>
                        <div class="item"><img src="../img/free-tour-lima-11.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palacio Presidencial</div></div>
                        <div class="item"><img src="../img/free-tour-lima-12.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Iglesia de Santo Domingo</div></div>
                        <div class="item"><img src="../img/free-tour-lima-13.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Conozca Otros Viajeros</div></div>
                        

                    </div>
                      
                    </div>
                  </div>
                </div>
           </div>

          </div>



         </section>

      </section>

      <aside class="derecha">
      <?php include('../cuadro-reservas-lima.php');?>

       <!--  <div class="mapadetalle">
        <h2> <span id="mytext" class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span> Click the Map to See</h2>
        <div class="centrarmapa mb-5"><img  id="myImg" src="../img/lima-miraflores-10am.jpg" alt="Free Walking Tour Lima 10:30 am"  height="200"></div>


        <div id="myModal" class="modal">
          <span class="close">×</span>
          <img class="modal-content" id="img01" alt="mapa ubicacion">
          <div id="caption"></div>
        </div>
        </div> -->
      </aside>

    <!--  <div class="maps-c mb-5">
       <div id="map" style="width:100%;height:500px;"></div>
       <div class="contenedormap"></div>
     </div> -->
<div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Inicio</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/es/lima/" itemprop="url" title="Lima" class="linkgeneral">
                                      <span itemprop="title">Lima</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Tour a pie - Free Walking Tour Barranco</strong>
                                  </div>
                  </div>
    <div class="banners mt-5">
         <img src="../img/imgfooter.jpg" alt="publicidad logos">
      </div>
    <?php include('../footer.php');?>

    </div>
    </div>


<script src="https://code.jquery.com/jquery-2.2.3.min.js"></script> 


    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/easy-responsive-tabs.js"></script>
     <script src="../js/mapa-lima1.js"></script>
      <script src="../js/script-efectos.js"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"
        integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU="
        crossorigin="anonymous"></script>
<script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>

          <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>
   <script>
 $.datepicker.regional['es'] = {
 closeText: 'Cerrar',
 prevText: '< Ant',
 nextText: 'Sig >',
 currentText: 'Hoy',
 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
 monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
 dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
 dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
 weekHeader: 'Sm',
 dateFormat: 'dd/mm/yy',
 firstDay: 1,
 isRTL: false,
 showMonthAfterYear: false,
 yearSuffix: ''
 };
 $.datepicker.setDefaults($.datepicker.regional['es']);
$(function () {
$("#fecha").datepicker();
});
</script>
   <script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submitlima.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>
     
<style>
    #owl-demo .item{
        margin: 3px;
    }
    #owl-demo .item img{
        display: block;
        width: 100%;
        height: auto;
    }
    </style>


  </body>


</html>