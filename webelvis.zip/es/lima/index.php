<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>FREE Tour Lima Español | City Tour Lima | Centro Historico</title>
    <meta content="Somos la mejor opción para su Free Tour Lima Español | City Tour Lima, Recogemos en Miraflores y Centro Historico | Los Tours en Lima y sus alrededores o tours cerca de lima son caminando y tienes precios Libres | Tour en lima a pie." name="description" />
    <meta content="Free Tour Lima Español, city tour Lima centro, tours en lima y sus alrededores, tours cerca de lima, tour en lima, free tour centro de lima, city tour lima Miraflores, city tour centro historico de lima, city tours, free walking tour lima, lima by walking, tour caminando, tours a pie" name="keywords" />
    <meta content="es" name="language" />
   <meta name="author" content="Free Walking Tours" />
    <!-- Bootstrap -->
    <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/styles.css" rel="stylesheet">
    <link href="/css/responsiveslides.css" rel="stylesheet">
    <link href="/css/stylefwt.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />
    <link href="/css/flag-icon.min.css" rel="stylesheet">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
    
  </head>
  <body>

  <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>

<!-- <div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center">NOTA:</h4>
            </div>
            <div class="modal-body">
        <p class="text-center">Nota 28 de  Julio<br>
Lima: Busquenos en Calle Tarata a las 10am | Solamente por esta ocasion haremos el free tour de Miraflores, NO iremos al centro de Lima, El free tour solamente sera en INGLES.<br> 
Cusco & Arequipa: Seguimos operando en los horarios regulares.</p>
                
            </div>
        </div>
    </div>
</div> -->

    <div class="container px-0">
      <header class="cabecera">
          <?php include('../menu.php');?>
          
                <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/free-tour-city-lima.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/free-tour-lima.jpg">
        <img src="../img/free-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/free-tour-lima-centro.jpg">
        <img src="../img/tours-peru-free.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>



           
      </header>

    <div class="cuerpo">

      <section class="container izquierda">
                   
            <div class="text-general col-lg-12 col-lg-12 col-xs-12">
              <h1>Free Tour Lima Español | City Tour Lima | Centro Historico </h1>
             <p>Sea parte de nuestro majestuoso tour en Lima | Free Walking City tours Lima caminado, los cuales tienen una duración de 2.5 a 3.5 horas, actualmente tenemos tres horarios 10am & 11am& 3pm, un mismo itinerario, dos puntos de encuentro, escoja donde encontrarnos de acuerdo a la ubicación de su hostel (Dónde se hospeda? En Miraflores? En Barranco? En Centro de Lima? O a qué hora puede venir? por la mañana o por la tarde?).</p>
             <p>Sea parte de nuestro majestuoso tour en Lima | Free Walking City tours Lima caminado, los cuales tienen una duración de 2.5 a 3.5 horas, actualmente tenemos tres horarios 10am & 11am& 3pm, un mismo itinerario, dos puntos de encuentro, escoja donde encontrarnos de acuerdo a la ubicación de su hostel (Dónde se hospeda? En Miraflores? En Barranco? En Centro de Lima? O a qué hora puede venir? por la mañana o por la tarde?).</p>

<h2>Horarios y Punto de Encuentro:</h2>
<p>De Lunes a Sabado &ndash; <span class="text-danger">No free tours los Domingos.</span></p>
<ol>
<li style="font-weight: 400;"><span style="font-weight: 400;">Si Ud. Se encuentra en el Distrito de Miraflores, b&uacute;squenos a las </span><strong>10AM</strong><span style="font-weight: 400;"> en </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642"><span style="font-weight: 400;">Calle Schell</span></a><span style="font-weight: 400;"> a la altura del Mall Oechsle , a solamente de 2 min a pie desde el Parque Kennedy - </span><span style="font-weight: 400; color: #ff6600;"><span style="color: #800080; font-family: sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">Traiga 2.50 soles (0.70 centavos de D&oacute;lares Americanos), este dinero es para su pasaje en el Bus del Metropolitano.</span></span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Si Ud. ya se encuentra en el Centro de Lima, b&uacute;squenos a las </span><strong>11AM</strong><span style="font-weight: 400;"> frente a la </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">Iglesia La Merced</span></a><span style="font-weight: 400;"> en Jir&oacute;n de la Uni&oacute;n.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Si desea tomar nuestro free walking tour Lima por la TARDE, tambi&eacute;n b&uacute;squenos a las </span><strong>3PM</strong><span style="font-weight: 400;"> frente a la </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">Iglesia La Merced</span></a><span style="font-weight: 400;"> en Jir&oacute;n de la Uni&oacute;n(Este es nuestro &uacute;nico punto de encuentro para el free tour por la tarde, entonces donde sea que se encuentre en Lima, tiene que VENIR DIRECTAMENTE a la Iglesia La Merced).</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Qu&eacute; pasa si me encuentro en Barranco? Si este es su caso, s&iacute;ganos </span><a href="https://www.freewalkingtoursperu.com/es/lima/tours-a-pie-desde-barranco"><span style="font-weight: 400;">Free Walking Tour Lima desde Barranco.</span></a></li>
</ol>
<h2>C&oacute;mo identificar a nuestro Gu&iacute;a Oficial:</h2>
<ul>
<li>B&uacute;squenos en el Punto de Encuentro Correcto.</li>
<li>Busque por el logo de Inkan Milky Way.</li>
</ul>
<h2>Qu&eacute; Incluye nuestro free city tour Lima?</h2>
<p style="text-align: justify; line-height: 18.0pt; background: white;"><span style="font-size: 10.5pt; font-family: 'Segoe UI',sans-serif; color: #343434;">Todos nuestros Free City Tours Lima incluyen visita del centro hist&oacute;rico de Lima apie(Calles coloniales, Iglesias, Puentes, Museos ) bastante cultura y historia &ndash; </span><span style="font-size: 10.5pt; font-family: 'Segoe UI',sans-serif; color: red;">No visitamos Bares, No Bebidas. </span></p>
<h2>Duraci&oacute;n:</h2>
<p>Si empieza su free tour desde el centro de Lima dura 2.5 horas; Sin Embargo si empieza desde Miraflores (Recojo) dura 3.5 horas porque tomaremos el Bus hasta llegar al centro de Lima.</p>
<h2>Precio:</h2>
<p>FREE Tours Libres &ndash; en base a Donaciones al final del free tour</p>
<h2>Idioma:</h2>
<p>Grupos en Ingl&eacute;s y Espa&ntilde;ol, Ud. escoge su idioma.</p>

<div class="btn-reserva">
  
<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#titlea-side"><button type="button" class="btn btnreserva active">¡Reserva Ya!</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>

<p><span style="color: #ff0000;">Muy Importante</span>:&nbsp;NO se confunda con otras personas, vistiendo chalecos amarillos falsos SIN nuestro Logo &amp; Nuestros Free Tours en Lima est&aacute;n operados por Inkan Milky Way Tours Lima, una compa&ntilde;&iacute;a 100% Peruana,&nbsp;<a href="https://www.facebook.com/limafreewalkingtour/">S&iacute;ganos aqu&iacute;.</a></p>



            </div>

            <div class="row">

                                  <div class="ciudadfwt bot25">

                                                <div class="center"> 
                                                  <a href="tour-a-pie-centro-historico"><h3 class="titulociudad"><span class="tours-time limat"><span class="rojo">Free Walking City Tour Lima - 10am</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/free-walking-tour-lima-10-30-am.jpg" alt="free walking tours lima 10.30 am">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                    <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> De Lunes a Sábado.<br>
                                                    <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todos, incluyendo familias con hijos.<br>
                                                    <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 3.5 horas.<br>
                                                    <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>
                                                    <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong>  Lugar de Encuentro:</strong></span> Calle Schell, a la altura del Mall Oechsle. <br>
                                                    <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma </strong></span> English - Español <br>
                                                    <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span> El Logo Inkan Milky Way.<br>
                                                    
                                                    <div>
                                                        <div class="porciento50">
                                                       
                                                       <span><a class="click-here" href="tour-a-pie-centro-historico-lima"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>
                                                        </div>
                                                        <div class="porciento50"><a href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>

                                  </div>

                                   <div class="ciudadfwt bot25">

                                                 <div class="center"> 
                                                  <a href="tours-a-pie-plaza-de-armas-centro-historico"><h3 class="titulociudad"><span class="tours-time limat"><span class="rojo">Free Walking City Tour Lima – 11am</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/lima-dowtown-plaza-arma-tour.jpg" alt="free walking tours lima 11.30 am">
                                                  </div>

                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                      <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                      <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Caminata Cultural. <br>

                                                      <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todos, incluyendo familias con hijos.<br>

                                                      <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 2.5 horas.<br>

                                                      <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>

                                                      <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Lugar de Encuentro:</strong></span> Frente a la Iglesia Virgen de la Merced, en Jirón de la Unión.<br>
                                                      <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma </strong></span> English - Español <br>

                                                      <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span> El Logo Inkan Milky Way.<br>

                                                      
                                                      <div>
                                                         <div class="porciento50">
                                                            <span><a class="click-here" href="tours-a-pie-plaza-de-armas-centro-historico"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>

                                                        </div>
                                                        <div class="porciento50"><a  href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                  </div>


                                   <div class="ciudadfwt">

                                                 <div class="center"> 
                                                  <a href="tour-a-pie-centro-historico-por-la-tarde"><h3 class="titulociudad"><span class="tours-time limat"><span class="rojo">Free Walking City Tour Lima – 3pm</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/lima-dowtown-plaza-arma-tour.jpg" alt="free walking tours lima 11.30 am">
                                                  </div>

                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                      <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                      <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Caminata Cultural. <br>

                                                      <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todos, incluyendo familias con hijos.<br>

                                                      <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 2.5 horas.<br>

                                                      <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>

                                                      <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Lugar de Encuentro:</strong></span> Frente a la Iglesia Virgen de la Merced, en Jirón de la Unión.<br>
                                                      <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma </strong></span> English - Español <br>

                                                      <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span> El Logo Inkan Milky Way.<br>

                                                      
                                                      <div>
                                                         <div class="porciento50">
                                                            <span><a class="click-here" href="tour-a-pie-centro-historico-por-la-tarde"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>

                                                        </div>
                                                        <div class="porciento50"><a  href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                  </div>


                </div>
            <!-- /.row -->

          <div class="lima2">

             <!-- <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <img class="img-responsive" src="http://www.inkanmilkyway.com/wp-content/uploads/2018/02/inkan-milky-way-map-lima-10am-es.jpg" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                 <img  class="img-responsive"src="../img/lima-walks-11am.png" alt="">
                </div>

             </div> -->

             <div class="pb-3">

                      <div class="col-lg-12">
                          
                              <div class="col-lg-6 col-md-6 col-xs-12">
                              
                                  <img class="img-responsive" src="../img/lima-miraflores-10am.jpg" alt="Another alt text">
                             
                          </div>

                              <div class="col-lg-6 col-md-6 col-xs-12">
                          
                                  <img class="img-responsive" src="../img/free-tour-lima-map-11am-3pm.png" alt="Another alt text">
                           
                          </div>
                  </div>


                 
                </div>


          </div>
  
      </section>

   

      <aside class="derecha" id="titlea-side">
       <?php include('../cuadro-reservas-lima.php');?>
        <div class="facebookpubli">
          <!-- <div class="fb-page" data-href="https://www.facebook.com/FTFWALKINGTOURSLIMA/" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/FTFWALKINGTOURSLIMA/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/FTFWALKINGTOURSLIMA/">Free Walking Tour Lima</a></blockquote></div> -->
        </div>
      </aside>

     

       <div class="maps-c mb-5">
<div class="row">
    <div class="col-xs-12 col-sm-6">
      <div class="border-map mb-2">
        <h3 class="text-center mt-2">Free Tour Lima 10am - Recojo en Calle Schell, a la altura del Mall Oechsle Miraflores</h3>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3900.83395271387!2d-77.03090888518663!3d-12.123511191416247!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x3e2cd448586ebf0b!2sInkan+Milky+Way+Lima%2C+Free+Walking+Tour!5e0!3m2!1ses!2spe!4v1523139123996" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>
    </div>
  <div class="col-xs-12 col-sm-6">
    <div class="border-map">
      <h3 class="text-center mt-2">Free Tour Lima 11am & 3pm - Frente a la Iglesia La Merced</h3>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.9325044777484!2d-77.0350338851874!3d-12.048164991466383!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x260b4404fb6284e!2sInkan+Milky+Way+Lima!5e0!3m2!1ses!2spe!4v1523139111848" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>
  </div>
</div>
     </div>
 <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Inicio</span>
                                    </a> »  
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Lima</strong>
                                  </div>
                   </div>
         <section class="mt-5 pt-5 mb-5">

         <div id="wrap">
            <div class="card mb-5">
              <div class="thumb" id="one" style="background-image: url(../img/free-walking-tour-cusco-10-am.jpg);}"></div>
              <div class="option">
                <i class="material-icons"></i>
                <i class="material-icons"></i>
                <i class="material-icons"></i>
              </div>
              <h3 class="text-center">Free Tour Cusco</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Going to Cusco? Join our free tour Partner, offering the best tip based walks, full on history & culture</p>
              <div class="add"><a target="_blank" href="/es/cusco/">More Info</a></div>
              <div class="buy"> <a target="_blank" href="/es/reservar/">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="two" style="background-image: url(../img/free-walking-tour-arequipa-3-pm.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Free Tour Arequipa</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Are you planning to visist Arequipa? Be part of the finest free walking tours operated by our Partner</p>
              <div class="add"> <a target="_blank" href="/es/arequipa/">More Info</a></div>
              <div class="buy"> <a target="_blank" href="/es/reservar/">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="three" style="background-image: url(../img/cusco-private-tour.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Private Walks Cusco</h3>
              
              <p class="price">$35.00</p>
              
              <p class="desc mt-1 mb-3">Want a private walk? Then join our premier private walking tours, operated by a Local Indigenous Co</p>
              <div class="add"> <a target="_blank" href="#">More Info</a></div>
              <div class="buy"><a target="_blank" href="#">Book Know</a></div>
            </div>
          </div>

  
     </section>
     

    <div class="banners mt-5">
       <img src="../img/imgfooter.jpg" alt="">
    </div>
    <?php include('../footer.php');?>


    </div>

   
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="/js/responsiveslides.min.js"></script>

   
<!--     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $("#myModal").modal('show');
  });
</script> -->

   <!-- script reservas -->
<script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>
<script language="javascript">
$(document).ready(function() {
    $().ajaxStart(function() {
        $('#loading').show();
        $('#result').hide();
    }).ajaxStop(function() {
        $('#loading').hide();
        $('#result').fadeIn('slow');
    });
    $('#form, #fat, #fo3').submit(function() {
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function(data) {
                $('#result').html(data);

            }
        })
        
        return false;
    }); 
})  
</script>

   


  </body>


</html>



