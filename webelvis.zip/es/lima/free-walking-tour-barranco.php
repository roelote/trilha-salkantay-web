<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tour Lima en Español – Tours a Pie Lima</title>
    <meta content="Somos la mejor compañia pionera en Free Walking Tour Lima en Español - Tours a Pie Lima, ubiquenos en Miraflores y el Centro Historico de Lima." name="description" />
    <meta content="tour a pie lima, camintas, tours lima" name="keywords" />
    <meta content="es" name="language" />
   <meta name="author" content="Free Walking Tours" />
    <!-- Bootstrap -->
    <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />

  </head>
  <body>

  <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>

    <div class="container px-0">
      <header class="cabecera">
          <?php include('../menu.php');?>
        <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                      <ul class="rslides" id="slider2">
                        <li><img src="../img/home-free-walking-tour-lima.jpg" alt="free walking tours lima"> </li>
                         <!--  <li><img src="../img/slider-lima-walking-tour.jpg" alt="free walking tour lima"> </li> -->
                      </ul>
                </div>
            </div>     



           
      </header>

    <div class="cuerpo">

      <section class="container izquierda">
                    <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Inicio</span>
                                    </a> »  
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Lima</strong>
                                  </div>
                  </div>
            <div class="col-lg-12 col-lg-12 col-xs-12">
              <h1>Free Walking Tour Lima – Tours a Pie Lima</h1>
             <p>En Free Walking Tour Peru operado por by Inkan Milky Way, contamos con la mejor plataforma de Free Walking Tour en Lima, lleno de historia relevante, actualmente tenemos dos horarios: 10am & 11am con el mismo itinerario pero los Puntos de Partida son diferentes, escoja una de ellas de acuerdo a la ubicación de su Hotel o Hostel o donde se encuentra Ud. (Si está Ubicado en el distrito de Miraflores o el centro historico de Lima). </p>

             <h2>Horarios y Punto de Encuentro:  </h2>
             <p>De Lunes a Sabado – <span class="text-danger">No operamos free tours los Domingos.</span></p>
               <ul>
                <li>Si Ud. Se encuentra en el Distrito de Miraflores, búsquenos en la Calle Schell 378, al costado de Money Gram (frente al Hotel MARRIOTT) a las 10AM – <span class="text-primary">Traiga 2.50 soles (0.70 centavos de Dólares Americanos), este dinero es para su pasaje en el Bus del Metropolitano.</span></li>
                <li>Si Ud. ya se encuentra en el Centro de Lima, búsquenos en el Atrio de la Iglesia La Merced en Jirón de la Unión a las 11am.</li>
                <li>Qué pasa si me encuentro en Barranco? Si este es su caso, síganos Free Walking Tour Lima desde Barranco.</li>


             </ul>

            <h2> How to identify your Correct Tour Guide:</h2>
            <ul>
              <li>Look for us at the Correct Meeting Point.</li>
              <li>We wear the Inkan Milky Way Logo-Sign</li>
            </ul>

          <h2>Inclusions & Duration:</h2>
              <p>All our Free Tours Lima include culture, history, culinary explanation, professional tour guides, travel tips and travel emotions, they take 2.5h(from Lima downtown) to 3.5h(from Miraflores), take a glance to our Lima Walking Tour Map below.</p>


               <p><b>Inkan Milky Way Tours</b> - Lima is in charge of all Tours and Free Tours in Lima, any question, comment, testimony, feedback write at <a href="https://www.facebook.com/inkanmilkywaylimafreewalkingtour">Inkan Milky Way Tours – Lima.</a></p>


              <p class="text-danger">  </p>

              <p class="text-danger"> </p> 


            </div>

            <div class="row">

                                  <div class="ciudadfwt">

                                                <div class="center"> 
                                                  <a href="tour-a-pie-centro-historico"><h3 class="titulociudad"><span class="tours-time limat"><span class="rojo">Tour a pie – Centro Historico de Lima - 10:30am</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/free-walking-tour-lima-10-30-am.jpg" alt="free walking tours lima 10.30 am">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                    <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Todo los Días<br>
                                                    <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todos, incluyendo familias con hijos.<br>
                                                    <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 3 a 3.5 horas.<br>
                                                    <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>
                                                    <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong>  Lugar de Encuentro:</strong></span> Parque Kennedy, frente a la iglesia Virgen Milagrosa<br>
                                                    <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma </strong></span> English - Español <br>
                                                    <span><i class="fa fa-eye" aria-hidden="true"></i><strong>Busque únicamente por:</strong></span> El Logo FTF en los chalecos amarillos.<br>
                                                    
                                                    <div>
                                                        <div class="porciento50">
                                                       
                                                       <span><a class="click-here" href="tour-a-pie-centro-historico-lima"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>
                                                        </div>
                                                        <div class="porciento50"><a href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>

                                  </div>

                                   <div class="ciudadfwt">

                                                 <div class="center"> 
                                                  <a href="tours-a-pie-plaza-de-armas-centro-historico"><h3 class="titulociudad"><span class="tours-time limat"><span class="rojo">Tour a pie – Centro Historico de Lima – 11:30am</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/free-walking-tour-lima-11-30-am.jpg" alt="free walking tours lima 11.30 am">
                                                  </div>

                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                      <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                      <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Todo los Días<br>

                                                      <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todos, incluyendo familias con hijos.<br>

                                                      <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 3 a 3.5 horas.<br>

                                                      <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>

                                                      <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Lugar de Encuentro:</strong></span> Plaza de Armas (por la Fuente de agua).<br>
                                                      <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma </strong></span> English - Español <br>

                                                      <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span> El Logo FTF en los chalecos amarillos.<br>

                                                      
                                                      <div>
                                                         <div class="porciento50">
                                                            <span><a class="click-here" href="tour-a-pie-centro-historico-lima"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>

                                                        </div>
                                                        <div class="porciento50"><a  href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                  </div>


                </div>
            <!-- /.row -->

             <div class="lima2">

             <!-- <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <img class="img-responsive" src="../img/lima-walks-10-30am.png" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                 <img  class="img-responsive"src="../img/lima-walks-11am.png" alt="">
                </div>

             </div> -->

             <div class="row">

                      <div class="col-lg-12">
                          
                              <div class="col-lg-6 col-md-6 col-xs-12">
                              <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="Tour a Pie Lima 10 am" data-caption="free walking tour lima 10 am" data-image="../img/lima-walks-10-30am.png" data-target="#image-gallery">
                                  <img class="img-responsive" src="../img/lima-walks-10-30am.png" alt="Another alt text">
                              </a>
                          </div>

                              <div class="col-lg-6 col-md-6 col-xs-12">
                              <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="Tour a Pie Lima 11.30 am" data-caption="free walking tour lima 11 am" data-image="../img/lima-walks-11am.jpg" data-target="#image-gallery">
                                  <img class="img-responsive" src="../img/lima-walks-11am.png" alt="Another alt text">
                              </a>
                          </div>
                  </div>


                  <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <div class="modal-dialogo">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span><span class="sr-only">Close</span></button>
                                  <h4 class="modal-title" id="image-gallery-title"></h4>
                              </div>
                              <div class="modal-body">
                                  <img id="image-gallery-image" class="img-responsive" src="">
                              </div>
                              
                          </div>
                      </div>
                  </div>
                </div>


          </div>
  
      </section>

   

      <aside class="derecha">
      
        <div class="facebookpubli">
          <div class="fb-page" data-href="https://www.facebook.com/FTFWALKINGTOURSLIMA/" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/FTFWALKINGTOURSLIMA/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/FTFWALKINGTOURSLIMA/">Free Walking Tour Lima</a></blockquote></div>

          
   
          
        </div>

      
       
      </aside>

     

       <div class="maps-c mb-5">
       <div id="map" style="width:100%;height:500px;"></div>
       <div class="contenedormap"></div>
     </div>

         <section class="mt-5 pt-5 mb-5">

         <div id="wrap">
            <div class="card mb-5">
              <div class="thumb" id="one" style="background-image: url(../img/free-walking-tour-cusco-10-am.jpg);}"></div>
              <div class="option">
                <i class="material-icons"></i>
                <i class="material-icons"></i>
                <i class="material-icons"></i>
              </div>
              <h3 class="text-center">Free Tour Cusco</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Going to Cusco? Join our free tour Partner, offering the best tip based walks, full on history & culture</p>
              <div class="add"><a target="_blank" href="/es/cusco/">More Info</a></div>
              <div class="buy"> <a target="_blank" href="/es/reservar/">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="two" style="background-image: url(../img/free-walking-tour-arequipa-3-pm.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Free Tour Arequipa</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Are you planning to visist Arequipa? Be part of the finest free walking tours operated by our Partner</p>
              <div class="add"> <a target="_blank" href="/es/arequipa/">More Info</a></div>
              <div class="buy"> <a target="_blank" href="/es/reservar/">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="three" style="background-image: url(../img/cusco-private-tour.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Private Walks Cusco</h3>
              
              <p class="price">$35.00</p>
              
              <p class="desc mt-1 mb-3">Want a private walk? Then join our premier private walking tours, operated by a Local Indigenous Co</p>
              <div class="add"> <a target="_blank" href="#">More Info</a></div>
              <div class="buy"><a target="_blank" href="#">Book Know</a></div>
            </div>
          </div>

  
     </section>
     

    <div class="banners mt-5">
       <img src="../img/imgfooter.jpg" alt="">
    </div>
    <?php include('../footer.php');?>


    </div>

   
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
    <script src="../js/mapa-lima.js"></script>

   
   <!-- script reservas -->

<script language="javascript">
$(document).ready(function() {
    $().ajaxStart(function() {
        $('#loading').show();
        $('#result').hide();
    }).ajaxStop(function() {
        $('#loading').hide();
        $('#result').fadeIn('slow');
    });
    $('#form, #fat, #fo3').submit(function() {
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function(data) {
                $('#result').html(data);

            }
        })
        
        return false;
    }); 
})  
</script>


    


    <script>
    // You can also use "$(window).load(function() {"
    $(function () {
      // Slideshow 1
        $("#slider2").responsiveSlides({
          maxwidth: none,
          speed: 500
        });
    });
</script>
<script>
  
 $(document).ready(function(){

    loadGallery(true, 'a.thumbnail');

    //This function disables buttons when needed
    function disableButtons(counter_max, counter_current){
        $('#show-previous-image, #show-next-image').show();
        if(counter_max == counter_current){
            $('#show-next-image').hide();
        } else if (counter_current == 1){
            $('#show-previous-image').hide();
        }
    }

    /**
     *
     * @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
     * @param setClickAttr  Sets the attribute for the click handler.
     */

    function loadGallery(setIDs, setClickAttr){
        var current_image,
            selector,
            counter = 0;

        $('#show-next-image, #show-previous-image').click(function(){
            if($(this).attr('id') == 'show-previous-image'){
                current_image--;
            } else {
                current_image++;
            }

            selector = $('[data-image-id="' + current_image + '"]');
            updateGallery(selector);
        });

        function updateGallery(selector) {
            var $sel = selector;
            current_image = $sel.data('image-id');
            $('#image-gallery-caption').text($sel.data('caption'));
            $('#image-gallery-title').text($sel.data('title'));
            $('#image-gallery-image').attr('src', $sel.data('image'));
            disableButtons(counter, $sel.data('image-id'));
        }

        if(setIDs == true){
            $('[data-image-id]').each(function(){
                counter++;
                $(this).attr('data-image-id',counter);
            });
        }
        $(setClickAttr).on('click',function(){
            updateGallery($(this));
        });
    }
});
</script>

  </body>


</html>



