<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tour Lima ESPAÑOL | Centro Historico & City Tours en Lima y sus alrededores desde Miraflores</title>
    <meta content="Descubra la magia de Lima en Free Walking Tour Lima Español, este City Tour Lima empieza desde Miraflores | Nuestros free tours en Lima y sus alrededores, le mostraran una fascinante historia llena de contenido relevante, los esperamos en nuestro Tour Lima en el centro histórico." name="description" />
    <meta content="Free Walking Tour Lima, city tour lima miraflores, tours en lima y sus alrededores, tour Lima en centro historico, free tour, free walking tour, tours gratis lima, tour caminando Lima" name="keywords" />
    <meta content="es" name="language" />


    <!-- Bootstrap -->
    <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">

     
  <!--   estilos slider pekeño -->
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />

        <link href="/css/flag-icon.min.css" rel="stylesheet">

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
    

  </head>
  <body>
   <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>



    <div id="fb-root"></div>

    <div class="container px-0">
      <header class="cabecera">
       <?php include('../menu.php');?>
        <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima10am-free-city-tour.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima1">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima10am-city-tour.jpg">
        <img src="../img/free-tour-peru.jpg" class="w-100" alt="free walking tour lima2">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima10am-free-tour.jpg">
        <img src="../img/tours-peru-free.jpg" class="w-100" alt="free walking tour lima3">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>
           
      </header>

 
    <div class="cuerpo">

      <section class="container izquierda">
            

        <section class="cuadro-texto cuadro-contenedor">

          <h1>Free Walking Tour Lima 10am | City Tour Lima Centro Historico | Recojo en Miraflores </h1>
         

          <div class="wecolmetour">

<p>Lea lo siguiente solamente si esta hospedado en Miraflores o lugares cercanos a este distrito y sea parte de una experiencia inolvidable siendo parte del mejor Free Walking Tour Lima | City Tour en el Centro Hist&oacute;rico, le mostraremos la manera m&aacute;s <strong>Econ&oacute;mica &amp; R&aacute;pida</strong> para ir al Centro Hist&oacute;rico de Lima, tomaremos el Sistema de <strong>Bus</strong>, llamado <strong>Metropolitano</strong> como la gente local lo hace, una vez que lleguemos al centro de Lima, lo maravilloso de esta ciudad, los atractivos m&aacute;s importantes como la Iglesia de Santo Domingo, Rio Rimac, Estaci&oacute;n de Tren o el Palacio de Los Virreyes y mucho m&aacute;s | Nuestro free walking tour en Lima definitivamente es la mejor alternativa para conocer Lima en su primer d&iacute;a, descubra Lima </p>

<p>Nuestro <strong>FREE Walking Tour Lima </strong>a las<strong> 10am</strong> est&aacute; dirigido para Turistas que se encuentren hospedados en el distrito de Miraflores (Le recogeremos); Sin embargo si Ud. esta hospedado en el <a href="https://www.freewalkingtoursperu.com/es/lima/tours-a-pie-plaza-de-armas-centro-historico">centro de Lima s&iacute;ganos aqu&iacute;</a>, Si esta hospedado en <a href="https://www.freewalkingtoursperu.com/es/lima/tours-a-pie-desde-barranco">Barranco s&iacute;ganos aqu&iacute;</a>.</p>

          <h2 class="text-center">ANTES DE ASISTIR A NUESTRO FREE TOUR DEBERIA DE SABER:</h2>

<p><strong>Horario:&nbsp;</strong>10am de Lunes a S&aacute;bado &ndash;&nbsp;<span style="color: #ff0000;">No domingos.</span></p>
<p><strong>Lugar de Encuentro</strong>:&nbsp;<a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Calle Schell</a> a la altura del Mall Oechsle (Distrito de Miraflores) -&nbsp;No llegue tarde&iexcl;</p>
<p><strong>C&oacute;mo ubicarnos en Miraflores?</strong>&nbsp;Estamos a solamente 2 a 5 min a pie desde el Parque Kenndey. Use como lugar de referencia&nbsp;<a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Calle Schell</a>, todos conocen esta calle famosa.</p>
<p><strong>Duraci&oacute;n</strong>: Empezando desde Miraflores, este free tour dura 3.5 horas aprox.</p>
<p><strong>C&oacute;mo reconocer al Gu&iacute;a de nuestra compa&ntilde;&iacute;a?</strong>&nbsp;Busque por el Logo Inkan Milky Way en el Punto de Encuentro Correcto.</p>
<p><strong>Qu&eacute; Traer?</strong>&nbsp;2.50 soles para su transporte en el Bus del Metropolitano, gorras, lentes de Sol, bloqueador, agua y una Sonrisa.</p>
<p><strong>Precio: </strong>FREE Tours Libres &ndash; en base a Donaciones al final del free tour.</p>
<p><strong>Idioma: </strong>Grupos en Ingl&eacute;s y Espa&ntilde;ol, Ud. escoge su idioma.</p>


<div class="btn-reserva">
  
<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#titlea-side"><button type="button" class="btn btnreserva active">¡Reserva Ya!</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>
<p><span style="color: #ff0000;">Muy Importante:</span>&nbsp;NO se confunda con otras personas, vistiendo chalecos amarillos falsos SIN nuestro Logo &amp; Nuestros Free Tours en Lima est&aacute;n operados por Inkan Milky Way Tours Lima, una compa&ntilde;&iacute;a 100% Peruana,&nbsp;<a href="https://www.facebook.com/limafreewalkingtour/">S&iacute;ganos aqu&iacute;.</a></p>

<h2 class="text-center">Qué es un free walking tour en el centro histórico de Lima – City Tour Lima a Pie?</h2>
<p>Consiste en realizar un <strong>tour caminando</strong> como cualquier local conociendo atractivos de inter&eacute;s hist&oacute;rico y al final turista puede dejar una donaci&oacute;n para el gu&iacute;a | Es un Free Tour un Tour Gratis? NO. El concepto de Free Tour fue creado por <a href="https://www.youtube.com/watch?v=7RMzHA9FGU8">Christopher Sandman</a> graduado en la Universidad de Yale en los EEUU, el cual consiste el tomar un free tour libremente y al final del tour dejar una gratificaci&oacute;n en directa proporci&oacute;n a la calidad del free city tour Lima | Tambi&eacute;n mencionamos que no necesita traducir un Free Tour como: <strong>Tours Gratis Lima</strong>, recuerde que es un concepto Ingles, en esta compa&ntilde;&iacute;a somos Honestos.</p>

          </div>
  <p class="text-center"><strong style="color: #e318e0;">Lugares Maravillosos que Veremos!</strong></p>
          <div class="slidertours">
              <div id="demo">
                <div class="container">
                  <div class="row">
                    <div class="span12">

                      <div id="owl-demo" class="owl-carousel">

                        <div class="item"><img src="../img/free-tour-lima-14.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Viaje como un Local en Metro-Bus</div></div>
                        <div class="item"><img src="../img/free-tour-lima-01.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Conozca Gente Local</div></div>
                        <div class="item"><img src="../img/free-tour-lima-02.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Casa de la Literatura Peruana</div></div>
                        <div class="item"><img src="../img/free-tour-lima-03.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Socialice con otros Viajeros</div></div>
                        <div class="item"><img src="../img/free-tour-lima-04.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Rio Rimac</div></div>
                        <div class="item"><img src="../img/free-tour-lima-05.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palacio Municipal</div></div>
                        <div class="item"><img src="../img/free-tour-lima-06.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Iglesia de San Francisco</div></div>
                        <div class="item"><img src="../img/free-tour-lima-07.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Conozca otros viajeros</div></div>
                        <div class="item"><img src="../img/free-tour-lima-08.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palacio del Marques Torre Tagle</div></div>
                        <div class="item"><img src="../img/free-tour-lima-09.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Cambio de Guardia</div></div>
                        <div class="item"><img src="../img/free-tour-lima-10.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Plaza de Armas</div></div>
                        <div class="item"><img src="../img/free-tour-lima-11.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Palacio Presidencial</div></div>
                        <div class="item"><img src="../img/free-tour-lima-12.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Iglesia de Santo Domingo</div></div>
                        <div class="item"><img src="../img/free-tour-lima-13.jpg" alt="free walking tour lima miraflores"><div class="tit-carrusel">Conozca Otros Viajeros</div></div>
                        

                    </div>
                      
                    </div>
                  </div>
                </div>
           </div>

          </div>
          <div id="verticalTab">
                <ul class="resp-tabs-list">
                    <li> <span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span>ITINERARIO</li>
                    <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span>INCLUYE</li>
                    <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span>FAQS - AVISO IMPORTANTE</li>
                </ul>
                <div class="resp-tabs-container">
                    <div>
                    <h2 class="h2-tours-detalle">Lugares a Visitar:</h2> 

                   <p class="texto-ciudades">Este itinerario es flexible dependiendo de muchas razones: festividades, huelgas, etc. Si usted es un Blogger, critico en Tripavisor, agente de Lonely Planet, por favor revise nuestras políticas, de esa manera podremos evitar malos entendidos, No obstante, haremos todo lo posible para que pueda tener una grata experiencia.</p>

                   <ul style="list-style-type: none" class="bi-ciudades">

 

 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Se encuentra hospedado en Miraflores? No sabe cómo llegar al centro de Lima mediante el sistema del Metropolitano? Entonces lo Recogeremos a las 10am, en la <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Calle Schell</a> a la altura del Mall Oechsle <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Google Maps de Inkan Milky Way, Free Walking Tour Lima</a>.</li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span><b><span class="text-danger">No llegue tarde¡</span></b> A las 10:05am en Punto nos dirigiremos a la Estación de Bus del Metropolitano, dé 2.50 soles a su guía, esto es el costo del pasaje en el Bus – <b>Tomaremos el bus para ir al centro de Lima.</b></li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Tomaremos el Bus que va hacia al Norte, nos bajaremos en Jirón de La Unión, muy cerca de la Iglesia La Merced.</li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>A las 10:50am aprox. Llegaremos a la estación del Bus, luego nos dirigiremos a la Iglesia La Merced, esperaremos por unos minutos aquí a nuestros asistentes del grupo de las 11am.  </li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>A las 11am, empezaremos su free tour o tours a pie. </li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Visitaremos La Plaza Mayor y El Palacio Presidencial de Lima (visita exteriormente).</li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Iglesia de Santo Domingo (visita interiormente) y el Rio Rimac.</li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Iglesia de San Francisco y el Congreso de la Republica, ambos serán visitados exteriormente.</li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Palacio de José Bernardo Torre Tagle (visita exteriormente).</li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Recuerde que este free tour y se trabaja en base a gratificaciones, No espere fuegos artificiales, bebidas o chocolates al final del tour.</li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Terminamos el tour al costado de la Plaza Mayor. </li>
 <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Si desea ayuda para volver a Miraflores usando el Bus del Metropolitano, le ayudaremos, tenga nuestra palabra.</li>

                   </ul>
                    </div>

                    <div>
                       <div class="imagesit">
                        <img src="../img/ico-lima-10-30am/gothic-free-walks-lima.png" alt="gothic-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/best-picture-free-walks-lima.png" alt="best-picture-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/hoverment-palace-free-walks-lima.png" alt="hoverment-palace-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/history-free-walks-lima.png" alt="history-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/catholicis-free-walks-lima.png" alt="catholicis-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/inquires-free-walks-lima.png" alt="inquires-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/geo-orientation-free-walks-lima.png" alt="geo-orientation-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/travel-tips-free-walks-lima.png" alt="travel-tips-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/acomodation-tips-free-walks-lima.png" alt="acomodation-tips-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/peruvian-curine-free-walks-lima.png" alt="peruvian-curine-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/lisenced-company-free-walks-lima.png" alt="lisenced-company-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/profesional-guides-free-walks-lima.png" alt="profesional-guides-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/pisco-sours-free-walks-lima.png" alt="pisco-sours-free-walks-lima">
                        <img src="../img/ico-lima-10-30am/chocolate-tastings-free-walks-lima.png" alt="chocolate-tastings-free-walks-cusco">

                      </div>
                    </div>
                    <div>
                    <ul style="list-style-type: none">

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Dónde es nuestro Punto de Encuentro en Lima y Miraflores? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">
-<span style="color: #ff00ff;">10am Lima free tour: </span>Si esta hospedado en el distrito de Miraflores, Le recogeremos en la <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Calle Schell</a> a la altura del Mall Oechsle  a las 10am &ndash; N&oacute;tese: Le recogeremos en este lugar para tomar el Bus y transportarnos al centro de Lima y hacer el free tour en Lima (No en Miraflores).<br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #008080;">- C&oacute;mo ubicarnos en Miraflores?</span> Estamos a solamente 2 a 5 min a pie desde el Parque Kennedy. Use como lugar de referencia Calle Schell, todos conocen esta calle, <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Use nuestro google maps</a>. <br /> 
<span>--------------------------------------------------------------------------------------------------------------------------</span>
<span style="color: #ff00ff;">-11am Lima free tour:</span> Si esta hospedado en Lima centro o ya se encuentra en Lima centro, Ub&iacute;quenos frente a la <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima/@-12.048165,-77.0350339,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452">Iglesia la Merced</a> a las 11am (in Jir&oacute;n de la Uni&oacute;n).<br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #008080;">- C&oacute;mo ubicarnos la iglesia de La Merced en Lima centro?</span> Estamos a 3min a pie, desde la Plaza Mayor <span style="color: #ff0000;">(Recuerde NO nos busque en la plaza mayor).</span> Pregunte por Jir&oacute;n de la Uni&oacute;n, camine 3 bloques hacia al sur, pregunte por la Iglesia La Merced, <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima/@-12.048165,-77.0350339,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452">use nuestro google maps.</a><br />
<span>--------------------------------------------------------------------------------------------------------------------------</span>
 <span style="color: #ff00ff;">-C&oacute;mo hago si estoy hospedado en Barranco?</span> Dir&iacute;jase a este enlace para Barranco y haga su reserva para las 11am y b&uacute;squenos en la iglesia La Merced, <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima/@-12.048165,-77.0350339,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452">use nuestro google maps.</a>
</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>  ¿Cómo reconocer a nuestros guías en el Punto de Encuentro en Lima y Miraflores? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">Busque por el Logo Inkan Milky Way, en el Lugar Correcto, recuerde en Lima hay muchas personas que usan el chaleco amarillo, incluso muchos seudo-guías en la plaza mayor, por consiguiente oriéntese buscándonos en el Lugar Correcto y el Logo: Inkan Milky Way Tours Lima.</p></li>

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>  ¿Dónde termina nuestro free tour en Lima? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">Nuestro free tour termina al costado de la plaza mayor.</p></li>

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Cuánto se sugiere como gratificación apropiada?(<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">Nuestra filosofía de Free Tour es: Pay what you think the tour was worth¡, (Paga lo que vale el tour) – Nuestros free tours son de buena calidad y creemos humildemente que un buen servicio debe de ser gratificado generosa, decente y apropiadamente, No con monedas como 2 soles o 5 soles.<br>

No trabajamos bajo el siguiente concepto: Pay what you can or what you like (Paga lo que quieras),  la razón es muy sencilla, en Sudamérica tenemos muchos turistas que no tiene la cultura de dejar una gratificación; por eso nuestra filosofía es Pay what you think the tour was worth¡, es decir un buen tour debe ser gratificado generosamente. <br>
Nuestra compañía es 100% privada, ningún guía nuestro trabaja o percibe un salario de ninguna entidad u ONG’s, toda contribución siempre es compartida entre todo el equipo, normalmente la mayoría de los turistas dejan veinte a treinta soles por persona siempre y cuando que el servicio haya sido bueno(el costo de vida en Lima es caro), porque nadie premia un mal servicio, de eso se trata un free walking tour, aportar por algo que vale la pena y le recalcamos que NO ofrecemos “Tours Gratis”, si Ud. lo traduce es un tema suyo, nosotros somos responsables por los free walking tours que es un concepto Ingles, creado por Christopher Sandman. <br>
Muchas Gracias.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Qué cosas debo llevar conmigo? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">
- Traiga consigo 2.50 soles si va a tomar nuestro free tour desde Miraflores.
- Bloqueador solar. 
- Lentes de sol. 
- Zapatos para caminar.
- Una gran sonrisa y la voluntad para caminar.
</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Idiomas disponibles para nuestros free tours en Lima? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">Inglés y Español, de acuerdo a la cantidad de turistas ya sea para un guiado solo en Inglés, solo en español o bilingüe. Haremos lo mejor, tenga nuestra palabra.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Horarios de Free Tours en Lima? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">Tenemos un solo free tour por día en Lima, de Lunes a Sábado a las 10am & 11am, pero con dos diferentes Puntos de Partida - No tenemos free tours los domingos.</p></li>

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Son diferentes nuestros free tours en Lima (10am & 11am)?(<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">Tenemos un solo free tour por día en Lima, es decir los free tours a las 10am & 11am, tienen el mismo itinerario, pero con dos diferentes Puntos de Partida.</p></li>

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Podemos retirarnos antes que termine su free tour porque tenemos otras actividades programadas?(<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">Siempre puede dejar o retirarse de nuestro free tour antes de que este termine, sin embargo considere lo siguiente:
Deje que su gratificación, no ignore a su guía, no se escape, no pretenda haberse olvidado de traer dinero para la gratificación para su free tour, no pretenda no saber que es un free tour basado en gratificaciones.<br>
Gracias.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>  ¿Cuánto tiempo dura nuestro free tour en Lima? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">
-Si inicia su free tour, en Miraflores, su free walking tour dura 3.5 horas aprox.<br>
-Si inicia su free tour frente a la Iglesia La Merced en el centro histórico de Lima, su free walking tour dura 2.5 horas aprox.</p></li>

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Turistas mínimos necesarios para realizar el free tour? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">05 turistas, caso contrario el free tour se cancelara, para más información visite: nuestras políticas.</p></li>

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Turistas máximos permitidos por grupo? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">20 turistas. En muy pocas ocasiones solemos tener grupos de más de 20, por favor no eche la culpa a su guía o al equipo, porque sencillamente muchos no hacen la reserva, razón por la cual no se puede tomar una decisión con anticipación para contar con más guías.</p></li>

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Somos un grupo de 11 o más, podemos reservar en línea? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">
Grupos o familias de 11 a más deben de contactarnos antes de reservar, y de acuerdo a la disponibilidad aceptaremos o denegaremos la participación en nuestros free tours. <br>
Sabemos por experiencia que grupos grandes No prestan atención a la explicación del guía y este hecho afecta la calidad del free tour.<br>

Si se olvidó de reservar, siempre se puede presentarse en el lugar indicado, haremos lo mejor para acomodarlo si se puede, pero No espere lo mejor de lo mejor, le recordamos que es un free tour, si desea un servicio Premium, un tour privado es aconsejable.</p></li>



<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Somos un grupo de 11 o más, podemos tener un free tour privado? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">NO, todos nuestros free tours son servicios compartidos, es decir tomara el servicio juntamente con otros turistas.
No importa si su grupo es de 20 o 30 turistas, la repuesta sigue siendo NO, sabemos por experiencia que grupos grandes No prestan atención a la explicación del guía y este hecho afecta la calidad del free tour, por esta razón le aconsejamos tomar un tour pre-pago.<br>

Si aun así su grupo desea participar de nuestro free tour, contáctenos, si es que hay cupos aceptaremos su reserva, pero su free tour NO será privado, es decir tomara el servicio juntamente con otros turistas. </p></li>

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Se puede cancelar nuestros free tours por protestas, festividades o mal tiempo en Lima? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">
- Si se trata de protestas podemos cancelar su free tour, incluso sin previo aviso porque muchas huelgas no son anunciadas.<br>
- Si se trata de festividades (como año nuevo o 28 de julio), también podemos cancelar el free tour.<br>
- En Lima NO hay mal tiempo, es decir casi nunca llueve.  <br></p></li>

<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Usamos Muletas, podemos participar en su free tour? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">Por su puesto, siempre y cuando Ud. sea capaz de caminar y mantearse parado mientras su guía explica sobre algún punto de interés histórico.</p></li>


<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Usamos Sillas de Rueda, podemos participar en su free tour? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
<p class="respuesta" style="display:none">Desafortunadamente la respuesta es NO, porque muchas calles o avenidas en el Perú no están adaptadas para personas que usen Silla de ruedas, esta situación escapa de nuestras manos, le aconsejamos tomar un tour privado y contar con un asistente.</p></li>

                    <a href="#" class="alternar-todo" id="alternar-todo">Ver todas las respuestas</a>

                    </ul>
                    </div>
                </div>
            </div>



         </section>

      </section>

      <aside class="derecha">

        <div class="redes-movil mt-3 visible-xs">
        <section class="redes-s" style="width: 100%;font-size: 12px; border-radius: 5px;">
  <div class="row text-center mt-2 mb-3">
  <span class="tex-center">
  <h4 id="titlea-side">Tome la mejor decisión en Lima, lea nuestros más de 200 testimonios en:</h4>

   <a href="https://web.facebook.com/inkanmilkywaylimafreewalkingtour/"><i class="fab fa-facebook"></i></a>
   <a href="https://www.youtube.com/channel/UCjCwOb8Uayzl2pCLsntighg"><i class="fab fa-youtube-square"></i></a>
   <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294316-d14918493-Reviews-Inkan_Milky_Way_Tours_Lima-Lima_Lima_Region.html"><img src="/img/trip-advisor.jpg" class="mt-1" alt="" width="38" height="35"></a>
   <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1"><img src="/img/google-b.png" alt="" style="" width="40" height="38"></a>
   <a href="https://plus.google.com/+FreeWalkingToursLimaDistritodeLima"><i class="fab fa-google-plus-square"></i></a>
</span>
  </div>
</section>
        </div>

      <?php include('../cuadro-reservas-lima.php');?>

        <div class="mapadetalle">
        <h2 class="hidden-xs"> <span id="mytext" class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span> Click the Map to See</h2>
        <div class="centrarmapa mb-5"><img  id="myImg" src="../img/lima-miraflores-10am.jpg" alt="Free Walking Tour Lima 10am"  height="200"></div>

        <!-- The Modal -->
        <div id="myModal" class="modal">
          <span class="close">×</span>
          <img class="modal-content" id="img01" alt="mapa ubicacion">
          <div id="caption"></div>
        </div>
        </div>
      </aside>
<section class="redes-s hidden-xs" style="float: left;
width: 100%;
border: 2px solid #c8cbc4;
background-color: #ede58a;font-size: 1.7em;">
  <div class="row text-center mt-2 mb-3">
  <span class="tex-center">
  Tome la mejor decisión en Lima, lea nuestros más de 200 testimonios en:

   <a href="https://web.facebook.com/inkanmilkywaylimafreewalkingtour/"><i class="fab fa-facebook"></i></a>
   <a href="https://www.youtube.com/channel/UCjCwOb8Uayzl2pCLsntighg"><i class="fab fa-youtube-square"></i></a>
   <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294316-d14918493-Reviews-Inkan_Milky_Way_Tours_Lima-Lima_Lima_Region.html"><img src="/img/trip-advisor.jpg" class="mt-1" alt="" width="38" height="35"></a>
   <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1"><img src="/img/google-b.png" alt="" style="" width="40" height="38"></a>
   <a href="https://plus.google.com/+FreeWalkingToursLimaDistritodeLima"><i class="fab fa-google-plus-square"></i></a>
</span>
  </div>
</section>
     <div class="maps-c mb-5">
<h3 class="text-center mt-1" style="float: left;width: 100%;font-size: 1.6em;">Punto de Encuentro para Lima Free Tours a las 10am (Recojo en Miraflores) – Google maps</h3>
       <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15603.354161349951!2d-77.0279224!3d-12.1231975!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x3e2cd448586ebf0b!2sInkan+Milky+Way+Lima%2C+Free+Walking+Tour!5e0!3m2!1ses!2spe!4v1518131962531" width="1200" height="400" frameborder="1" style="border:0" allowfullscreen></iframe>
     </div>

         <div class="carousel-reviews broun-block hidden-xs">
 <h3 class="text-center mt-3" style="float: left;width: 100%;font-size: 1.6em;">What our customers are saying about us¡</h3>     
    <div class="container">
        <div class="">
            <div id="carousel-reviews1" class="carousel slide" data-ride="carousel"  data-interval="5000">
            
                <div class="carousel-inner">
                    <div class="item active">
                            <div class="col-md-4 col-sm-6">
                                  <div class="block-text rel zmin">
                                  <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Free Walking Tour Lima with Richard</a>
                                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                                  <p>We went on the walking tour with Richard. He met us in Miraflores and we took the bus to central Lima. This was very helpful as we learnt how to use the metro bus. We met the rest of the group and spent almost 3 hours seeing the main sights of Lima. Richard was very detailed and gave us lots of interesting information about the city and its history. Highly recommended. We also did a walking tour of Cusco with Incan Milky Way which is also great!</p>
                                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                </div>
                            <div class="person-text rel">
                               <img alt="" src="/img/reviews/free-walking-tour-lima (9).jpg" width="80">    
                              <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Stephanie Kelsall</a>
                          <!--     <i>from Glasgow, Scotland</i> -->
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 hidden-xs">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Decent Free Walking Tour in Lima center</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>Richard gave a quality tour where he took us around the historic part of downtown Lima, and we got to know the important buildings and their corresponding history. I'm glad we got to do the tour, otherwise without it, I would have missed out on a lot of historic information I would have liked to know about Peru. He speaks in both Spanish and English so it's certainly for everyone!  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="/img/reviews/free-walking-tour-lima (6).jpg" width="80">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Clara Lam</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>

                  <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Extremely knowledgeable tour Guide</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>Richard was an amazing tour guide! He is extremely knowledgeable and provided a highly comprehensive and entertaining tour. I learned so much about Lima and Peru on this tour and saw things I would’ve not noticed on my own. Highly highly recommend you do this on one of your first days in the city to get an overview - your trip will be all the richer after!<br>

                    The same company operates in Cusco! We will be taking that one there as well</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="/img/reviews/free-walking-tour-lima (5).jpg" width="80">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wendy Yang</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>

          </div>

          

    



                    <div class="item ">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Fantastic experience by walking</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                  <img alt="" src="/img/reviews/free-walking-tour-lima (3).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Ariana S</a>
              <!--   <i>from Glasgow, Scotland</i> -->
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wonderful free tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>I completed the Free Walking Tours Lima and Ricardo was a VERY informative guide. He may have spoken a little quickly, but from experience; I know this is how the folk from S. America speak. I think he tried to lose me during the "Changing of the guards" at the Presidential Palace, but I was fortunate to find the group and continue on. Ricardo even spoke of great restaurants to eat at and even had the pleasure and dining with him. He was a very cordial individual and would recommend his tour highly more than anyone else's on the web. Thanks again for a wonderful tour!!! Your friend--Matt.  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (1).jpg" width="80">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Matt Moore</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Tours a pie con Elvis</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Buen tour. 3 horas de información interesante e historias sobre Lima y Peru que no conocíamos en muy buen inglés. Realizamos el tour con Elvis. Muy buen guía, agradable y auténtico. ¡Definitivamente vale la pena! Good tour. 3 hours of interesting information and stories about Lima and Peru we did not know, in a very good English. We made the tour with Elvis. Very good guide, nice and authentic. Definitely I recommend it!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (4).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">TereDattari MargaPineda</a>
              </div>
            </div>
                    </div>



                    <div class="item">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="#">Enthusiastic Tour Guide, Elvis</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>It was a nice and very informative tour and our guide Elvis was very enthusiastic. It lasted for 3,5 hours and ended with the choice of having lunch together. It would have been nice with a short break for refreshments during the tour. Otherwise I'm very satisfied and would definitely recommend it.</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (8).jpg" width="80">
                <a title="" href="#">Hilma Hård af Segerstad</a>
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="#">Super informative tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (7).jpg" width="80">
                    <a title="" href="#">Ariana Joy </a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="#">Historia y Cultura en tour Lima</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Richard nos introdujo en la historia y arquitectura y vida social del centro histórico de Lima demostrando un gran conocimiento de la historia y la sociedad limeña. Con muchas anécdotas y amenas historias nos acompañó en este tour que nos resultó excelente. Felicitaciones!!! </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (2).jpg" width="80">
                <a title="" href="#">Pablo Zorrilla</a>
              </div>
            </div>
                    </div>
         
                                    
                </div>
                <a class="left carousel-control" href="#carousel-reviews1" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-reviews1" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </div>
    </div>

</div>


<div class="carousel-reviews broun-block hidden-sm hidden-md hidden-lg">

<h3 class="text-center mt-1 hidden-xs " style="float: left;width: 100%;font-size: 1.6em;">What our customers are saying about us¡</h3>
    <div class="container">
        <div class="">
            <div id="carousel-reviews" class="carousel slide" data-ride="carousel"  data-interval="5000">
            
                <div class="carousel-inner">
                    <div class="item active">
                            <div class="col-md-4 col-sm-6">
                                  <div class="block-text rel zmin">
                                 <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Free Walking Tour Lima with Richard</a>
                                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                                  <p>We went on the walking tour with Richard. He met us in Miraflores and we took the bus to central Lima. This was very helpful as we learnt how to use the metro bus. We met the rest of the group and spent almost 3 hours seeing the main sights of Lima. Richard was very detailed and gave us lots of interesting information about the city and its history. Highly recommended. We also did a walking tour of Cusco with Incan Milky Way which is also great!</p>
                                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                </div>
                            <div class="person-text rel">
                               <img alt="" src="/img/reviews/free-walking-tour-lima (9).jpg" width="80">    
                              <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Stephanie Kelsall</a>
                          <!--     <i>from Glasgow, Scotland</i> -->
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 hidden-xs">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Decent Free Walking Tour in Lima center</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>Richard gave a quality tour where he took us around the historic part of downtown Lima, and we got to know the important buildings and their corresponding history. I'm glad we got to do the tour, otherwise without it, I would have missed out on a lot of historic information I would have liked to know about Peru. He speaks in both Spanish and English so it's certainly for everyone!  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="/img/reviews/free-walking-tour-lima (6).jpg" width="80">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Clara Lam</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>

                  <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Extremely knowledgeable tour Guide</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>Richard was an amazing tour guide! He is extremely knowledgeable and provided a highly comprehensive and entertaining tour. I learned so much about Lima and Peru on this tour and saw things I would’ve not noticed on my own. Highly highly recommend you do this on one of your first days in the city to get an overview - your trip will be all the richer after!<br>

                    The same company operates in Cusco! We will be taking that one there as well</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="/img/reviews/free-walking-tour-lima (5).jpg" width="80">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wendy Yang</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>

          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Decent Free Walking Tour in Lima center</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>Richard gave a quality tour where he took us around the historic part of downtown Lima, and we got to know the important buildings and their corresponding history. I'm glad we got to do the tour, otherwise without it, I would have missed out on a lot of historic information I would have liked to know about Peru. He speaks in both Spanish and English so it's certainly for everyone!  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="/img/reviews/free-walking-tour-lima (6).jpg" width="80">
                          <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Clara Lam</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>
          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Extremely knowledgeable tour Guide</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>Richard was an amazing tour guide! He is extremely knowledgeable and provided a highly comprehensive and entertaining tour. I learned so much about Lima and Peru on this tour and saw things I would’ve not noticed on my own. Highly highly recommend you do this on one of your first days in the city to get an overview - your trip will be all the richer after!<br>

                    The same company operates in Cusco! We will be taking that one there as well</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="/img/reviews/free-walking-tour-lima (5).jpg" width="80">
                      <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wendy Yang</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>
          </div>



                    <div class="item ">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Fantastic experience by walking</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                  <img alt="" src="/img/reviews/free-walking-tour-lima (3).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Ariana S</a>
              <!--   <i>from Glasgow, Scotland</i> -->
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wonderful free tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>I completed the Free Walking Tours Lima and Ricardo was a VERY informative guide. He may have spoken a little quickly, but from experience; I know this is how the folk from S. America speak. I think he tried to lose me during the "Changing of the guards" at the Presidential Palace, but I was fortunate to find the group and continue on. Ricardo even spoke of great restaurants to eat at and even had the pleasure and dining with him. He was a very cordial individual and would recommend his tour highly more than anyone else's on the web. Thanks again for a wonderful tour!!! Your friend--Matt.  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (1).jpg" width="80">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Matt Moore</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Tours a pie con Elvis</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Buen tour. 3 horas de información interesante e historias sobre Lima y Peru que no conocíamos en muy buen inglés. Realizamos el tour con Elvis. Muy buen guía, agradable y auténtico. ¡Definitivamente vale la pena! Good tour. 3 hours of interesting information and stories about Lima and Peru we did not know, in a very good English. We made the tour with Elvis. Very good guide, nice and authentic. Definitely I recommend it!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (4).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">TereDattari MargaPineda</a>
              </div>
            </div>
                    </div>


          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Wonderful free tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>I completed the Free Walking Tours Lima and Ricardo was a VERY informative guide. He may have spoken a little quickly, but from experience; I know this is how the folk from S. America speak. I think he tried to lose me during the "Changing of the guards" at the Presidential Palace, but I was fortunate to find the group and continue on. Ricardo even spoke of great restaurants to eat at and even had the pleasure and dining with him. He was a very cordial individual and would recommend his tour highly more than anyone else's on the web. Thanks again for a wonderful tour!!! Your friend--Matt.  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (1).jpg" width="80">
                    <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Matt Moore</a>
              </div>
            </div>
          </div>


          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
              <div class="block-text rel zmin">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">Tours a pie con Elvis</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Buen tour. 3 horas de información interesante e historias sobre Lima y Peru que no conocíamos en muy buen inglés. Realizamos el tour con Elvis. Muy buen guía, agradable y auténtico. ¡Definitivamente vale la pena! Good tour. 3 hours of interesting information and stories about Lima and Peru we did not know, in a very good English. We made the tour with Elvis. Very good guide, nice and authentic. Definitely I recommend it!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (4).jpg" width="80">
                <a title="" href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.0307867,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598!9m1!1b1?hl=es-ES">TereDattari MargaPineda</a>
              </div>
            </div>
          </div>
                    <div class="item">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="#">Enthusiastic Tour Guide, Elvis</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>It was a nice and very informative tour and our guide Elvis was very enthusiastic. It lasted for 3,5 hours and ended with the choice of having lunch together. It would have been nice with a short break for refreshments during the tour. Otherwise I'm very satisfied and would definitely recommend it.</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (8).jpg" width="80">
                <a title="" href="#">Hilma Hård af Segerstad</a>
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="#">Super informative tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (7).jpg" width="80">
                    <a title="" href="#">Ariana Joy </a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="#">Historia y Cultura en tour Lima</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Richard nos introdujo en la historia y arquitectura y vida social del centro histórico de Lima demostrando un gran conocimiento de la historia y la sociedad limeña. Con muchas anécdotas y amenas historias nos acompañó en este tour que nos resultó excelente. Felicitaciones!!! </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (2).jpg" width="80">
                <a title="" href="#">Pablo Zorrilla</a>
              </div>
            </div>
                    </div>

                    <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                <div class="block-text rel zmin">
                    <a title="" href="#">Super informative tour in Lima</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Fantastic experience! This walking tour allowed me to see “Old Lima” in a way I never would have been able to on my own. Our guide was great — super informative, very attentive, and fielded any and all of our questions. Would definitely recommend this tour (for English and Spanish speakers!). When I visit Cusco, I will do the Cusco version of the tour there. Gracias!</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (7).jpg" width="80">
                    <a title="" href="#">Ariana Joy </a>
              </div>
            </div>
          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
              <div class="block-text rel zmin">
                <a title="" href="#">Historia y Cultura en tour Lima</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Richard nos introdujo en la historia y arquitectura y vida social del centro histórico de Lima demostrando un gran conocimiento de la historia y la sociedad limeña. Con muchas anécdotas y amenas historias nos acompañó en este tour que nos resultó excelente. Felicitaciones!!! </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/free-walking-tour-lima (2).jpg" width="80">
                <a title="" href="#">Pablo Zorrilla</a>
              </div>
            </div>
          </div>


                                    
                </div>
                <a class="left carousel-control" href="#carousel-reviews" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-reviews" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </div>
    </div>
</div>
 <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Inicio</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/es/lima/" itemprop="url" title="Lima" class="linkgeneral">
                                      <span itemprop="title">Lima</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Tour a pie - Centro Histórico de Lima - 10am</strong>
                                  </div>
                  </div>
    <div class="banners mt-5">
         <img src="../img/imgfooter.jpg" alt="publicidad logos">
      </div>
    <?php include('../footer.php');?>

    </div>
    </div>


<script src="https://code.jquery.com/jquery-2.2.3.min.js"></script> 


    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/easy-responsive-tabs.js"></script>
     <script src="../js/mapa-lima1.js"></script>
      <script src="../js/script-efectos.js"></script>
      
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"
        integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU="
        crossorigin="anonymous"></script>

          <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>
   
   <script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>

   <script>
 $.datepicker.regional['es'] = {
 closeText: 'Cerrar',
 prevText: '< Ant',
 nextText: 'Sig >',
 currentText: 'Hoy',
 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
 monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
 dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
 dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
 weekHeader: 'Sm',
 dateFormat: 'dd/mm/yy',
 firstDay: 1,
 isRTL: false,
 showMonthAfterYear: false,
 yearSuffix: ''
 };
 $.datepicker.setDefaults($.datepicker.regional['es']);
$(function () {
$("#fecha").datepicker();
});
</script>
   <script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submitlima.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>
     
<style>
    #owl-demo .item{
        margin: 3px;
    }
    #owl-demo .item img{
        display: block;
        width: 100%;
        height: auto;
    }
    </style>


  </body>


</html>