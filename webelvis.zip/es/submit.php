<?php
if($_POST)
{
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phno = $_POST['phno'];
    $fecha=$_POST['date'];
    $nombretours = $_POST['nombretour'];
    

$from = $_POST['email'];
$subject = 'Contact Us';
$message = 'Nombre: ' . $fname . 
"\n". 'E-mail: ' . $email. 
"\n". 'Tour:' . $nombretours.
"\n". 'Fecha:' . $fecha.  
"\n". 'Asunto:' . $lname. 
"\n". 'Mensaje:' . $phno;

$headers = "From: ". $from . "\n";
mail ('info@freewalkingtoursperu.com', $subject, $message, $headers);


    ?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2"><h2 class="contact-send">Su mensaje ha sido enviado, le responderemos lo más pronto posible.</h2>
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice"></span></td>
    </tr>
    </tbody></table>
    <?php
    
}

?>
