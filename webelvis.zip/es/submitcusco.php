
<?php
if($_POST)
{
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phno = $_POST['phno'];
    $fecha=$_POST['date'];
    $nombretours = $_POST['nombretour'];

    

$from = $_POST['email'];

$subject = 'Free Walks Cusco - Español';
$subject2= 'Sus Detalles de CONFIRMACIÓN - Cusco';
$message = 
'<table width="300" border="1" align="center" cellpadding="1" cellspacing="1"
  <tr>
    <th colspan="2">Tours a Pie Cusco<br></th>
  </tr>
  <tr>
    <td>Nombre<br></td>
    <td>'.$fname.'</td>
  </tr>
  <tr>
    <td>Tour<br></td>
    <td>'.$nombretours.'</td>
  </tr>
  <tr>
    <td>Fecha<br></td>
    <td>'.$fecha.'</td>
  </tr>
  <tr>
    <td>Nro Pax<br></td>
    <td>'.$lname.'</td>
  </tr>
  <tr>
    <th colspan="2">Mensaje<br></th>
  </tr>
   <tr>
   <th colspan="2">'.$phno.'<br></th>
  </tr>
</table>';

$message2 = 
'<table style="height: 173px; width: 506.433px;" border="1">
<tbody>
<tr>
<td style="width: 169px;">Compa&ntilde;ia:</td>
<td style="width: 312.433px; text-align: center;"><strong>Inka Milky Way Tours Cusco</strong></td>
</tr>
<tr>
<td style="width: 169px;">Nombre:</td>
<td style="width: 312.433px;">&nbsp;'.$fname.'</td>
</tr>
<tr>
<td style="width: 169px;">Tama&ntilde;o del Grupo:</td>
<td style="width: 312.433px;">&nbsp;'.$lname.'</td>
</tr>
<tr>
<td style="width: 169px;">Fecha del Tour a Pie:</td>
<td style="width: 312.433px;">&nbsp;'.$fecha.'</td>
</tr>
<tr>
<td style="width: 169px;">Hora de Inicio de Tour:</td>
<td style="width: 312.433px;">&nbsp;'.$nombretours.'</td>
</tr>
<tr>
<td style="width: 169px;">Lugar de Encuentro:</td>
<td style="width: 312.433px; text-align: center;"><a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.980109,15z/data=!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">Regocijo Plazoleta&nbsp;</a>(Kusipata) frente al&nbsp;<a href="https://www.google.com.pe/maps/place/Museo+del+Chocolate/@-13.5172359,-71.9804421,15z/data=!4m2!3m1!1s0x0:0x2f9797c884894ed0?sa=X&amp;ved=0ahUKEwjtmsrA0MzZAhVyUd8KHRaDDQAQ_BIIuQEwDg">Choco Museo</a>&nbsp;o La Municipalidad.</td>
</tr>
</tbody>
</table>
<p style="text-align: center;"><strong><span style="color: #000000;">IMPORTANTE:</span></strong></p>
<ul>
<li>Somos&nbsp;<strong>Inkan Milky Way Tours Cusco,</strong>su reserva est&aacute; confirmada, ya lo tenemos en nuestro sistema, lo estaremos esperando en el Punto de Encuentro Correcto, no haga que lo esperemos en vano, sino puede venir av&iacute;senos.</li>
<li>Busque por nosotros Elvis o Richard, vestimos el&nbsp;<span style="background-color: #ffff00;">Logo Inkan Milky Way</span> en los Chalecos Amarillos, identif&iacute;quenos por el Logo.</li>
<li>Si se perdi&oacute; de su free tour, a&uacute;n se puede unir a nuestros free tours en las siguientes salidas: De Lun a Sab: 10am &ndash; 1pm &ndash; 3:30pm &ndash; Cada Domingo a las 10am.&nbsp;</li>
<li>Los free tours en <span style="background-color: #ffff00;">Es</span><span style="background-color: #ff0000;">pa</span><span style="background-color: #ffff00;">&ntilde;ol</span> son de Lunes a Domingo a las 10am, Los free tours de lun a sab a la 1pm y 3:30pm solamente son en Ingles.</li>
<li>No ofrecemos visitas a Bares o Restaurantes; Ofrecemos Historia y Cultura.</li>
<li><span style="color: #ff0000;">No se confunda con personas ajenas a nuestra compa&ntilde;&iacute;a, ellos visten Polos (Remeras) Azules, Blancos, Rosados y Anaranjados &ndash;Tambi&eacute;n visten Chalecos Morados.</span></li>
<li>Vea nuestro&nbsp;<a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.980109,15z/data=!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">Punto de Encuentro en Cusco&nbsp;</a>en Google.</li>
</ul>
<p>Como encontrar nuestro punto de encuentro en Cusco? Estamos en la plazoleta&nbsp;<a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171337,-71.980109,15z/data=!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171337!4d-71.980109">REGOCIJO</a>, frente al&nbsp;<a href="https://www.google.com.pe/maps/place/Museo+del+Chocolate/@-13.5172359,-71.9804421,15z/data=!4m5!3m4!1s0x0:0x2f9797c884894ed0!8m2!3d-13.5172359!4d-71.9804421">Choco Museo</a>, llegar aqu&iacute; demora entre 2 min a 15 min a pie.</p>
<h3 style="text-align: center;"><strong>Haga su free tour con nosotros en tres ciudades:&nbsp;</strong><a href="https://www.freewalkingtoursperu.com/es/lima/"><strong>Lima</strong></a><strong>,&nbsp;</strong><a href="https://www.freewalkingtoursperu.com/es/arequipa/"><strong>Arequipa</strong></a><strong>&nbsp;y&nbsp;</strong><a href="https://www.freewalkingtoursperu.com/es/cusco/"><strong>Cusco</strong></a><strong>,&nbsp;</strong><a href="https://www.freewalkingtoursperu.com/es/reservar/"><strong>RESERVE AHORA</strong></a><strong>!</strong></h3>
<p>&nbsp;<span style="font-size: 12pt;"><strong style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #888888;"><span style="font-size: 14px; color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><img src="https://www.freewalkingtoursperu.com/es/img/maps-inkan-mily-way-es.jpg" alt="Meeting Point Cusco" width="492" height="285" /></span></strong></span></p>
<p><strong>www.freewalkingtoursperu.com es operado por:</strong><span style="font-family: Arial,Helvetica,sans-serif; font-size: 10pt;"><span style="color: #bd1398;"><br /></span></span></p>
<p><strong>Inkan Milky Way Tours Cusco</strong><br /> <span style="color: #ff00ff;">Numero de Contactos:</span><br /> <span style="color: #008000;">Whatsapp: +51 958745640 &amp; +51 984479073&nbsp;</span></p>
<p>&nbsp;</p>
';

$from3=$fname."<".$email.">";
$headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers .= "From: ". $from3 . "\n";

$from2='Inkan Milky Way Tours<info@freewalkingtoursperu.com>';
$headers2 = 'MIME-Version: 1.0' . "\r\n";
    $headers2 .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers2 .= "From: ". $from2 . "\n";

mail ('info@freewalkingtoursperu.com', $subject, $message, $headers);

mail ($from, $subject2, $message2, $headers2);





    ?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2" class="resultado1">Gracias por reservar con nuestro afiliado Inkan Milky Way - Tours by Foot Cusco, Le acabamos de enviar los Detalles de su CONFIRMACION, revise su BANDEJA DE ENTRADA o su BANDEJA DE CORREOS NO DESEADOS para que llegue al Punto de Encuentro Correcto y tenga el Guía calificado.
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">IMPORTANTE: Verifique su Punto de Encuentro de su Free Tour de acuerdo a la ciudad</span></td>
    </tr>
    </tbody></table>

    
    <?php
    
}

?>





