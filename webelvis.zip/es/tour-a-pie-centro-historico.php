<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Tours a Pie Cusco 10:00 am | Caminatas Guiadas Centro Historico</title>
    <meta content="Ven a disfrutar del mejor tour a pie en Cusco a las 10:00am lunes a sabado, úbiquenos en la Plaza Regocijo, busquenos por el logo FTF chalecos amarillos." name="description" />
    <meta content="tour a pie cusco, plaza de armas, centro historico, mercado san pedro, camintas guiadas" name="keywords" />
    <meta content="es" name="language" />


     <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">

 <!--   estilos slider pekeño -->
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
    
  </head>
  <body>

    <div id="fb-root"></div>

    <div class="container">
      <header class="cabecera">
      <div class="idiomas">
        <span class="en"><a href="/"><img src="../img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/"><img src="../img/es.png" alt="ingles"></a></span>
      </div>

       <div class="slider">
            <div id="wrappers" class="relativo over-effect">
          <!-- Slideshow 1 -->
                <ul class="rslides" id="slider2">

                  <li><img src="../img/slider-cusco-10-am.jpg" alt="free walking tours peru"></li>

             
                </ul>
          </div>
      </div>
            <?php include('../menu.php');?>
      </header>

 
    <div class="cuerpo">

      <section class="container izquierda">
      <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Inicio</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/es/cusco/" itemprop="url" title="Lima" class="linkgeneral">
                                      <span itemprop="title">Cusco</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Tour a pie - Centro Histórico del Cusco - 10:00am</strong>
                                  </div>
                  </div>

        <section class="cuadro-texto cuadro-contenedor">

          <h1>Free Walking Tour Cusco en el Centro Histórico – Caminatas Guiadas en Español</h1>
          <h2 class="sub-h2">Tour a Pie a las 10AM</h2>

           <div class="slidertours">
              <div id="demo">
                <div class="container">
                  <div class="row">
                    <div class="span12">

                      <div id="owl-demo" class="owl-carousel">
                        <div class="item"><img src="../img/free-walking-tours-cusco-1.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walking-tours-cusco-2.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walking-tours-cusco-3.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walking-tours-cusco-4.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walking-tours-cusco-1.jpg" alt="Owl Image"></div>

                      </div>
                      
                    </div>
                  </div>
                </div>
           </div>

          </div>

          <div class="wecolmetour">

          
          <p>Este recorrido a pie en Cusco por la mañana incluye el centro histórico conducido por guías profesionales y hacer de su estadía en la ciudad del Cusco inolvidable, tome nuestro Free Walking Tour Cusco – Caminatas Guiadas en Español en el casco monumental.</p>

          <p>Nuestro Tour a pie es totalmente plana, es decir no tendrá que preocuparse de subir gradas. Este tour está dirigido a todos los visitantes de todo el mundo y de todas las edades, se les invita cordialmente a tomar esta excursión para poder aprender, conocer, apreciar y valorar nuestra cultura, tradición, historia desde la época inca, colonial y republicana. </p><br>

          <h2  class="sub-tours">Que es un free walking tour en el centro histórico del Cusco?</h2>
          <p>
            El concepto de free tour fue creado por primera vez en la ciudad de Berlin, Alemania por Chrisopher Sandman un graduado de la Universidad de Yale en los Estados Unidos, (2003), que consiste en realizar visitas guiadas por lugares con relevancia histórica y al final del tour el turista hace una donación que no solo es para el guía sino para todo el equipo, la donación es hecha siempre y cuando el servicio haya sido buena caso contrario no hay necesidad, es decir en un walking tour Ud. paga por algo que vale la pena, en otras palabras NO es un tour barato sino un tour con mucha calidad que se recorre a pie en el casco monumental de la ciudad del Cusco, declarado Patrimonio Cultural del Humanidad por la Unesco en 1983.
          </p><br>

          <h2  class="sub-tours">Horarios de salida - Cuando?</h2>

              <p>Todos los días de Lunes a Sábado a las 10AM</p>

          <span class="text-primary">Donde es nuestro Punto de Encuentro?  </span>Plazoleta Regocijo (Kusipata) frente al Palacio Municipal o CHOCO MUSEO, vea nuestro mapa abajo o haga click en nuestro google map.<br><br>
          <span class="text-primary">Como reconocer al Guía de nuestra compañía?  </span>Nuestros Guías Oficiales visten el Logo <span class="letra-c">FTF en los Chalecos Amarillos.</span><br><br> 
          <span class="text-primary">Como ubicar nuestro Punto de Encuentro?  </span>Donde quiera que se encuentre en el centro histórico, dura entre 5 a 10 minutos llegar a nuestro punto de partida, utilice el Palacio Municipal o Choco Museo como referencia.<br><br> 
          <span class="text-primary">Idiomas disponibles para este tour a pie a las 10AM?  </span>Español e inglés, grupos separados.<br><br> 
          <span class="text-primary">Como participar en nuestro free tour? </span>Haga su reserva en esta hoja a la mano derecha o diríjase a reservas y recibirá una confirmación instantánea con los detalles de su reserva – también puede escribirnos a nuestro Whatsapp: +51 958745640 ó +51 974479073.<br><br>

          <span class="text-primary">Haga su reserva en esta hoja a la mano derecha o diríjase a reservas y recibirá una confirmación instantánea con los detalles de su reserva – también puede escribirnos a nuestro Whatsapp: +51 958745640 ó +51 974479073.</span>Tenemos tres free tours de lun a sab, y los domingos un solo tour, todos tienen el mismo itinerario.<br><br>

          <span class="text-danger">Nota Importante! </span>Para tomar nuestro servicio, no se confunda con personas ajenas a nuestra compañía: Tours by Foot Cusco – Inkan Milky Way, recuerde que con nosotros NO visitara bares, restaurantes, museos de café, chocolates, cata de cervezas. Para marcar la diferencia y originalidad nosotros le ofrecemos una perspectiva histórica de la ciudad Inka a través de una explicación profesional NO especulativa además de que somos una compañía 100% legal, vea nuestra autorización aquí. <br><br>
          

      

          </div>
          <div id="verticalTab">
              <ul class="resp-tabs-list">
                <li> <span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span>ITINERARIO</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span>INCLUYE</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span>FAQS - AVISO IMPORTANTE</li>
                </ul>
                <div class="resp-tabs-container">
                    <div>
                        <h2 class="h2-tours-detalle">Lugares a Visitar:</h2> 

                       <p class="texto-ciudades">Este itinerario es flexible dependiendo de muchas razones (festivales, huelgas, temporada de lluvias, etc.). Si usted es un blogger, critico en tripavisor, agente de Lonely Planet o alguien que le gusta escribir sus experiencias de viaje, por favor revise nuestras políticas, de esa manera podremos evitar malos entendidos, No obstante, haremos todo lo posible para que pueda tener una grata experiencia con nosotros.</p>

                     
                   <ul style="list-style-type: none" class="bi-ciudades">
                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Únase a nosotros en la Plaza Regocijo, frente al choco museo o la municipalidad, y busque ÚNICAMENTE el logotipo de FTF en el chaleco amarillo, <a target="_blank" href="punto-de-partida-horarios">Vea el Mapa</a> de Free Tours by Foot Cusco.</li>

                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>La visita comienza aprox. a las 10:10 am para los pasajeros de habla inglesa y el grupo en Español empieza a las 10:15 am.</li>

                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Cálida Bienvenida a la ciudad de Cusco y breve información histórica relevante de la ciudad de Cusco.</li>

                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>San Francisco Plaza (Jardín Botánico del Cusco).</li>

                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>El Arco de Santa Clara.</li>

                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Mercado local de San Pedro, fue diseñado por Alexandre Gustave Eiffel en 1925 en el interior del Mercado veremos: fetos de llama, carne deshidratada, jugo especial de rana, gelatina de colágeno de pata de res, sección de carnes, de frutas típicas, de panes, de quesos, de comidas típicas, de vegetales, etc.</li>

                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Plaza de Armas (Plaza Principal).</li>

                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Templo del Acclla Wasi (exterior-Templo de las vírgenes del Sol).</li>

         <!--            <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Observación y sesión de fotos con llamas y alpacas.</li> -->

                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Palacio de Pachaquteq (visita guiada desde el interior de lunes a viernes), el noveno emperador.</li>

                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Palacio del Inca Tupac Yupanqui (exterior).</li>
                    <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Demostración real de lana de alpaca.</li>

                  <!--   <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Degustación de Frutas Locales. </li> -->
                   </ul>

                    </div>

                    <div>
                      <div class="imagesit">
                        <img src="../img/ico-cusco-10am/inca-culture-free-walks-cusco.png" alt="inca-culture-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/best-picture-free-walks-cusco.png" alt="best-picture-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/accomodation-tips-free-walks-cusco.png" alt="accomodation-tips-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/history-free-walks-cusco.png" alt="history-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/catholicism-free-walks-cusco.png" alt="catholicism-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/geo-orientation-free-walks-cusco.png" alt="geo-orientation-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/inquires-free-walks-cusco.png" alt="inquires-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/andes-explation-free-walks-cusco.png" alt="andes-explation-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/maps-free-walks-cusco.png" alt="maps-free-walks-cusco">
                       <!--  <img src="../img/ico-cusco-10am/alpaca-watching-free-walks-cusco.png" alt="alpaca-watching-free-walks-cusco"> -->
                        <img src="../img/ico-cusco-10am/inca-arquitecture-free-walks-cusco.png" alt="inca-arquitecture-free-walks-cusco">
                    <!--     <img src="../img/ico-cusco-10am/llamas-free-walks-cusco.png" alt="llamas-free-walks-cusco"> -->
                        <img src="../img/ico-cusco-10am/travel-tips-free-walks-cusco.png" alt="travel-tips-free-walks-cusco">
                        <!-- <img src="../img/ico-cusco-10am/loca-fruit-samples-free-walks-cusco.png" alt="loca-fruit-samples-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/local-fruits-samples-free-walks-cusco.png" alt="local-fruits-samples-free-walks-cusco">
                        <img src="../img/ico-cusco-10am/local-fruits-free-walks-cusco-1.png" alt="local-fruits-free-walks-cusco-1"> -->
                      </div>
                    </div>

                   
                    <div>
                    <ul style="list-style-type: none">
                    <li> <p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>  ¿Dónde encuentro a mi guía? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">Nuestro único Punto de encuentro es en la Plaza Regocijo/Kusipata junto a la fuente, frente al CHOCO MUSEO  o la municipalidad.</p></li>

                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Cómo reconocer a nuestros guías en el Punto de Encuentro en Cusco? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">UNICAMENTE busque por el logotipo "FTF" en los chalecos amarillos, no se confunda</p></li>

                     <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Dónde termina el free tour? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">El tour termina a media cuadra del centro histórico del Cusco, a 5 minutos a pie desde la Plaza de Armas, en la calle San Agustín.</p></li>

                     <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>  ¿Cuánto debo pagar? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">Todas nuestras caminatas son financiadas por  <strong>PROPINAS DECENTES</strong>, esto es parte de nuestras <strong>políticas de reserva</strong> (recuerde que nuestros guías son profesionales pero también son personas que tienen sus familias y sólo viven de propinas que vienen a ser sus salarios) caso contrario puede optar por tours privados, todos están invitados a participar en nuestros free tours, sin embargo la decisión la toman los turistas. <br>

                    <strong>PROPINAS DECENTES</strong> significa que no se acepta 2 soles o 5 soles, toda propina DECENTE es a partir de 10 a 15 soles mínimo por persona, recuerde que solo son nuestras condiciones de reserva, nada personal.<br>

                    <strong>*Sabemos muy bien que la filosofía de hacer free tours es dar una propina voluntaria de acuerdo a la calidad del tour y la capacidad económica, PERO hay una tendencia en Sudamérica por parte de los turistas a DAR PROPINAS que equivalen a medio dólar o un dólar </strong>(Esto sucede probablemente porque muchos de ellos creen que países como Perú son subdesarrollados, razón por la cual dar de propina 1 dólar está bien y vale mucho por la tasa de cambio, lo cual es totalmente incorrecto porque ya sea aquí o en Brasil el costo de vida se ha incrementado bastante).<br>
                    <strong>No podemos asegurar la calidad del servicio de nuestros free tours en base a monedas o centavos por que los buenos guías no son baratos para ser contratados. Las propinas que todos los turistas dejan es prácticamente el salario de los guías y del personal que trabaja con nosotros.
                    Tome en cuenta también que los guías son hombres de familia así que tienen que vivir de algo.</strong><br>

                    <strong>*Somos una iniciativa privada, no tenemos patrocinio o apoyo de nadie ni siquiera por parte del Gobierno y así son todos los walking tours a nivel mundial.</strong></p>
                </li>

                <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>¿Cosas que deben llevar consigo? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">

                    Pedimos a nuestros turistas llevar consigo los siguientes artículos: <br>
                   
                  - Siempre ROPA CALIENTE - ABRIGADORA.<br>
                  - Bloqueador solar <br>
                  - Lentes de sol <br>
                  - Zapatos para caminar <br>
                  - Una gran  sonrisa y la voluntad de caminar<br>
                    
                    </p>

                    </li>
                    
                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>¿Idiomas disponibles? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">Inglés y Español, siempre que haya un número de turistas considerable ya sea para un guiado unilingue o bilingüe se requiere  de al menos 07 turistas.<br>

                  <span style="color:#1976d2">Siga la siguiente recomendación para el free tour 100% español en CUSCO:</span><br>

                  <strong>Venga de lunes a sábado a las 10am y los domingos 10AM siempre hay grupo en español. A la 1pm y 3.30pm de lunes a sábados solo en Inglés.</strong>
                  </p></li>


                     <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>¿Cuando sucede esto? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">De  LUNES A SABADO a las 10:00am. </p></li> 
                    
                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Cuánto tiempo dura?  (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">Todos nuestros Walking Tours en Cusco duran aproximadamente 2 horas y media, aproximadamente 1.6 km por lo que pedimos cordialmente a nuestros turistas tener ese tiempo disponible o dar a conocer al guía si es que desea retirarse antes de que el tour termine.
                    </p></li>
                      
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>¿Turistas mínimos necesarios para realizar el tour?  (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">A todos de nuestros clientes de habla hispana, les pedimos muy encarecidamente que se requiere de al menos 10 turistas para realizar el tour en Grupo unilingüe o bilingüe, caso contrario el guiado  será solamente en Ingles; Esto es DEBIDO A QUE ES MUY DIFICIL ENCONTRAR UN Guía que pueda TRABAJAR SOLO A PROPINAS y hacer un buen servicio en la ciudad de Cusco, para más informes sobre nuestras políticas vaya a la sección de NUESTRAS POLITICAS; Gracias por su comprensión. <br>
                    Si usted o su  familia están muy interesados en hacer el free tour en español, puede revisar nuestra sección de servicios tours privados y hacer su reservación con anticipación, dependerá mucho de la ciudad.

                    </p></li>

                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>¿Turistas máximos permitidos por grupo? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">20 pasajeros, ya sea para Inglés o Español, para más información ir a: nuestras políticas.</p></li>

                    <a href="#" class="alternar-todo"id="alternar-todo">Ver todas las respuestas</a>

                    </ul>
                    </div>
                </div>
            </div>

                <br />
                <div style="height: 30px; clear: both"></div>
          

         </section>

      </section>

      <aside class="derecha">
      <?php include('../cuadro-reservas-cusco.php');?>
       <div class="mapadetalle">
        <h2> <span class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span> Haga Click en el Mapa</h2>
        <div class="centrarmapa"><img id="myImg" src="../img/maps/cusco-walks.png" alt="Free Walking Tour Cusco 10:00 am" width="300" height="200"></div>

        <!-- The Modal -->
        <div id="myModal" class="modal">
          <span class="close">×</span>
          <img class="modal-content" id="img01" alt="mapa ubicacion">
          <div id="caption"></div>
        </div>
        </div>
      </aside>
   <div class="banners">
         <img src="../img/imgfooter.jpg" alt="publicidad logos">
      </div>
    <?php include('../footer.php');?>

    </div>

    </div>


  <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>

    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/easy-responsive-tabs.js"></script>
      <script src="../js/script-efectos.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

   <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>
    <script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submitcusco.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>




<style>
    #owl-demo .item{
        margin: 3px;
    }
    #owl-demo .item img{
        display: block;
        width: 100%;
        height: auto;
    }
    </style>



  </body>


</html>