<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Tour Peru Español | Lima | Mrflores| Cusco| Arequipa |City Tours cerca de Centros históricos</title>
    <meta content="Ofrecemos el mejor free walking tour peru en Español: Lima, Mrflores, Arequipa, Cusco, recomendado por +1600 opiniones en TripAdvisor | Nuestro city tour a pie es histórico y cultural, esperamos verlos en City Tours Lima, Arequipa o City Tours Cusco, también tenemos tours en Barranco." name="description" />
    <meta content="Free Tour Lima Miraflores, Arequipa, Cusco, Barranco en Español, lima by walking, city tour Lima centro, city tour Arequipa, city tour Lima Miraflores, tours centro de Lima, tour en lima, tours cerca de lima, city tour Cusco, city tours lima, tours en Lima y sus alrededores, city tour cusco en la mañana, tours cerca de cusco, full day Lima." name="keywords" />
    <meta content="es" name="language" />
    <meta name="author" content="Free Walking Tours" />
    <!-- Bootstrap -->
    <link rel="icon" type="image/ico" href="/img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">

    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />



  </head>
  <body>

  
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>


<!-- <div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center">NOTA:</h4>
            </div>
            <div class="modal-body">
        <p class="text-center">Nota 28 de  Julio<br>
Lima: Busquenos en Calle Tarata a las 10am | Solamente por esta ocasion haremos el free tour de Miraflores, NO iremos al centro de Lima, El free tour solamente sera en INGLES.<br> 
Cusco & Arequipa: Seguimos operando en los horarios regulares.</p>
                
            </div>
        </div>
    </div>
</div>
 -->
    <div class="container px-0">

      <?php include('menu.php');?>
      
      <!--  <div class="idiomas">
        <span class="en"><a href="/"><img src="img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/"><img src="img/es.png" alt="ingles"></a></span>
      </div> -->
      <header class="cabecera">
      
            <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-tour-cusco-centro.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-central-tours.jpg">
        <img src="../img/free-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/cusco-tour-lima.jpg">
        <img src="../img/tours-peru-free.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>
          

      </header>
    <div class="cuerpo">

      <section class="container izquierda">

                    <div class="margin0 col-lg-12 col-lg-12 col-xs-12">
                      <section class="content">

                      <h1>FREE WALKING CITY TOUR PERU ESPAÑOL | LIMA | AREQUIPA | CUSCO | MIRAFLORES | BARRANCO</h1>
                      <article>
                        <p>Tenga un c&aacute;lida bienvenida a Free Walking Tour Per&uacute; en Espa&ntilde;ol (en Lima, Arequipa, Cusco y mas), operado InkanMilkyWay Tours, una compa&ntilde;&iacute;a Local e Ind&iacute;gena con Gu&iacute;as Calificados &amp; Autorizados por el Estado Peruano; Quienes ofrecemos un Free City Tour memorable en el centro hist&oacute;rico de cada ciudad que visite en Per&uacute; | <strong>En Qu&eacute; consiste es un free tour?</strong> Es Lo &Uacute;ltimo en la Industria del Turismo donde no se requiere de una pago previo sino m&aacute;s bien, Ud. le pone el precio al final del free tour en directa proporci&oacute;n a la calidad del servicio, este sistema hace que Ud. como visitante tenga el poder de apreciar el trabajo de su gu&iacute;a y gratificar correctamente de acuerdo a la experiencia brindada, este nuevo innovador sistema de Free Tour fue creado por Christopher Sandman en Berlin, Alemania con un solo fin: <strong>Calidad en el tour</strong> y eso es lo que Ud. obtendr&aacute; al tomar nuestros free city tours a pie o free tours caminando | Nuestros tours cerca de Lima, Cusco, Arequipa y sus alrededores tienen lugar los centros hist&oacute;ricos de dichas ciudades.</p>
<p>Tenemos los mejores comentarios en Tripadvisor, Facebook y Google Maps, esto como resultado de un enfoque total a la Cultura &amp; Historia en nuestros free tours y city tours pre-pago, <strong>NO</strong> visitamos Bares, &uacute;nase a la mejor plataforma de Lima by walking, Lima a pie&iexcl;</p>

                        <p><b>IMPORTANTE!</b> Cada vez que Usted reserve un free tour asegúrese de llegar al punto de encuentro correcto con el guía indicado, si no puede asistir al free tour infórmenos, así de esta manera su guía no desperdiciará su tiempo esperándolo.</p>

                        <h2 class="text-center"><b>FREE WALKING CITY TOUR LIMA</b></h2>
                       <h4 class="text-center">El Mejor <a href="https://www.freewalkingtoursperu.com/es/lima/">free tour</a> operado por: Guias Locales | Inkan Milky Way Tours Lima</h4>

                     <p>Vienes Lima y no sabes qu&eacute; hacer? Ya est&aacute;s en Lima y desear hacer un city tour fuera de lo com&uacute;n? Entonces tenemos la mejor opci&oacute;n (free tour) para que puedas descubrir los secretos de la &ldquo;Ciudad de los Reyes&rdquo;, conozcamos juntos todo el centro hist&oacute;rico caminando, nuestros free city tours a pie ofrecen la manera <strong>m&aacute;s Moderna de visitar</strong> <strong>una ciudad</strong> en manos de Gu&iacute;as Locales Carism&aacute;ticos y Conocedores de su historia | Nuestros Tours en Lima y sus alrededores incluyen la visita de Plazas, Calles Coloniales, Iglesias, Muesos y mucho m&aacute;s durante 2.5 a 3.5 horas | Si se encuentra hospedado en Miraflores le recogeremos y luego tomaremos un Bus Local: &ldquo;Metropolitano&rdquo; para llegar al centro de Lima, si se encuentra en Barranco, tambi&eacute;n puede ser parte de nuestros free tours Lima | Vea nuestros m&aacute;s de 300 comentarios en <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294316-d14918493-Reviews-Inkan_Milky_Way_Tours_Lima-Lima_Lima_Region.html">TripAdvisor</a>, <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.028598,16z/data=!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598?hl=es-US">Google Maps Lima Miraflores</a> &amp; <a href="https://www.google.com/maps/place/Inkan+Milky+Way,+Free+Walking+Tour+Lima/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-US">Google Maps Lima centro</a> y <a href="https://www.facebook.com/limafreewalkingtour/">Facebook</a>, nos vemos pronto en nuestro free tour caminado en espa&ntilde;ol. &nbsp;</p>

                        <h2 class="text-center"><b>FREE WALKING CITY TOUR AREQUIPA</b></h2>
                        <h4 style="text-align: center;">El Mejor <a href="https://www.freewalkingtoursperu.com/es/arequipa/">free tour</a> operado por: Guias Locales | Free Tour Downtown Arequipa</h4>
<p>Arequipa, una ciudad enigm&aacute;tica, lleno de cultural, historia, escritores, poetas, pensadores, educadores, una ciudad adornada con nevados, volcanes como el Misti, profundos ca&ntilde;ones como el Cotahuasi y el Colca, una reconocida gastronom&iacute;a, caletas y playas y gente incre&iacute;ble | Si viene en direcci&oacute;n de esta ciudad disfrute de la autenticidad de nuestro free tour Arequipa en Espa&ntilde;ol(city tour Arequipa caminado) |&nbsp; Con nosotros caminara en manos de Gu&iacute;as Locales durante 2.5 horas, nuestro Tour Arequipa a pie incluye la visita de todo el centro hist&oacute;rico, explicaremos sobre atractivos tur&iacute;sticos enigm&aacute;ticos como La catedral, El Monasterio de Santa Catalina, Convento de Santo Domingo, Rio Chilli, Mercados y mucho m&aacute;s | Contemple nuestros m&aacute;s de 600 comentarios en <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Tripadvisor</a> Arequipa | Esperamos verlos en nuestros paseos a pie | Free Tours caminado.</p>
                        
                       <h2 class="text-center"><b>FREE WALKING CITY TOUR CUSCO</b></h2>
                       <h4 style="text-align: center;">El mejor <a href="https://www.freewalkingtoursperu.com/cusco/">free tour</a> operado por: Guias Locales | Inkan Milky Way Tours Cusco</h4>
<p>Bienvenido a la Capital del Imperio de Los Inkas, la m&aacute;s majestuosa civilizaci&oacute;n en Sudam&eacute;rica por eso tambi&eacute;n se denomina La Capital Arqueol&oacute;gica de Am&eacute;rica, hoy en d&iacute;a La Meca en la Industria del Turismo en Peru, Con&oacute;zcalo&iexcl; Vis&iacute;telo&iexcl; realizando un Free walking city tour Cusco (City tours Cusco a precios Libres | Tours Caminado) Una ciudad cosmopolita, llena de contrastes en su cultura, vivencia, culinaria y gente los cuales le dan una belleza peculiar &amp; sorprendente a esta ciudad, Un city tour en Cusco, es definitivamente un arranque perfecto para su habituaci&oacute;n y decidir qu&eacute; tipo de Tours en Cusco descubrir m&aacute;s adelante | Nuestros tours cerca de Cusco(centro hist&oacute;rico) comprende la visita a Mercados, Plazas Inkas, Calles Inkas, Muros Inkas, Templos, Arquitectura Inka y mucho m&aacute;s, tienen una duraci&oacute;n de 2.5 horas aprox | Vea nuestros m&aacute;s de 1600 comentarios en <a href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Inkan_Milky_Way_Tours_Cusco-Cusco_Cusco_Region.html">TripAdvisor</a>, <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171255,-71.982284,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953!9m1!1b1?hl=es-US">Google Maps Cusco</a> y <a href="https://www.facebook.com/freewalkingtourscusco/">Facebook</a> tambi&eacute;n estamos recomendados por <a href="https://books.google.com.pe/books?id=yE40DwAAQBAJ&amp;pg=PT364&amp;dq=Stefan+Loose+inkanmilkyway.com+cusco&amp;hl=es-419&amp;sa=X&amp;ved=0ahUKEwjq-Yy36LDaAhWG11MKHYYYAuMQ6AEIJjAA#v=onepage&amp;q=Stefan%20Loose%20inkanmilkyway.com%20cusco&amp;f=false">Stefan Loose</a>&nbsp;y&nbsp;<a href="http://www.routard.com/guide/code_dest/perou.htm">Le Routard</a>. Nos vemos pronto en nuestro free tour caminado en espa&ntilde;ol.&nbsp;</p>
                       
                      </article>

                      <ul class="redes_sociales">
                        <li><a href="https://es.pinterest.com/freetoursperu/" target="_blank"><i class="fa fa-pinterest-square" aria-hidden="true"></i></a></li>
                        <li><a href="https://www.facebook.com/FreeWalkingToursPeru" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></li>    
                        <li><a href="https://www.youtube.com/channel/UCw96I0FBc-Bo3NY6ipUkHVg" target="_blank"><i class="fa fa-youtube-square" aria-hidden="true"></i></a></li>
                        <li><a href="https://twitter.com/freetoursperu" target="_blank"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
                        <li><a href="https://plus.google.com/+Inkanmilkyway-freewalkingtourscusco" target="_blank"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>

                            
                        </ul>
                    </section>

                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-lg-6 col-sm-6 col-xs-12">

                                 <div class="fotofwt a-fijo">
                                   
                                        <div class="center positiontitleimg"> 
                                         <a href="/es/lima/">
                                          <h2><span class="tours-time limancolor"><span class="rojo">Free Walking Tour | City Tours </span> Lima</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                          <div id="myCarousel2" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-lima-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                            </div>
                                            <!-- Left and right controls -->
                                            <a class="left carousel-control" href="#myCarousel2" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel2" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                               <!-- <img class="efectoimg"src="img/t2.jpg"> -->
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/lima/">
                                               <span class="time"><span class="days">De Lunes a Sabado </span>10AM & 11AM & 3PM</span> 
                                            </a>
                                          </div>
                                       
                                </div>
                            
                               
                        
                                  <div class="fotofwt a-fijo">
                                  
                                       <div class="center positiontitleimg"> 
                                         <a href="/es/miraflores/">
                                          <h2><span class="tours-time limacolor"><span class="rojo">Free Walking Tour | City Tours </span> Miraflores</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                          <div id="myCarousel3" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-miraflores-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                            
                                            </div>
                                            <a class="left carousel-control" href="#myCarousel3" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel3" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                             <!--   <img class="efectoimg"src="img/t3.jpg"> -->
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/miraflores/">
                                               <span class="time"><span class="days">Tours Diarios</span>4:15pm</span> 
                                            </a>
                                          </div>
                                </div>
                     </div>

                      <div class="col-lg-6 col-lg-6 col-sm-6 col-xs-12">
                            
                                <div class="fotofwt a-fijo">
                                   
                                         

                                           <div class="center positiontitleimg"> 
                                         <a href="/es/arequipa/">
                                          <h2><span class="tours-time arequipacolor"><span class="rojo">Free Walking Tour | City Tours </span> Arequipa</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                               <!-- <img class="efectoimg"src="img/t4.jpg"> -->
                                               <div id="myCarousel4" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-arequipa-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                              <!-- <div class="item">
                                                <img src="img/free-walking-tour-arequipa-2.jpg" alt="Chania" width="460" height="345">
                                              </div> -->
                                             <!--  <div class="item">
                                                <img src="img/free-walking-tour-arequipa-3.jpg" alt="Flower" width="460" height="345">
                                              </div> -->
                                            
                                            </div>
                                            <!-- Left and right controls -->
                                            <a class="left carousel-control" href="#myCarousel4" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel4" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/es/arequipa/">
                                               <span class="time"><span class="days">Tours Diarios</span>10:00am & 3.00pm</span> 
                                            </a>
                                          </div>
                                          
                                </div>

                                 <div class="fotofwt a-fijo">
                                         <div class="center positiontitleimg"> 
                                         <a href="/es/cusco/">
                                          <h2><span class="tours-time cuscocolor"><span class="rojo">Free Walking Tour | City Tours </span> Cusco</span></h2>
                                          </a>
                                         </div>
                                          <div class="slidert">
                                            <div id="myCarousel1" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner" role="listbox">
                                              <div class="item active">
                                                <img src="img/free-walking-tour-cusco-1.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                              <!-- <div class="item">
                                                <img src="img/free-walking-tour-cusco-2.jpg" alt="Chania" width="460" height="345">
                                              </div>
                                              <div class="item">
                                                <img src="img/free-walking-tour-cusco-3.jpg" alt="Flower" width="460" height="345">
                                              </div> -->
                                            </div>
                                            <!-- Left and right controls -->
                                            <a class="left carousel-control" href="#myCarousel1" role="button" data-slide="prev">
                                              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="right carousel-control" href="#myCarousel1" role="button" data-slide="next">
                                              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                          </div>
                                              
                                         </div>
                                           <div class="space a-fijo">
                                            <a href="/cusco/">
                                                
                                                <span class="time"><span class="days dayly">Tours Lunes a Sabado</span>10:00am & 1:00pm & 3.30pm
                                                <span class="days dayly">Domingos</span>
                                                10.00am </span> 
                                            </a>
                                          </div>
                                </div>
                        
                                
                     </div>
            </div>
      </section>
      <aside class="derecha">
      <div class="trip-ciudades">
 

  <a target="_blank" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html"><img src="img/trip-advisor-arequipa.png" alt="trip-advisor-arequipa"></a>
  <a target="_blank" href="https://www.tripadvisor.com.pe/Attraction_Review-g294316-d14918493-Reviews-Inkan_Milky_Way_Tours_Lima-Lima_Lima_Region.html"><img src="img/trip-advisor-lima-miraflores.png" alt="trip-advisor-lima-miraflores"></a>
  <a target="_blank" href="https://www.tripadvisor.com.pe/Attraction_Review-g294314-d7238744-Reviews-Free_Tours_by_Foot_Cusco-Cusco_Cusco_Region.html"><img src="img/trip-advisor-cusco.png" alt="trip-advisor-cusco"></a>

</div>



<div class="facebookpubli">

  <div class="fb-page" 
  data-href="https://www.facebook.com/FreeWalkingToursPeru"
  data-width="380" 
  data-hide-cover="false"
  data-show-facepile="false" 
  data-show-posts="false"></div>
  
</div>




  
      </aside>

   <div class="banners">
       <img src="img/imgfooter.jpg" alt="publicidad free tours peru">
    </div>


    </div>

   <?php include('footer.php');?>
   
    <script src="https://code.jquery.com/jquery-2.2.3.min.js"></script>  
    <script src="/js/script.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- <script type="text/javascript">
  $(document).ready(function(){
    $("#myModal").modal('show');
  });
</script>
 -->
    <script src="../js/responsiveslides.min.js"></script>

        <script>
        // You can also use "$(window).load(function() {"
        $(function () {
          // Slideshow 1
            $("#slider2").responsiveSlides({
              maxwidth: 2600,
              speed: 500
            });
        });
    </script>
  </body>


</html>