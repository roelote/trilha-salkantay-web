
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <title>FREE Tour Arequipa Español | City Tour Arequipa | Centro Historico</title>
    <meta content="Contamos con la más destacada alternativa de Free Tour Arequipa Español en Perú | City Tour Arequipa (Tours Gratis*) Nuestros Tours Arequipa en el centro histórico(Tours cerca de Arequipa) son a pie, son tours caminando a precios libres con un enfoque cultural, nos vemos pronto en nuestro tour en Arequipa| Free Walking Tours Arequipa Español." name="description" />
    <meta content="Free Tour Cusco domingo, tours gratis cusco domingos, city tour cusco español, tours cerca de cusco, tour cusco en centro historico, free walking tour, tours gratis cusco por la tarde, free tour cusco por la tarde." name="keywords" />
    <meta content="es" name="language" />

    <!-- Bootstrap -->
        <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
       <link href="../css/stylefwt.css" rel="stylesheet">
       <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />
<link href="/css/flag-icon.min.css" rel="stylesheet">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
  </head>
  <body>
  <script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>

    <div id="fb-root"></div>

    <div class="container px-0">
      <header class="cabecera">
       <?php include('../menu.php');?>
            <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                      <ul class="rslides" id="slider2">
                         <li><img src="../img/home-free-walking-tour-arequipa.jpg" alt="free walking tours arequipa"></li>
                        <!-- <li><img src="../img/slider-arequipa-free-walks.jpg" alt="free walking tour arequipa"></li> -->
                      </ul>
                </div>
            </div> 
           
      </header>

    <div class="cuerpo">

      <section class="container izquierda">
      
            <div class="text-general col-lg-12 col-lg-12 col-xs-12">
              <h1>Free Tour Arequipa Español | City Tour Arequipa | Centro Historico </h1>

              <p>Viva la mejor experiencia en La Ciudad Blanca de Arequipa a precios Libres en Free Tour Arequipa en Espa&ntilde;ol, nuestros Tours Pie son totalmente Modernos y Electrizantes por eso estamos de moda en la Industria del Turismo: El Free Tour es el Futuro&iexcl; Por qu&eacute;? Porque Ud. tiene el poder de calificar el servicio de su Gu&iacute;a y gratificarlo en directa proporci&oacute;n al servicio prestado, esto es lo innovador en la industria del turismo debido a ello los free walking tours est&aacute;n de moda&iexcl; no nos cree? pues le invitamos a ver esta p&aacute;gina <a href="http://www.neweuropetours.eu/">Sandman free walking tour</a>: free tour en 19 paises, <a href="https://freetoursbyfoot.com/">freetoursbyfoot</a> free walks 25 paises | Un free tour es solamente para viajeros modernos del siglo 21 que deseen visitar una ciudad en manos de Gu&iacute;as Locales, 100% capacitados y certificados | Los esperamos en nuestro Free City Tour Arequipa.</p>
<p>Nuestros Free Walking City Tours Arequipa tienen una duraci&oacute;n de 2.5 horas, tenemos dos salidas y/o horarios de Lunes a Domingo a las 10am &amp; 3pm.</p>
<h2>Horarios:</h2>
<p>De Lunes a Domingo: 10am &amp; 3pm</p>
<h2>Punto de Encuentro:</h2>
<p>Calle <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5388673,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786">Santa Catalina 204</a>&nbsp;dentro del Choco Museo Chaqchao.</p>
<h2>C&oacute;mo identificar a nuestro Gu&iacute;a Oficial:</h2>
<p>Solamente pres&eacute;ntese en el Lugar Correcto &ndash; No uniformes</p>
<h2>Qu&eacute; Incluye nuestro free city tour Arequipa?</h2>
<p>Todos nuestros Free City Tours Arequipa incluyen visita del centro hist&oacute;rico a pie (Calles coloniales, Iglesias, Puentes, Museos) bastante cultura y historia.</p>
<h2>Duraci&oacute;n:</h2>
<p>2.5 a 3 horas.</p>
<h2>Precio:</h2>
<p>FREE Tours Libres &ndash; en base a Donaciones al final del free tour.</p>
<h2>Idioma:</h2>
<p>Grupos en Ingl&eacute;s y Espa&ntilde;ol de Lunes a S&aacute;bado a las 10am &amp; 3pm | Los Free Tours Arequipa cada Domingo es solamente en Ingles.</p>

  <div class="btn-reserva">
  
<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#titlea-side"><button type="button" class="btn btnreserva active">¡Reserva Ya!</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>

<p><span style="color: #ff0000;">Muy Importante:</span>&nbsp;NO se confunda con otras personas, b&uacute;squenos en la direcci&oacute;n correcta &amp; Nuestros Free Tours en Arequipa est&aacute;n operados por Free Tour Downtown Arequipa, una compa&ntilde;&iacute;a 100% Peruana,&nbsp;<a href="https://www.facebook.com/arequipafreewalkingtour/">S&iacute;ganos aqu&iacute;.</a></p>
    

              
            </div>

            <div class="row">

                                   <div class="ciudadfwt">

                                                  <div class="center"> 
                                                  <a href="tour-a-pie-centro-historico-plaza-de-armas"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking City Tour Arequipa - 10am</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/free-walking-tour-arequipa-10-am.jpg">
                                                  </div>

                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                          <span class="negrita-span"><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                          <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Todo los Días<br>
                                                          <span class="negrita-span"><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todos, incluyendo familias con hijos.<br>
                                                          <span class="negrita-span"><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 2.5 a 3 horas.<br>
                                                          <span class="negrita-span"><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>
                                                          <span class="negrita-span"><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Lugar de Encuentro:</strong></span> Calle Santa Catalina #204.<br>
                                                          <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma: </strong></span> English(Every Day) - Español(lun a Sab)  <br>
                                                          <span class="negrita-span"><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span>Calle Santa Catalina 204.<br>
                                                          
                                                    <div>
                                                        <div class="porciento50">
                                                        <span><a class="click-here" href="tour-a-pie-centro-historico-arequipa-plaza-de-armas"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>
                                                       </div> 
                                                        <div class="porciento50"><a href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                  </div>

                                  <div class="ciudadfwt">

                                                  <div class="center"> 
                                                  <a href="tours-a-pie-monasterio-santa-catalina-centro-historico"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking City Tour Arequipa - 3pm</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/free-walking-tour-arequipa-3-pm.jpg">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                          <span class="negrita-span"><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                          <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Todo los Días<br>
                                                          <span class="negrita-span"><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todos, incluyendo familias con hijos.<br>
                                                          <span class="negrita-span"><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 2.5 a 3 horas.<br>
                                                          <span class="negrita-span"><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>
                                                          <span class="negrita-span"><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Lugar de Encuentro:</strong></span> Calle Santa Catalina #204.<br>
                                                          <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma: </strong></span> English(Every Day) - Español(lun a Sab) <br>
                                                          <span class="negrita-span"><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span>Calle Santa Catalina 204.<br>
                                                          
                                                      <div>
                                                        <div class="porciento50">
                                                        <span><a class="click-here" href="tour-a-pie-centro-historico-arequipa-plaza-de-armas"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>
                                                        </div>
                                                        <div class="porciento50"><a href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                  </div>

                </div>

                 <div class="mapasciudad">
                   <!--  <div class="centrarimg">
                     <img src="../img/arequipa-walks.png" alt="">
                  </div> -->
                  <div class="row">

                      <div class="col-lg-12">
                          
                              <div class="col-lg-12 col-md-12 col-xs-12">
                              <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="Tour a Pie Arequipa 10 am - 3pm" data-caption="free walking tour lima 10 am" data-image="../img/arequipa-free-tours-es.png" data-target="#image-gallery">
                                  <img class="img-responsive" src="../img/arequipa-free-tours-es.png" alt="Another alt text">
                              </a>
                  </div>


                  <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <div class="modal-dialogo">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span><span class="sr-only">Close</span></button>
                                  <h4 class="modal-title" id="image-gallery-title"></h4>
                              </div>
                              <div class="modal-body">
                                  <img id="image-gallery-image" class="img-responsive" src="">
                              </div>
                              
                          </div>
                      </div>
                  </div>


                </div>
            <!-- /.row -->
      </section>

      <aside class="derecha" id="titlea-side">
        <?php include('../cuadro-reservas-arequipa.php');?>
               <div class="facebookpubli">
              <div class="fb-page" data-href="https://www.facebook.com/Free-Walking-Tour-Arequipa-1459711764055083" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/Free-Walking-Tour-Arequipa-1459711764055083" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/Free-Walking-Tour-Arequipa-1459711764055083">Free Walking Tour Arequipa</a></blockquote></div>
                
              </div>
      </aside>

      <div class="maps-c mb-5">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3827.5529682687084!2d-71.53886728513723!3d-16.39671918867933!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xfd3216dc3b492aee!2sInkan+Milky+Way+Arequipa%2C+Free+Walking+Tour!5e0!3m2!1ses!2spe!4v1522849728318" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
     </div>

     <section class="mt-5 pt-5 mb-5">

         <div id="wrap">
            <div class="card mb-5">
              <div class="thumb" id="one" style="background-image: url(../img/free-walking-tour-lima-10-30-am.jpg);}"></div>
              <div class="option">
                <i class="material-icons"></i>
                <i class="material-icons"></i>
                <i class="material-icons"></i>
              </div>
              <h3 class="text-center">Free Tour Lima</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Going to Lima? Join our free tour Partner, offering the best tip based walks, full on history & culture</p>
              <div class="add"><a  target="_blank" href="/es/lima/">More Info</a></div>
              <div class="buy"> <a target="_blank" href="/es/reservar">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="two" style="background-image: url(../img/cusco-private-tour.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Free Tour Cusco</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Are you planning to visist Cusco? Be part of the finest free walking tours operated by our Partner</p>
              <div class="add"> <a target="_blank" href="/es/cusco/">More Info</a></div>
              <div class="buy"><a target="_blank" href="/es/reservar/">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="three" style="background-image: url(../img/free-walking-tour-cusco-10-am.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Private Walks Cusco</h3>
              
              <p class="price">$35.00</p>
              
              <p class="desc mt-1 mb-3">Want a private walk? Then join our premier private walking tours, operated by a Local Indigenous Co</p>
               <div class="add"> <a target="_blank" href="#">More Info</a></div>
              <div class="buy"><a target="_blank" href="#">Book Know</a></div>
            </div>
          </div>

  
     </section>

 <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Inicio</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Arequipa</strong>
                                  </div>
  </div>
    <div class="banners mt-5">
       <img src="../img/imgfooter.jpg" alt="">
    </div>
    <?php include('../footer.php');?>


    </div>
  
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/mapa-arequipa.js"></script>
   <script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>

    <script language="javascript">
$(document).ready(function() {
    $().ajaxStart(function() {
        $('#loading').show();
        $('#result').hide();
    }).ajaxStop(function() {
        $('#loading').hide();
        $('#result').fadeIn('slow');
    });
    $('#form, #fat, #fo3').submit(function() {
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function(data) {
                $('#result').html(data);

            }
        })
        
        return false;
    }); 
})  
</script>
    

<script>
  
 $(document).ready(function(){

    loadGallery(true, 'a.thumbnail');

    //This function disables buttons when needed
    function disableButtons(counter_max, counter_current){
        $('#show-previous-image, #show-next-image').show();
        if(counter_max == counter_current){
            $('#show-next-image').hide();
        } else if (counter_current == 1){
            $('#show-previous-image').hide();
        }
    }

    /**
     *
     * @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
     * @param setClickAttr  Sets the attribute for the click handler.
     */

    function loadGallery(setIDs, setClickAttr){
        var current_image,
            selector,
            counter = 0;

        $('#show-next-image, #show-previous-image').click(function(){
            if($(this).attr('id') == 'show-previous-image'){
                current_image--;
            } else {
                current_image++;
            }

            selector = $('[data-image-id="' + current_image + '"]');
            updateGallery(selector);
        });

        function updateGallery(selector) {
            var $sel = selector;
            current_image = $sel.data('image-id');
            $('#image-gallery-caption').text($sel.data('caption'));
            $('#image-gallery-title').text($sel.data('title'));
            $('#image-gallery-image').attr('src', $sel.data('image'));
            disableButtons(counter, $sel.data('image-id'));
        }

        if(setIDs == true){
            $('[data-image-id]').each(function(){
                counter++;
                $(this).attr('data-image-id',counter);
            });
        }
        $(setClickAttr).on('click',function(){
            updateGallery($(this));
        });
    }
});
</script>
  </body>


</html>