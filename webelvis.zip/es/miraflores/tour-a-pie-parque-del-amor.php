<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>Tour Gratis a Pie Miraflores 4:15 pm | Visitas Guidas en Miraflores Barranco</title>
    <meta content="Disfrute del mejor tour gratis a pie por Miraflores y Barranco, a las 4:15pm, úbiquenos en el Parque Kennedy, Busque por el logo FTF en los chalecos amarillos." name="description" />
    <meta content="tour a pie barranco, miraflores, visitas guiadas larcomar, parque del amor" name="keywords" />
    <meta content="es" name="language" />

  <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">

 <!--   estilos slider pekeño -->
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">

     <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">


  </head>
  <body>

    <div id="fb-root"></div>

    <div class="container">
      <header class="cabecera">
      <div class="idiomas">
        <span class="en"><a href="/"><img src="../img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/"><img src="../img/es.png" alt="ingles"></a></span>
      </div>

       <div class="slider">
            <div id="wrappers" class="relativo over-effect">
          <!-- Slideshow 1 -->
                <ul class="rslides" id="slider2">

                  <li><img src="../img/mirafores-off-es.jpg" alt="free walking tours peru"> </li>


                </ul>
          </div>
      </div>
            <?php include('../menu.php');?>
      </header>

 
    <div class="cuerpo">

      <section class="container izquierda">
       <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Inicio</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/es/lima/" itemprop="url" title="miraflores" class="linkgeneral">
                                      <span itemprop="title">Miraflores</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Tour a pie – Miraflores – Parque del Amor – Barranco - 04:15pm</strong>
                                  </div>
                  </div>

        <section class="cuadro-texto cuadro-contenedor">

          <h1>Tour a pie – Miraflores – Parque del Amor </h1>

            <div class="slidertours">
              <div id="demo">
                <div class="container">
                  <div class="row">
                    <div class="span12">

                      <div id="owl-demo" class="owl-carousel">
                        <div class="item"><img src="../img/free-walks-miraflores-1.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walks-miraflores-2.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walks-miraflores-3.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walks-miraflores-1.jpg" alt="Owl Image"></div>

                      </div>
                      
                    </div>
                  </div>
                </div>
           </div>

          </div>

          <div class="wecolmetour">
            <ul>
<li><span style="color: #ff0000;">Ya NO hacemos free tours en Miraflores.</span></li>
<li><span style="color: #ff0000;">Todos nuestros free tours en Miraflores estan suspendidos.</span></li>
<li><span style="color: #ff0000;">Lo diremos de nuevo: Solamente nuestros free tours en Miraflores ya NO est&aacute;n en operaci&oacute;n</span> , sin embargo todos nuestros <a href="https://www.freewalkingtoursperu.com/es/lima/">free tours en Lima</a> est&aacute;n en operaci&oacute;n.</li>
<li>Para su free tour en Lima centro tenemos dos puntos de encuentro: Si se encuentra hospedado en <a href="https://www.freewalkingtoursperu.com/es/lima/tour-a-pie-centro-historico">Miraflores venga a las 10am</a> y si ya est&aacute; en el <a href="https://www.freewalkingtoursperu.com/es/lima/tours-a-pie-plaza-de-armas-centro-historico">centro de Lima s&iacute;game aqu&iacute;.</a></li>
</ul>
<p><span style="background-color: #ff0000; color: #ffffff;"><strong>MUY MUY IMPORTANTE:</strong> Nunca hacemos free tours en Barranco, asi que NUNCA busque por nosotros en el distrito de Barranco, porque si ve el nombre de nuestra compa&ntilde;&iacute;a (Inkan Milky Way Tours Lima) estese seguro que NO es nuestra compa&ntilde;ia sino personas con pocos escrupulos, mentirosos, timadores, competidores pobres tratando de colarse a nuestra compa&ntilde;&iacute;a.</span></p>
          </div>

          <div id="verticalTab">
                <ul class="resp-tabs-list">
                 <li> <span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span>ITINERARIO</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span>INCLUYE</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span>FAQS - AVISO IMPORTANTE</li>
                </ul>
                <div class="resp-tabs-container">
                    <div>
                    <<h2 class="h2-tours-detalle">Lugares a Visitar:</h2> 

                   <p class="texto-ciudades">Este itinerario es flexible dependiendo de muchas razones (festivales, huelgas, temporada de lluvias, etc.). Si usted es un blogger, critico en tripavisor, agente de Lonely Planet o alguien que le gusta escribir sus experiencias de viaje, por favor revise nuestras políticas, de esa manera podremos evitar malos entendidos, No obstante, haremos todo lo posible para que pueda tener una grata experiencia con nosotros.</p>

                         <ul style="list-style-type: none" class="bi-ciudades">

                              <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Únase a nosotros en el PARQUE KENNEDY frente a la iglesia Virgen Milagrosa a las 04:15 pm y busque UNICAMENTE por el logotipo "FTF" en el chaleco amarillo, <a target="_blank" href="punto-de-partida-horarios">Vea el Mapa</a> de Free Tours by Foot Lima.</li>
                              <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Una introducción histórica y actual del distrito. </li>
                              <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Parque de Gatos, la oportunidad de ver este parque único, en el que veremos un montón de gatitos abandonados.</li>
                              <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>El Terrorismo de los 80 en Tarata, el Partido Comunista solía ser llamado Sendero Luminoso  y esta organización terrorista estaba dirigido por ABIMAEL GUZMÁN.  </li>
                              <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>El Centro Cultural Ricardo Palma, el más moderno de Lima</li>
                              <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>El Parque del Amor extremadamente romántico, tomaremos fotos con el mar Pacífico como fondo, y daremos breve información sobre el mar peruano además del fenómeno de "El Niño"</li>
                              <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>El Larcomar, construida en el acantilado y el lugar donde uno puede ver marcas auténticas con precios increíbles o muy razonables (Nota: no es un tour para hacer compras, solo se pasa por este lugar para poder disfrutar de la modernidad del Perú.</li>
                      
                         </ul>
                       <h2 class="h2-tours-detalle"> Este Tour Incluye También:</h2> 
                         <ul style="list-style-type: none">
                           
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Guía profesional de turismo.</li>
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Recomendaciones fiables para cenar en restaurantes peruanos típicos.</li>
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Entradas gratuitas a las mejores discotecas de Miraflores y Barranco</li>
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Degustación de chocolates peruanos, un cóctel innovador Chocopisco, y 100% de Aguaymanto ( peruvianis phisylis)</li>
                          <li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Diferentes sorpresas cada día y mucho más.</li>

                         </ul>
                    </div>
                              <div>
                                <div class="imagesit">
                                <img src="../img/ico-miraflores-4-15pm/modernity-free-walks-miraflores.png" alt="modernity-free-walks-miraflores">
                                <img src="../img/ico-miraflores-4-15pm/panoramic-views-free-walks-miraflores.png" alt="panoramic-views-free-walks-miraflores">
                                <img src="../img/ico-miraflores-4-15pm/pacific-sea-free-walks-miraflores.png" alt="pacific-sea-free-walks-miraflores">
                                <img src="../img/ico-miraflores-4-15pm/history-free-walks-lima.png" alt="history-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/travel-tips-free-walks-lima.png" alt="travel-tips-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/acomodation-tips-free-walks-lima.png" alt="acomodation-tips-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/geo-orientation-free-walks-lima.png" alt="geo-orientation-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/inquires-free-walks-lima.png" alt="inquires-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/lisenced-company-free-walks-lima.png" alt="lisenced-company-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/pisco-sours-free-walks-lima.png" alt="pisco-sours-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/profesional-guides-free-walks-lima.png" alt="profesional-guides-free-walks-lima">
                                <img src="../img/ico-miraflores-4-15pm/chocolate-tastings-free-walks-lima.png" alt="chocolate-tastings-free-walks-lima">
                                
                                   

                              </div>
                              </div>
                    <div>
                    <ul style="list-style-type: none">
                    <li> <p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Dónde encuentro a mi guía? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">Nuestro Punto de encuentro es en el PARQUE KENNEDY frente a la iglesia Virgen Milagrosa</p></li>

                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Cómo reconocer a nuestros guías en el Punto de Encuentro en Miraflores? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">UNICAMENTE busque por el logotipo "FTF" en los chalecos amarillos, no se confunda</p></li>

                     <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Dónde termina el free tour? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">El tour termina en larcomar, distrito de Miralfores.</p></li>

                     <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>  ¿Cuánto debo pagar? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">Todas nuestras caminatas son financiadas por  <strong>PROPINAS DECENTES</strong>, esto es parte de nuestras <strong>políticas de reserva</strong> (recuerde que nuestros guías son profesionales pero también son personas que tienen sus familias y sólo viven de propinas que vienen a ser sus salarios) caso contrario puede optar por tours privados, todos están invitados a participar en nuestros free tours, sin embargo la decisión la toman los turistas. <br>

                    <strong>PROPINAS DECENTES</strong> significa que no se acepta 2 soles o 5 soles, toda propina DECENTE es a partir de 10 a 15 soles mínimo por persona, recuerde que solo son nuestras condiciones de reserva, nada personal.<br>

                    <strong>*Sabemos muy bien que la filosofía de hacer free tours es dar una propina voluntaria de acuerdo a la calidad del tour y la capacidad económica, PERO hay una tendencia en Sudamérica por parte de los turistas a DAR PROPINAS que equivalen a medio dólar o un dólar </strong>(Esto sucede probablemente porque muchos de ellos creen que países como Perú son subdesarrollados, razón por la cual dar de propina 1 dólar está bien y vale mucho por la tasa de cambio, lo cual es totalmente incorrecto porque ya sea aquí o en Brasil el costo de vida se ha incrementado bastante).<br>
                    <strong>No podemos asegurar la calidad del servicio de nuestros free tours en base a monedas o centavos por que los buenos guías no son baratos para ser contratados. Las propinas que todos los turistas dejan es prácticamente el salario de los guías y del personal que trabaja con nosotros.
                    Tome en cuenta también que los guías son hombres de familia así que tienen que vivir de algo.</strong><br>

                    <strong>*Somos una iniciativa privada, no tenemos patrocinio o apoyo de nadie ni siquiera por parte del Gobierno y así son todos los walking tours a nivel mundial.</strong></p>
                </li>

                <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Cosas que deben llevar consigo? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">

                    Pedimos a nuestros turistas llevar consigo los siguientes artículos: <br>
                   
                  - Siempre ROPA CALIENTE - ABRIGADORA.<br>
                  - Bloqueador solar <br>
                  - Lentes de sol <br>
                  - Zapatos para caminar <br>
                  - Una gran  sonrisa y la voluntad de caminar<br>
                    
                    </p>

                    </li>
                    
                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> Idiomas disponibles? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">Inglés y Español, siempre que haya un número de turistas considerable ya sea para un guiado unilingue o bilingüe se requiere  de al menos 07 turistas.<br>

                  <span style="color:#1976d2">Siga la siguiente recomendación para el free tour en español en LIMA:</span><br>

                  <strong>Venga a las 10.30am y 11.30am todos los días, siempre hay grupo en español al menos en temporada alta. El Free Tour de Miraflores solo en Inglés, si es que hubiese turistas en español se hace bilingüe.</strong>
                  </p></li>


                     <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> Cuando sucede esto? (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">Todos los días a las 4.15 pm. </p></li> 
                    
                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> ¿Cuánto tiempo dura?  (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">Todos nuestros Walking Tours en Lima duran aproximadamente 2.5 horas a 3 horas, 1.6 km por lo que pedimos cordialmente a nuestros turistas tener ese tiempo disponible o dar a conocer al guía si es que desea retirarse antes de que el tour termine.
                    </p></li>
                      
                      <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>¿Turistas mínimos necesarios para realizar el tour?  (<a href="#" class="alternar-respuesta">Ver</a>)</p>
                    <p class="respuesta" style="display:none">A todos de nuestros clientes de habla hispana, les pedimos muy encarecidamente que se requiere de al menos 10 turistas para realizar el tour en Grupo unilingüe o bilingüe, caso contrario el guiado  será solamente en Ingles; Esto es DEBIDO A QUE ES MUY DIFICIL ENCONTRAR UN Guía que pueda TRABAJAR SOLO A PROPINAS y hacer un buen servicio en la ciudad de Lima, para más informes sobre nuestras políticas vaya a la sección de NUESTRAS POLITICAS; Gracias por su comprensión. <br>
                    Si usted o su  familia están muy interesados en hacer el fre tour en español, puede revisar nuestra sección de servicios tours privados y hacer su reservación con anticipación, dependerá mucho de la ciudad.
                    </p></li>

                    <li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>¿Turistas máximos permitidos por grupo? (<a href="#" class="alternar-respuesta">ver</a>)</p>
                    <p class="respuesta" style="display:none">20 pasajeros, ya sea para Inglés o Español, para más información ir a: nuestras políticas.</p></li>

                    <a href="#" class="alternar-todo"id="alternar-todo">Ver todas las respuestas</a>

                    </ul>
                    </div>
                </div>
            </div>


          
          
         </section>

      </section>

      <aside class="derecha">
     <?php include('../cuadro-reservas-miraflores.php');?>
      <div class="mapadetalle">
        <h2> <span class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span>Click The Map to See</h2>
        <div class="centrarmapa"><img id="myImg" src="../img/miraflores-walks.png" alt="Free Walking Tour Miraflores 4:15 pm" width="300" height="200"></div>

        <!-- The Modal -->
        <div id="myModal" class="modal">
          <span class="close">×</span>
          <img class="modal-content" id="img01" alt="modal imagen mapa">
          <div id="caption"></div>
        </div>
        </div>

      </aside>

      <div class="banners">
         <img src="../img/imgfooter.jpg" alt="publicidad logos">
      </div>
    <?php include('../footer.php');?>

    </div>
    </div>

<script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>

     <script src="../js/bootstrap.min.js"></script>
    <script src="../js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/easy-responsive-tabs.js"></script>
      <script src="../js/script-efectos.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

        <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>
   <script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submitmiraflores.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>

<style>
    #owl-demo .item{
        margin: 3px;
    }
    #owl-demo .item img{
        display: block;
        width: 100%;
        height: auto;
    }

 
    </style>


  </body>


</html>