<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Tour a Pie Gratis Miraflores - Barranco | 4.15 pm </title>
    <meta content="El mejor tour a pie gratuito en miraflores y barranco, ubiquenos en el Parque Kennedy, busque por el logo FTF en los Chalecos Amarillos." name="description" />
    <meta content="tours gratis miraflores, caminatas gratuitas, caminatas gratuitas en barranco" name="keywords" />
    <meta content="en" name="language" />
   <meta name="author" content="Free Walking Tours" />

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
       <link href="../css/stylefwt.css" rel="stylesheet">
    
  </head>
  <body>

   <script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

    <div id="fb-root"></div>

    <div class="container">
      <header class="cabecera">

            <div class="idiomas">
        <span class="en"><a href="/miraflores/"><img src="../img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/miraflores/"><img src="../img/es.png" alt="ingles"></a></span>
      </div>
            <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                      <ul class="rslides" id="slider2">
                        <li><img src="../img/mirafores-off-es.jpg" alt="free walking tours lima"></li>
                      </ul>
                </div>
            </div>

               <?php include('../menu.php');?>
      </header>

    <div class="cuerpo">

      <section class="container izquierda">
       <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Inicio</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Miraflores</strong>
                                  </div>
                  </div>
            <div class="row col-lg-12 col-lg-12 col-xs-12">
              <h1>TOUR A PIE EN MIRAFLORES</h1>
<ul>
<li><span style="color: #ff0000;">Ya NO hacemos free tours en Miraflores.</span></li>
<li><span style="color: #ff0000;">Todos nuestros free tours en Miraflores estan suspendidos.</span></li>
<li><span style="color: #ff0000;">Lo diremos de nuevo: Solamente nuestros free tours en Miraflores ya NO est&aacute;n en operaci&oacute;n</span> , sin embargo todos nuestros <a href="https://www.freewalkingtoursperu.com/es/lima/">free tours en Lima</a> est&aacute;n en operaci&oacute;n.</li>
<li>Para su free tour en Lima centro tenemos dos puntos de encuentro: Si se encuentra hospedado en <a href="https://www.freewalkingtoursperu.com/es/lima/tour-a-pie-centro-historico">Miraflores venga a las 10am</a> y si ya est&aacute; en el <a href="https://www.freewalkingtoursperu.com/es/lima/tours-a-pie-plaza-de-armas-centro-historico">centro de Lima s&iacute;game aqu&iacute;.</a></li>
</ul>
<p><span style="background-color: #ff0000; color: #ffffff;"><strong>MUY MUY IMPORTANTE:</strong> Nunca hacemos free tours en Barranco, asi que NUNCA busque por nosotros en el distrito de Barranco, porque si ve el nombre de nuestra compa&ntilde;&iacute;a (Inkan Milky Way Tours Lima) estese seguro que NO es nuestra compa&ntilde;ia sino personas con pocos escrupulos, mentirosos, timadores, competidores pobres tratando de colarse a nuestra compa&ntilde;&iacute;a.</span></p>
            </div>

            <div class="row">
                              <!--        <div class="ciudadfwt">

                                                 <div class="center"> 
                                                  <a href="tour-a-pie-parque-del-amor"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Tour a Pie Miraflores - Barranco 4.15pm</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg" src="../img/free-walking-tour-miraflores-4-15-pm.jpg">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                   <span class="negrita-span"><strong>Tipo de Tour:</strong></span> Caminata Cultural y Modernidad. <br>
                                                    <span class="negrita-span"><strong>Bueno para:</strong></span> Todos, incluyendo familias con hijos.<br>
                                                    <span class="negrita-span"><strong>Duración:</strong></span> 2.5 a 3 horas.<br>
                                                    <span class="negrita-span"><strong>Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>
                                                    <span class="negrita-span"><strong>Lugar de Encuentro:</strong></span> <br>
                                                    <span class="negrita-span"><strong>Busque únicamente por:</strong></span> <br>
                                                    <span class="negrita-span"><strong>Descripción-más info:</strong> <a class="click-here" href="tour-a-pie-parque-del-amor">Haga Click Aquí</a></span>
                                                    <div>
                                                        <div class="porciento50">
                                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Pregúntenos</button>

                                                   
                                                        <div class="modal fade" id="myModal" role="dialog">
                                                          <div class="modal-dialog modal-sm">
                                                            <div class="modal-content">
                                                              <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                <h4 class="modal-title">Formulario de Pregunta</h4>
                                                              </div>
                                                              <div class="modal-body">
                                                                
                                                              </div>
                                                              
                                                            </div>
                                                          </div>
                                                        </div>
                                                       
                                                        </div>
                                                        <div class="porciento50"><a href="/booking/"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                  </div> -->
           <!--    <div class="mapasciudad mirafloresmapalado">
                  
               
                  <div class="row">

                      <div class="col-lg-12">
                          
                              <div class="col-lg-12 col-md-12 col-xs-12">
                              <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="Tour a Pie Miraflores 4.15pm " data-caption="free walking cusco" data-image="../img/miraflores-walks.png" data-target="#image-gallery">
                                  <img class="img-responsive" src="../img/miraflores-walks.png" alt="Another alt text">
                              </a>
                  </div>


                  <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <div class="modal-dialogo">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span><span class="sr-only">Close</span></button>
                                  <h4 class="modal-title" id="image-gallery-title"></h4>
                              </div>
                              <div class="modal-body">
                                  <img id="image-gallery-image" class="img-responsive" src="">
                              </div>
                              
                          </div>
                      </div>
                  </div>


                </div>
           </div>
                
            </div>   -->


                </div>
      </section>
    <br>
    <br>


      <aside class="derecha">
       
       <div class="facebookpubli">
  <div class="fb-page" data-href="https://www.facebook.com/FTFWALKINGTOURSLIMA/" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/FTFWALKINGTOURSLIMA/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/FTFWALKINGTOURSLIMA/">Free Walking Tour Lima</a></blockquote></div>
  
</div>
       
      </aside>
<!-- 
<div class="maps-c">
       <div id="map" style="width:100%;height:500px;"></div>
       <div class="contenedormap"></div>
     </div>
 -->
      
    <div class="banners">
       <img src="../img/imgfooter.jpg" alt="">
    </div>
  <?php include('../footer.php');?>


</div>

   
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/mapa-lima.js"></script>

<script language="javascript">
$(document).ready(function() {
    $().ajaxStart(function() {
        $('#loading').show();
        $('#result').hide();
    }).ajaxStop(function() {
        $('#loading').hide();
        $('#result').fadeIn('slow');
    });
    $('#form, #fat, #fo3').submit(function() {
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function(data) {
                $('#result').html(data);

            }
        })
        
        return false;
    }); 
})  
</script>


  
<script>
  
 $(document).ready(function(){

    loadGallery(true, 'a.thumbnail');

    //This function disables buttons when needed
    function disableButtons(counter_max, counter_current){
        $('#show-previous-image, #show-next-image').show();
        if(counter_max == counter_current){
            $('#show-next-image').hide();
        } else if (counter_current == 1){
            $('#show-previous-image').hide();
        }
    }

    /**
     *
     * @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
     * @param setClickAttr  Sets the attribute for the click handler.
     */

    function loadGallery(setIDs, setClickAttr){
        var current_image,
            selector,
            counter = 0;

        $('#show-next-image, #show-previous-image').click(function(){
            if($(this).attr('id') == 'show-previous-image'){
                current_image--;
            } else {
                current_image++;
            }

            selector = $('[data-image-id="' + current_image + '"]');
            updateGallery(selector);
        });

        function updateGallery(selector) {
            var $sel = selector;
            current_image = $sel.data('image-id');
            $('#image-gallery-caption').text($sel.data('caption'));
            $('#image-gallery-title').text($sel.data('title'));
            $('#image-gallery-image').attr('src', $sel.data('image'));
            disableButtons(counter, $sel.data('image-id'));
        }

        if(setIDs == true){
            $('[data-image-id]').each(function(){
                counter++;
                $(this).attr('data-image-id',counter);
            });
        }
        $(setClickAttr).on('click',function(){
            updateGallery($(this));
        });
    }
});
</script>

  </body>


</html>