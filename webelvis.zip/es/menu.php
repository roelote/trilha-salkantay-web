<div class="colormenu">
<div class="logo">
	<img class="" src="/img/logo-freewalks.png" alt="">
</div>

<div class="idiomas-header">
 <span class="en"><a href="/"><img src="../img/en.png" alt="español"></a></span>
      </div>
<div id='cssmenu' class="container-max">
          <ul>
             <li><a href='/es/'>Inicio</a></li>

             <li><a href='/es/lima/'>Lima</a>
				<ul class='lista-submenu-nav'>
				<li><a href='/es/lima/tour-a-pie-centro-historico'>Free Tour Lima Centro Hco. 10am, recojo en Miraflores</a></li>
				<li><a href='/es/lima/tours-a-pie-plaza-de-armas-centro-historico'>Free Tour Lima Centro Hco. 11am, empieza en Lima</a></li>
				<li><a href='/es/lima/tour-a-pie-centro-historico-por-la-tarde'>Free Tour Lima Centro Hco. 3pm, empieza en Lima</a></li>
			    <li><a href='/es/lima/tours-a-pie-desde-barranco'>Free Tour Lima Centro Hco. desde Barranco</a></li>
			   </ul>
             </li>
             <li><a href='/es/miraflores/'>Miraflores</a>
				<ul class='lista-submenu-nav'>
				<li><a href='/es/miraflores/tour-a-pie-parque-del-amor'>Tour a Pie 4:15pm - Free Tour</a></li>
			   </ul>
             </li>
             <li><a href='/es/arequipa/'>Arequipa</a>
				<ul class='lista-submenu-nav'>
				<li><a href='/es/arequipa/tour-a-pie-centro-historico-arequipa-plaza-de-armas'>Free Tour Arequipa Centro Hco. 10am</a></li>
				<li><a href='/es/arequipa/tours-a-pie-monasterio-santa-catalina-centro-historico-arequipa'>Free Tour Arequipa Centro Hco. 3pm</a></li>
			   </ul>
             </li>
             <li><a href='/es/cusco/'>Cusco</a>
				<ul class='lista-submenu-nav'>
				<li><a href='/es/cusco/tour-a-pie-centro-historico'>Free Tour Cusco Centro Hco. 10am</a></li>
				<li><a href='/es/cusco/tours-a-pie-centro-historico-barroco'>Free Tour Cusco Centro Hco. 1pm</a></li>
				<li><a href='/es/cusco/tour-gratis-centro-historico'>Free Tour Cusco Centro Hco. 3:30pm</a></li>
				<li><a href='/es/cusco/tour-a-pie-mercado-san-pedro-centro-historico'>Free Tour Cusco Centro Hco. Domingo 10am</a></li>
			   </ul>
             </li>
             <li><a href='/blog/'>Blog</a></li>
             <li><a href='/es/contactenos'>Contactenos</a></li>
             <li><a href='/es/reservar/'>Reservar</a></li>
          </ul>
 </div>
</div>