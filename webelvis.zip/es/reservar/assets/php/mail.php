<?php

$errorMSG = "";

// NAME
if (empty($_POST["name"])) {
    $errorMSG = "Name is required ";
} else {
    $name = $_POST["name"];
}

// EMAIL
if (empty($_POST["email"])) {
    $errorMSG .= "Email is required ";
} else {
    $email = $_POST["email"];
}

// SIZE
if (empty($_POST["size"])) {
    $errorMSG = "Name is required ";
} else {
    $size = $_POST["size"];
}

// COMBO 1
if (empty($_POST["combo1"])) {
    $errorMSG = "Name is required ";
} else {
    $combo1 = $_POST["combo1"];
}


// COMBO 2
if (empty($_POST["combo2"])) {
    $errorMSG = "Name is required ";
} else {
    $combo2 = $_POST["combo2"];
}


// date
if (empty($_POST["datepicker"])) {
    $errorMSG = "Name is required ";
} else {
    $datepicker = $_POST["datepicker"];
}


// MESSAGE
if (empty($_POST["messages"])) {
   $messages = $_POST["messages"];
} else {
    $messages = $_POST["messages"];
}


$EmailTo = "info@freewalkingtoursperu.com";
$Subject = "BOOKING GENERAL EN ESPAÑOL";

// prepare email body text
$Body = "";
$Body .= "Booking Español";
$Body .= "\n";
$Body .= "Nombre: ";
$Body .= $name;
$Body .= "\n";
$Body .= "Correo: ";
$Body .= $email;
$Body .= "\n";
$Body .= "Cantidad: ";
$Body .= $size;
$Body .= "\n";
$Body .= "Ciudad: ";
$Body .= $combo1;
$Body .= "\n";
$Body .= "Hora : ";
$Body .= $combo2;
$Body .= "\n";
$Body .= "Fecha: ";
$Body .= $datepicker;
$Body .= "\n";
$Body .= "Mensaje: ";
$Body .= $messages;
$Body .= "\n";


// send email
$success = mail($EmailTo, $Subject, $Body, "From:".$email);

// redirect to success page
// redirect to success page
if ($success && $errorMSG == ""){
   echo "success";
}else{
    if($errorMSG == ""){
        echo "Something went wrong :(";
    } else {
        echo $errorMSG;
    }
}