<?php
if($_POST)
{
   $fname = $_POST['name1'];
    $email = $_POST['email2'];
    $nombretours = $_POST['ciudad1'];
    $fecha=$_POST['date1'];
    $lname = $_POST['size1'];
    $phno = $_POST['message1'];

    

$from = $_POST['email2'];

$subject = 'Free Walks Lima - Español';
$subject2= 'Sus Detalles de CONFIRMACION - Lima';
$message = 
'<table width="300" border="1" align="center" cellpadding="1" cellspacing="1"
  <tr>
    <th colspan="2">Tours a Pie Lima<br></th>
  </tr>
  <tr>
    <td>Nombre<br></td>
    <td>'.$fname.'</td>
  </tr>
  <tr>
    <td>Tour<br></td>
    <td>'.$nombretours.'</td>
  </tr>
  <tr>
    <td>Fecha<br></td>
    <td>'.$fecha.'</td>
  </tr>
  <tr>
    <td>Nro Pax<br></td>
    <td>'.$lname.'</td>
  </tr>
  <tr>
    <th colspan="2">Mensaje<br></th>
  </tr>
   <tr>
   <th colspan="2">'.$phno.'<br></th>
  </tr>
</table>';

$message2 = 
'<table style="height: 173px; width: 506.433px;" border="1">
<tbody>
<tr>
<td style="width: 169px;">Compa&ntilde;ia:</td>
<td style="width: 312.433px; text-align: center;"><strong>Inkan Milky Way Tours Lima </strong></td>
</tr>
<tr>
<td style="width: 169px;">Nombre:</td>
<td style="width: 312.433px;">&nbsp;'.$fname.'</td>
</tr>
<tr>
<td style="width: 169px;">Tama&ntilde;o del Grupo:</td>
<td style="width: 312.433px;">&nbsp;'.$lname.'</td>
</tr>
<tr>
<td style="width: 169px;">Fecha del Tour a Pie:</td>
<td style="width: 312.433px;">&nbsp;'.$fecha.'</td>
</tr>
<tr>
<td style="width: 169px;">Hora de Inicio de Tour:</td>
<td style="width: 312.433px;">&nbsp;'.$nombretours.'</td>
</tr>
<tr>
<td style="width: 169px;">Lugar de Encuentro:</td>
<td style="width: 312.433px; text-align: left;">
<p>*<strong>10am</strong>&nbsp;Recojo: <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Calle Schell</a> a la altura del Mall Oechsle en Miraflores.</p>
<p><span style="font-weight: 400;">*</span><strong>11am &amp; 3pm: </strong><span style="font-weight: 400;">Ub&iacute;quenos frente a la </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">Iglesia La Merced</span></a><span style="font-weight: 400;">&nbsp;en Jir&oacute;n de la Uni&oacute;n a 5 min a pie desde la Plaza de Armas, Lima.</span></p>
</td>
</tr>
</tbody>
</table>
<p style="text-align: center;"><strong><span style="color: #000000;">CONSIDERE LO SIGTE:</span></strong></p>
<ul>
<li style="font-weight: 400;"><span style="font-weight: 400;">Somos </span><strong>Inkan Milky Way Tours Lima,</strong><span style="font-weight: 400;"> su reserva est&aacute; confirmada, ya lo tenemos en nuestro sistema, lo estaremos esperando en el Punto de Encuentro Correcto, no haga que lo esperemos en vano, sino puede venir av&iacute;senos.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Busque por nosotros Elvis o Richard, vestimos el <span style="background-color: #ffff00;">Logo Inkan Milky Way</span>, identif&iacute;quenos por el Logo.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Operamos free tours en Lima de Lun a Sab &ndash; </span><span style="font-weight: 400; color: #ff0000;">No Domingos</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Lima free tour a las 3pm:</span><span style="font-weight: 400;"> Si reservo este horario con mucha anticipaci&oacute;n, revise nuestra p&aacute;gina un d&iacute;a antes de asistir a </span><a href="https://www.freewalkingtoursperu.com/es/lima/tour-a-pie-centro-historico-por-la-tarde"><span style="font-weight: 400;">este free tour</span></a><span style="font-weight: 400;">.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400; color: #ff0000;">No nos busque en las plazas de Armas en ninguna parte del Per&uacute;</span><span style="font-weight: 400;">, somos una empresa legal, tenemos un punto de encuentro especifico.</span></li>
<li style="font-weight: 400;"><span style="color: #ff0000;"><span style="font-weight: 400;">No se confunda en Lima con Seudo-Guias que visten </span><strong>chalecos amarillos Falsos</strong> <strong>SIN</strong></span><span style="font-weight: 400;"> nuestro logo</span><span style="font-weight: 400;"> en la plaza de armas, <span style="color: #ff0000;">plaza san martin</span></span><span style="font-weight: 400; color: #ff0000;">.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Escriba su comentario de nuestro free tour en Lima en: </span><a href="https://web.facebook.com/InkanMilkyWayToursLima/"><span style="font-weight: 400;">Inkan Milky Way Tours Lima</span></a><span style="font-weight: 400;">.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Vea nuestros puntos de encuentro en Google maps: </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.1226699,-77.0328484,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.1226699!4d-77.0306597"><span style="font-weight: 400;">10am</span></a><span style="font-weight: 400;"> &amp;&nbsp;</span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">11am</span></a><span style="font-weight: 400;"> &amp; </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">3pm</span></a></li>
</ul>
<p><strong>C&oacute;mo encontrarnos en Miraflores?</strong> Estamos a solamente 1 min a pie desde el Parque Kennedy(Calle Schell, a la altura del Mall Oechsle).</p>
<p><strong>Haga su free tour con nosotros en tres ciudades: </strong><a href="https://www.freewalkingtoursperu.com/es/lima/">Lima</a><strong>, </strong><a href="https://www.freewalkingtoursperu.com/es/arequipa/">Arequipa</a><strong> y </strong><a href="https://www.freewalkingtoursperu.com/es/cusco/">Cusco</a><strong>, </strong><a href="https://www.freewalkingtoursperu.com/es/reservar/">RESERVE AHORA</a><strong>!</strong></p>
<p>&nbsp;<span style="font-size: 12pt;"><strong style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #888888;"><span style="font-size: 14px; color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><img src="https://www.freewalkingtoursperu.com/es/img/lima-mapa-espanish.jpg" alt="Meeting Point Cusco" width="267" height="250" /><img style="margin-left: 10px;" src="https://www.freewalkingtoursperu.com/es/img/free-tour-lima-map-11am-3pm.png" alt="Meeting Point Cusco" width="260" height="250" /></span></strong></span></p>
<p><span style="color: #bd1398;">Inkan&nbsp; Milky Way Tours Lima </span><span style="font-size: 9pt; font-family: sans-serif; color: #000000; background: white none repeat scroll 0% 0%;"><br /><span style="color: #008000;">Whatsapp</span>: </span><span style="font-size: 9pt; font-family: sans-serif; background: white none repeat scroll 0% 0%;">+51 958745640 &amp; +51 984479073.</span><span style="font-size: 9pt; font-family: sans-serif; color: #000000; background: white none repeat scroll 0% 0%;"><br /></span></p>
<p style="font-size: 11px;"><a href="http://www.freewalkingtoursperu.com">www.freewalkingtoursperu.com</a><strong> es operado por Inkan Milky Way Tours.</strong></p>
<p style="font-size: 11px;">Si su gu&iacute;a, no se present&oacute; en el punto de encuentro, por favor cont&aacute;ctenos, NO asuma algo malo, a veces hay huelgas en Lima, raz&oacute;n por la cual puede haber cancelaciones de free tour sin aviso previo, denos la oportunidad de explicar el caso.</p>
';

$from3=$fname."<".$email.">";
$headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers .= "From: ". $from3 . "\n";

$from2='Inkan Milky Way Tours & Walks<info@freewalkingtoursperu.com>';
$headers2 = 'MIME-Version: 1.0' . "\r\n";
    $headers2 .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers2 .= "From: ". $from2 . "\n";

mail ('info@freewalkingtoursperu.com ', $subject, $message, $headers);

mail ($from, $subject2, $message2, $headers2);




    ?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2" class="respuesta">Gracias por reservar con Inkan Milky Way Tours & Walks, Le acabamos de enviar los Detalles de su CONFIRMACION, revise su BANDEJA DE ENTRADA o su BANDEJA DE CORREOS NO DESEADOS para que llegue al Punto de Encuentro Correcto y tenga el Guía calificado.
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">IMPORTANTE: Verifique su Punto de Encuentro de su Free Tour de acuerdo a la ciudad.</span></td>
    </tr>
    </tbody></table>
    <?php
    
}

?>