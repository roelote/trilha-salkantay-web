<!doctype html>

<html lang="es">
  <head>

     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Booking Free Walking Tours Peru</title>

    <meta content="formulario de reservas free walking tour peru, lima, miraflores, arequipa, lima y cusco." name="description" />
    <meta content="booking free walking tours peru" name="keywords" />
    <meta content="en" name="language" />

    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css" media="screen">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

    
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet"> 

    <link rel="stylesheet" type="text/css" href="../css/easy-responsive-tabs.css" />

    <link rel="stylesheet" type="text/css" href="../css/jquery.fancybox.css?v=2.1.5" media="screen" />   

  
<style type="text/css">



</style>
  </head>
  <body>
    <div id="fb-root"></div>

    <div class="container px-0">
      <header class="cabecera">
                   <?php include('../menu.php');?>
                        <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-tour-cusco-centro.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-central-tours.jpg">
        <img src="../img/free-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/cusco-tour-lima.jpg">
        <img src="../img/tours-peru-free.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>




      </header>

 <div class="cuerpo">
    <!-- Full Body Container -->

    <section class="bookingiz">

     <div class="col-lg-12 col-lg-12 col-xs-12">
       <div id="container">

      <!-- Start Page Header -->
     
      <!-- End Page Header -->        
      
      <!-- Start Content Section -->
      <section id="content">
        <div class="container">
          <div class="row">
            <div class="centrarform">
              <h1 class="bookingh1">RESERVE AHORA</h1> 

              <p>Muchas Gracias, por dedicarle su tiempo en ver nuestra página web.
              Ayúdenos realizando una reserva, para que de esa manera podamos contratar los guías necesarios de acuerdo a la cantidad de asistentes a cada free tour.</p>
          
              <p>Reservar con nosotros es muy fácil, una vez que haga su pedido de reserva le enviaremos una respuesta <span class="letra-c"> instantánea</span> con los <span class="letra-c">Detalles de su Confirmación</span> y estará listo para atender a nuestros free tours.</p><br>
             
     


          
            
            <div class="confirmation-t mt-3 mb-3 pb-2">  
            <h3 class="text-center mt-1 mb-1"><span class="glyphicon glyphicon-envelope"></span>
           Confirmación Instantánea</h3>
              <p class="text-center">Una vez que reserve, inmediatamente recibirá un correo con los Detalles de su CONFIRMACIÓN - <b>Revise su bandeja de entrada o su spam box.</b></p>
            </div>

            
            <div class="cellp">Escoja su ciudad para su free tour</div>

            <!-- Start Contact Form -->
                       <!-- Start Contact Form -->
            <div id="parentHorizontalTab" class="mt-2">
                <ul class="resp-tabs-list hor_1">
                    <li>Cusco</li>
                    <li>Lima</li>
                    <li>Arequipa</li>
                </ul>
            <div class="resp-tabs-container hor_1">
                        <div>
                                <div id="form" class="result">
                                <form method="post" id="reg-form">
                                    
                                    <div class="contenidocajaform">
                                    <div class="form-group">
                                      <div class="controls">
                                      <label for="ejemplo_nombre">Nombre:</label>
                                        <input type="text" id="name" name="name" class="form-control"  required data-error="Ingrese su nombre">
                                        <div class="help-block with-errors"></div>
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <div class="controls">
                                      <label for="ejemplo_nombre">Correo:</label>
                                        <input type="email" class="email form-control" id="email" name="email" placeholder="Escriba bien su correo" required data-error="Ingrese su correo">
                                        <div class="help-block with-errors"></div>
                                      </div>
                                    </div>

                                   


                                    <div class="form-group">
                                      <label for="ejemplo_nombre">Numero Turistas: </label>
                                     <div class="controls">
                                            <select class="form-control" id="size" name="size"  required data-error="Ingrese el numero de turistas" >
                                              <option value="" disabled selected>Numero Turistas:</option>
                                              <option>1</option>
                                              <option>2</option>
                                              <option>3</option>
                                              <option>4</option>
                                              <option>5</option>
                                              <option>6</option>
                                              <option>7</option>
                                              <option>8</option>
                                              <option>9</option>
                                              <option>10</option>
                                            </select>
                                           </div>
                                          <div class="help-block with-errors"></div>
                                    </div>

                                    <div class="form-group">
                                             <div class="controls">
                                              <label for="sel1">Hora de Inicio del Free Tour:</label>

                                              <select class="form-control" name="ciudad" id="ciudad"> 
                                               <option value="" disabled selected>Elija el Horario del Free Tour</option>
                                                <option value="cusco-10am">Free Tour Cusco Centro 10am </option>
                                                <option value="cusco-1pm">Free Tour Cusco Centro 1pm </option>
                                                <option value="cusco-3-30pm">Free Tour Cusco Centro 3:30pm </option>
                                                <option value="cusco-10am-domingo">Free Tour Cusco Centro Domingo 10am </option>

                                              </select>
                                              </div>
                                      </div>      
                                      <div class="form-group">
                                      <div class="controls">
                                               <label for="comment">Fecha:</label>
                                               <input type="text" id="datepicker" name="date">
                                               </div>
                                      </div>

                                    <div class="form-group">
                                      <div class="controls">
                                      <label for="comment">Mensaje:</label>
                                        <textarea id="message" name="message" rows="7" placeholder=" IMPORTANTE para CUSCO: Todos los domingos solo tenemos UN solo free tour a las 10AM." class="form-control place-are" ></textarea>
                                        
                                      </div>  
                                    </div>
                                    <button type="submit" id="submit" class="btn btn-success"></i> Enviar</button>
                                    <div id="msgSubmit" class="h3 text-center hidden"></div> 
                                    <div class="clearfix"></div>   
                                                       </div>
                                  </form>

                              </div>
                            
                      </div>

                      <div>
                      
                             <div id="form" class="result1">
                                    <form method="post" id="reg-form1">
                                    
                                    <div class="contenidocajaform">
                                    <div class="form-group">
                                      <div class="controls">
                                      <label for="ejemplo_nombre">Nombre:</label>
                                        <input type="text" id="name1" name="name1" class="form-control"  required data-error="Ingrese su nombre">
                                        <div class="help-block with-errors"></div>
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <div class="controls">
                                      <label for="ejemplo_nombre">Correo:</label>
                                        <input type="email" class="email form-control" id="email2" name="email2" placeholder="Escriba bien su correo" required data-error="Ingrese su correo">
                                        <div class="help-block with-errors"></div>
                                      </div>
                                    </div>


                                    <div class="form-group">
                                      <label for="ejemplo_nombre">Numero Turistas: </label>
                                     <div class="controls">
                                            <select class="form-control" id="size1" name="size1"  required data-error="Ingrese el numero de turistas" >
                                              <option value="" disabled selected>Numero Turistas:</option>
                                              <option>1</option>
                                              <option>2</option>
                                              <option>3</option>
                                              <option>4</option>
                                              <option>5</option>
                                              <option>6</option>
                                              <option>7</option>
                                              <option>8</option>
                                              <option>9</option>
                                              <option>10</option>
                                            </select>
                                           </div>
                                          <div class="help-block with-errors"></div>
                                    </div>

                                    <div class="form-group">
                                    <div class="controls">
                                              <label for="sel1">Hora de Inicio del Free Tour :</label>

                                              <select class="form-control" name="ciudad1" id="ciudad1"> 
                                                 <option value="" disabled selected>Elija el Horario del Free Tour</option>
                                                  <option value="lima-10am">Free Tour Lima Centro 10am(recojo en Mrflrs</option>
                                                  <option value="lima-11am">Free Tour Lima Centro 11am </option>
                                                  <option value="lima-3pm">Free Tour Lima Centro 3pm</option>
                                              </select>
                                              </div>
                                        </div>      
                                      <div class="form-group">
                                      <div class="controls">
                                               <label for="comment">Fecha:</label>
                                               <input type="text" id="datepicker1" name="date1">
                                               </div>
                                      </div>

                                    <div class="form-group">
                                      <div class="controls">
                                      <label for="comment">Mensaje:</label>
                                        <textarea id="message1" name="message1" rows="7" placeholder="Nota Importante para Lima: Los Domingos NO operamos Free Tours" ></textarea>
                                        
                                      </div>  
                                    </div>
                                    <button type="submit" id="submit" class="btn btn-success"></i> Enviar</button>
                                    <div id="msgSubmit" class="h3 text-center hidden"></div> 
                                    <div class="clearfix"></div>   
                                                       </div>
                                 </form>

                                </div>

                      </div>
                      <div>
                                 <div id="form" class="result2">
                                    <form method="post" id="reg-form2">
                                    
                                    <div class="contenidocajaform">
                                    <div class="form-group">
                                      <div class="controls">
                                      <label for="ejemplo_nombre">Nombre:</label>
                                        <input type="text" id="name2" name="name2" class="form-control"  required data-error="Ingrese su nombre">
                                        <div class="help-block with-errors"></div>
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <div class="controls">
                                      <label for="ejemplo_nombre">Correo:</label>
                                        <input type="email" class="email form-control" id="email4" name="email4" placeholder="Escriba bien su correo" required data-error="Ingrese su correo">
                                        <div class="help-block with-errors"></div>
                                      </div>
                                    </div>

                                   
                                    <div class="form-group">
                                      <label for="ejemplo_nombre">Numero Turistas: </label>
                                     <div class="controls">
                                            <select class="form-control" id="size2" name="size2"  required data-error="Ingrese el numero de turistas" >
                                              <option value="" disabled selected>Numero Turistas:</option>
                                              <option>1</option>
                                              <option>2</option>
                                              <option>3</option>
                                              <option>4</option>
                                              <option>5</option>
                                              <option>6</option>
                                              <option>7</option>
                                              <option>8</option>
                                              <option>9</option>
                                              <option>10</option>
                                            </select>
                                           </div>
                                          <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                    <div class="controls">
                                              <label for="sel1">Hora de Inicio del Free Tour :</label>

                                              <select class="form-control" name="ciudad2" id="ciudad2">
                                                      <option value="" disabled selected>Elija el Horario del Free Tour</option>
                          <option value="arequipa-10am">Free Tour Arequipa Centro 10am </option>
                          <option value="arequipa-3pm">Free Tour Arequipa Centro 3pm </option>
                                              </select>
                                              </div>
                                        </div>      
                                      <div class="form-group">
                                            <div class="controls">
                                               <label for="comment">Fecha:</label>
                                               <input type="text" id="datepicker2" name="date2">
                                               </div>
                                      </div>

                                    <div class="form-group">
                                      <div class="controls">
                                      <label for="comment">Mensaje:</label>
                                        <textarea id="message" name="message2" rows="7" placeholder="" class="form-control" ></textarea>
                                        
                                      </div>  
                                    </div>
                                    <button type="submit" id="submit" class="btn btn-success"></i> Enviar</button>
                                    <div id="msgSubmit" class="h3 text-center hidden"></div> 
                                    <div class="clearfix"></div>   
                                                       </div>
                                 </form>

                          </div>
               
                </div>
            </div>
        </div>   
            <!-- End Contact Form -->     
            <!-- End Contact Form -->


            </div>
            
            </div>
           </div>
           </section>
      
       </div>

    </div>


            <!-- /.row -->
      </section>


      <aside class="bookingder">
          <div class="llamanos">
               <h4 class="llamanosya">

          <span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> Whatsapp
          </h4>
            <div class="telefonosbooking">

  <span class="glyphicon glyphicon-ok" aria-hidden="true"></span> LIMA - MIRAFLORES :
            <ul>
                 <li>Elvis +51 958745640</li>
      <li>Richard +51 984479073</li>
            </ul>

            </div>
            <div class="telefonosbooking">

  <span class="glyphicon glyphicon-ok" aria-hidden="true"></span> AREQUIPA : 
            <ul>
              <li>Bedgard +51 959305262</li>
            </ul>
  
            </div>
            <div class="telefonosbooking">

  <span class="glyphicon glyphicon-ok" aria-hidden="true"></span> CUSCO :
    <ul>
      <li>Elvis +51 958745640</li>
      <li>Richard +51 984479073</li>
    </ul>

            </div>
            <h4 class="llamanosya text-center">

          <span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span> Vea Nuestros Puntos de Encuentro de acuerdo a su Ciudad</h4>
             <div class="telefonosbooking mt-0">
                  <div class="mapabooking mt-1">
                  <p>Lima 10am</p>
                  <a class="fancybox" href="../img/lima-miraflores-10am.jpg" data-fancybox-group="gallery" title="Lima Walking Tour 10am"><img src="../img/maps/lima-miraflores-10am-m.jpg" alt="lima-10am-walks" /></a>
                  </div>
                  <div class="mapabooking mt-1">
                   <p>Lima 11am</p>
                  <a class="fancybox" href="../img/lima-centro-10-50am.jpg" data-fancybox-group="gallery" title="Lima Walking Tour 11am"><img src="../img/maps/lima-centro-10-50am-m.jpg" alt="lima-10-50am-walks" /></a>
                  </div>

                <!-- <div class="mapabooking mt-1">
                 <p>Miraflores</p>
                  <a class="fancybox" href="../img/maps/miraflores-walks.png" data-fancybox-group="gallery" title="Miraflores Walking Tour"><img src="../img/maps/miraflores-walks-m.jpg" alt="miraflores-walks" /></a>
                </div> -->
                <div class="mapabooking mt-1">
                 <p>Arequipa</p>
                  <a class="fancybox" href="../img/arequipa-free-tours-es.png" data-fancybox-group="gallery" title="Arequipa Walking Tour"><img src="../img/maps/arequipa-walks-m.jpg" alt="arequipa-walks" /></a>
                </div>
                <div class="mapabooking mt-1">
                 <p>Cusco</p>
                  <a class="fancybox" href="../img/maps-inkan-mily-way-es.jpg" data-fancybox-group="gallery" title="Cusco Walking Tour"><img src="../img/maps/cusco-walks-m.jpg" alt="cusco-walks" /></a>
                 </div>


                </div>
            </div>
       
     
      </aside>

        <?php include('../footer.php');?>

    </div>

    <!-- Main JS  -->
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
<!--     <script type="text/javascript" src="assets/js/jquery-min.js"></script>    -->   

    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/easy-responsive-tabs.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script type="text/javascript" src="../js/jquery.fancybox.js?v=2.1.5"></script>
    


      <script type="text/javascript">
    $(document).ready(function() {
      $('.fancybox').fancybox();
    });
  </script>
<script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>

    <script>
       $(function() {
               $("#datepicker1").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>

     <script>
       $(function() {
               $("#datepicker2").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>

   <script>
 $.datepicker.regional['es'] = {
 closeText: 'Cerrar',
 prevText: '< Ant',
 nextText: 'Sig >',
 currentText: 'Hoy',
 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
 monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
 dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
 dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
 weekHeader: 'Sm',
 dateFormat: 'dd/mm/yy',
 firstDay: 1,
 isRTL: false,
 showMonthAfterYear: false,
 yearSuffix: ''
 };
 $.datepicker.setDefaults($.datepicker.regional['es']);
$(function () {
$("#fecha").datepicker();
});
</script>



   <script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

    
    });
</script>

<script type="text/javascript">
$(document).ready(function()
{   

    $(document).on('submit', '#reg-form', function()
    {
        
        var data = $(this).serialize();
        
        $.ajax({
        
        type : 'POST',
        url  : 'submit1.php',
        data : data,
        success :  function(data)
                   {                        
                        $("#reg-form").fadeOut(500).hide(function()
                        {
                            $(".result").fadeIn(500).show(function()
                            {
                                $(".result").html(data);
                            });
                        });
                        
                   }
        });
        return false;
    });
});
</script>

<script type="text/javascript">
$(document).ready(function()
{   

    $(document).on('submit', '#reg-form1', function()
    {
        
        var data = $(this).serialize();
        
        $.ajax({
        
        type : 'POST',
        url  : 'submit2.php',
        data : data,
        success :  function(data)
                   {                        
                        $("#reg-form1").fadeOut(500).hide(function()
                        {
                            $(".result1").fadeIn(500).show(function()
                            {
                                $(".result1").html(data);
                            });
                        });
                        
                   }
        });
        return false;
    });
});
</script>

<script type="text/javascript">
$(document).ready(function()
{   

    $(document).on('submit', '#reg-form2', function()
    {
        
        var data = $(this).serialize();
        
        $.ajax({
        
        type : 'POST',
        url  : 'submit3.php',
        data : data,
        success :  function(data)
                   {                        
                        $("#reg-form2").fadeOut(500).hide(function()
                        {
                            $(".result2").fadeIn(500).show(function()
                            {
                                $(".result2").html(data);
                            });
                        });
                        
                   }
        });
        return false;
    });
});
</script>


  </body>
</html>
