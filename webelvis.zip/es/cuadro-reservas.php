


<div  id="cuadro-reservas">
    <section>
        <!-- <hgroup class="boooking">
            <span>CONTACT US</span>
        </hgroup> -->

<div id="container">
  <div id="form" class="result contact-uss">
  <?php
function dameURL(){
$url="http://".$_SERVER['HTTP_HOST'].":".$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];
return $url;
}
$urlweb=dameURL();

$resultado = substr($urlweb, 39);
$nombretour=str_replace("-"," ",$resultado);
$nombretour1=str_replace("/","-",$nombretour);

?>
      <form method="post" id="reg-form">


                      <label class="p-3 text-uppercase"><b>Envianos tus preguntas:</b></label>
                    <input type="hidden" name="nombretour" value=<?=$resultado?> /> 
        
                   <div class="form-group top15 padding10">
                    <label for="">Nombre:</label>
                      <i class="fa fa-user" aria-hidden="true"></i>
                      <input type="text" name="fname" id="lname" placeholder="Nombre:" required data-error="Ingrese Nombre" />
                    </div>
                    <div class="form-group padding10">
                      <label for="">Correo:</label>
                           <i class="fa fa-envelope-o" aria-hidden="true"></i>
                      <input type="email" name="email" id="email" placeholder="Correo" required data-error="Ingrese Correo" />
                    </div>

                    <div class="form-group padding10">
                      <label for="">Asunto:</label>
                       <i class="fa fa-tags" aria-hidden="true"></i>                           
                      <input type="text" name="asunto" id="asunto" placeholder="Asunto" required data-error="Ingrese Asunto" />
                    </div>
  

                      <div class="form-group padding10">
                        <label for="">Mensaje:</label>

                        <textarea class="form-control" name="phno" rows="7" placeholder="" id="comment" required data-error="Write your message"></textarea>
                      </div> 

                    <div class="centrarsend"><button type="submit">Enviar</button></div>
        </form>
    </div>
</div>
        

<style type="text/css">


#cuadro-reservas
{
  width: 35%;
  margin-top: 10px !important;
  float: left;
  margin-left: 15%;
  margin-bottom: 40px;
}
.contact-send {
    color: teal;
    font-size: 16px;
    padding: 13px;
    text-align: center;
}

@media only screen and (max-width: 700px){
#cuadro-reservas
{
  width: 100%;
  margin:0px;
}

  }
#container
{
  width: 100% !important;
}
input
{
  width:100%;
  height:35px;
  text-align:center;
  border:solid #cddcdc 2px;
  font-family:Verdana, Geneva, sans-serif;
  border-radius:3px;
}
button
{
  text-align:center;
  width:50%;
  height:35px;
  border:0;
  font-family:Verdana, Geneva, sans-serif;
  border-radius:3px;
  background:teal;
  color:#fff;
  font-weight:bolder;
  font-size:18px;
}
hr
{
  border:solid #cecece 1px;
}
.form-group
{
  position: relative;
}
.contact-uss .fa
{
color: teal;
width: 20px;
text-align: center;
position: absolute;
bottom: 4px;
left: 10px;
height: 23px;
padding: 0 10px;
font-size: 20px;
}
#header
{
  width:100%;
  height:50px;
  background:#00a2d1;
  text-align:center;
}
#header label
{
  font-family:Verdana, Geneva, sans-serif;
  font-size:35px;
  color:#f9f9f9;
}
.form-control
{
  /*color:#00acd4;*/
}
#cuadro-reservas hgroup
{
  color: gray !important;
}
#cuadro-reservas
{
  color:gray !important;
  border-color: gray !important;
  border:1px solid !important;
  border-radius: 4px;
  box-shadow: 2px 2px 2px;
}
a{
  color:#00a2d1;
  text-decoration:none;
}
</style>

</section>
</div>