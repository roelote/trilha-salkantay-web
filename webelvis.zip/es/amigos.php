<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Amigos Recomendados | Free Tours by foot</title>
    <meta content="amigos free tour en español" name="description" />
    <meta content="free walking tour miraflores, free walks, city tours, miraflores walking tour map" name="keywords" />
    <meta content="en" name="language" />
   <meta name="author" content="Free Walking Tours" />

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">
    
  </head>
  <body>

<style>
#backlinks{
  float:right;
  padding:0 20px;
  line-height:22px;
  font-weight:bold;
  font-size:13px;
}
#backlinks a{
  text-align:right;
  display:block;
}

/* Footer */
#footer{
  width:100%;
  position:fixed;
  padding-left:20px;
  bottom:0;
  left:0;
  line-height:20px;
  color:#888;
  font-size:13px;
  background:rgb(0, 0, 0);
  background:rgba(0, 0, 0, 0.8);
  z-index:99;
}
#footer span{
  display:block;
}

/* clearfix */
.clearfix {
  clear:both;
}

/* wrapper css */
#wrapper{
  margin-top:70px;
  width:100%;
}
#wrapper hgroup{
  text-align:center;
}
#wrapper h2{
  margin:5px 0;
  color:#FF6D99;
  text-shadow:1px 1px 2px #A50031;
  font-size:33px;
  font-family:Arial Narrow, Arial, sans-serif;
}
#wrapper h3{
  font-style:italic;
  font-weight:normal;
  font-size:18px;
  text-shadow:1px 1px 0 #fff;
  color:#888;
  margin:5px 0;
}

#container{
  position:relative;
  width:1100px;
  margin:0 auto 25px;
  padding-bottom: 10px;
  
}
.grid{
  width:188px;
  min-height:100px;
  padding: 15px;
  background:#fff;
  margin:8px;
  font-size:12px;
  float:left;
  box-shadow: 0 1px 3px rgba(34,25,25,0.4);
  -moz-box-shadow: 0 1px 3px rgba(34,25,25,0.4);
  -webkit-box-shadow: 0 1px 3px rgba(34,25,25,0.4);
  
  -webkit-transition: top 1s ease, left 1s ease;
  -moz-transition: top 1s ease, left 1s ease;
  -o-transition: top 1s ease, left 1s ease;
  -ms-transition: top 1s ease, left 1s ease;
}

.grid strong {
  border-bottom:1px solid #ccc;
  margin:10px 0;
  display:block;
  padding:0 0 5px;
  font-size:17px;
}
.grid .meta{
  text-align:right;
  color:#777;
  font-style:italic;
}
.grid .imgholder img{
  max-width:100%;
  background:#ccc;
  display:block;
}

@media screen and (max-width : 1240px) {
  body{
    overflow:auto;
  }
}
@media screen and (max-width : 900px) {
  #backlinks{
    float:none;
    clear:both;
  }
  #backlinks a{
    display:inline-block;
    padding-right:20px;
  }
  #wrapper{
    margin-top:90px;
  }
}
</style>



    <div id="fb-root"></div>
    <div class="container">
      <header class="cabecera">
        <div class="idiomas">
        <span class="en"><a href="/partners"><img src="img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/amigos"><img src="img/es.png" alt="ingles"></a></span>
      </div>
           <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                      <ul class="rslides" id="slider2">
                        <li><img src="img/partners.jpg" alt="free walking tours lima"></li>
                      </ul>
                </div>
            </div> 

               <?php include('menu.php');?>
      </header>

    <div class="cuerpo">

    <div class="container p-5">
      <div class="row">
        <h1>FREE WALKING TOUR PARTNERS - AMIGOS</h1>

        <p>Muchas Gracias por echarle una mirada a esta página, si está viajando a otros países, siéntase libre de tomar un free walking tour con nuestros amigos a nivel mundial, ellos los esperaran y atenderán de manera profesional.</p>

        <p>Como lo es en Perú o en Alemania, los free walking tours trabajan con donaciones económicas, literalmente no son gratis, por eso NO ofrecemos “tours gratis” sino FREE WALKING TOURS.</p>

        <h3>Tenga en cuenta las siguientes consideraciones:</h3>
              <ul>
                  <li> Todo free walking tour requiere de caminar, si le gusta caminar adelante tenga una maravillosa experiencia.</li>
                  <li> La mayoría de los walking tours duran 2.5 a 3.5 horas e incluyen una historia y cultura.</li>
                  <li> Muchas de las compañías de free tours requieren que Ud. haga su reserva.</li>
                  <li> También hay diferentes compañías en cada ciudad, por eso revise bien sobre como identificarlos.</li>

            </ul>
      </div>


<section id="wrapper">      
     <div id="container">

<div class="grid">
    <div class="imgholder">
      <img src="img/partners/freetourpraga-logo.jpg" />
    </div>
  
    <p>Nuestro free tour está diseñado para dar una introducción y así tener una idea general de la Ciudad de Praga, de sus personajes destacados y de sus acontecimientos históricos más importantes.!</p>
   <a target="blank" href="http://freetourpraga.com"><div class="meta">Ver Mas</div></a>



  </div>
  
        <div class="grid">
    <div class="imgholder">
      <img src="img/partners/free-walks-salta.png" />
    </div>
    
    <p>Enjoy a walk while you hear the background behind the old colonial town 
of Salta. We will visit the city highlights, including the old town hall, 
the cathedral and the magnificent Franciscan convent and learn about
 the heroes and stories of the most beautiful town in the north of Argentina.</p>
    <div class="meta">Ver Mas</div>
  </div>
  <div class="grid">
    <div class="imgholder">
      <img src="img/partners/san-fermin.png" />
    </div>
   
    <p>Get to know the most amazing places of Pamplona, their history and relationship 
with the festivals, make the best your journey in San Fermín by joining the 
pioneering free walking tour company, San Fermin Free Tour, Spain.</p>
    <div class="meta">Ver Mas</div>
  </div>
   <div class="grid">
    <div class="imgholder">
      <img src="img/partners/walking-tour-nomad.png" />
    </div>
  
    <p>Nomad Walking Tours LLC is happy to offer the first and only 
FREE Las Vegas Walking Tour of the world famous Las Vegas Strip,
unveil our city with us, professional tour guides.</p>
    <div class="meta">Ver Mas</div>
  </div>

  <div class="grid">
    <div class="imgholder">
      <img src="img/partners/free-walking-tour-naples.jpg" />
    </div>
  
    <p>During the free walking tours you will be able to discover what escapes from traditional visit and classic itineraries. The tours, by successfully mixing visit to less known places with true moments of the local day-life will let you feel to have experienced an authentical insight of this town.</p>
    <div class="meta">Ver Mas</div>
  </div>

  <div class="grid">
    <div class="imgholder">
      <img src="img/partners/bafreewalks.jpg" />
    </div>
  
    <p>In this free tour you get a historic and political perspective of our city, starting from the National Congress and walking the grand boulevard of Avenida de Mayo, with its architecture and sites, revealing the most glorious and terrible periods of our history.</p>
    <div class="meta">Ver Mas</div>
  </div>
  <div class="grid">
    <div class="imgholder">
      <img src="img/partners/logo-square-yellow.jpg" />
    </div>
  
    <p>Join us on an amazing journey through the infamous streets of Amsterdam. Discover how freedom and tolerance transformed a simple fisherman’s village into the centre of a vast trading empire and understand how these values continue to shape its liberal attitudes today.</p>
    <div class="meta">Ver Mas</div>
  </div>

  <div class="grid">
    <div class="imgholder">
      <img src="img/partners/logo_freewalkingtourprague.jpg" />
    </div>
  
    <p>Discover the most famous sights and hidden gems of Prague on 4 unique free tours in English. Free Walking Tour Prague is the only free tour operator in the Czech capital providing a complete tour of Prague totally on a free contribution basis!</p>
  <div class="meta">Ver Mas</div>
  </div>

    <div class="grid">
    <div class="imgholder">
      <img src="img/partners/free-tours-more.jpg" />
    </div>
    <p>In the Happy Strasbourg team, we are all native and passionate guides. Our goal is that during the visit, you feel like you are walking with a friend who would always be HAPPY, interesting, and also ready to give you all the advices you need, so no more hesitation.</p>
      <a target="blank" href="http://happy-strasbourg.eu"><div class="meta">Ver Mas!</div></a>
  </div>





    </div>
  </section>

     </div>


    <div class="banners">
       <img src="img/imgfooter.jpg" alt="">
    </div>
  <?php include('footer.php');?>


</div>

   
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
    <script src="../js/blocksit.min.js"></script>
  
<script>
$(document).ready(function() {
  //vendor script
  $('#header')
  .css({ 'top':-50 })
  .delay(1000)
  .animate({'top': 0}, 800);
  
  $('#footer')
  .css({ 'bottom':-15 })
  .delay(1000)
  .animate({'bottom': 0}, 800);
  
  //blocksit define
  $(window).load( function() {
    $('#container').BlocksIt({
      numOfCol: 4,
      offsetX: 8,
      offsetY: 8
    });
  });
  
  //window resize
  var currentWidth = 1100;
  $(window).resize(function() {
    var winWidth = $(window).width();
    var conWidth;
    if(winWidth < 660) {
      conWidth = 340;
      col = 1
    } else if(winWidth < 880) {
      conWidth = 660;
      col = 3
    } else if(winWidth < 1100) {
      conWidth = 880;
      col = 4;
    } else {
      conWidth = 1100;
      col = 5;
    }
    
    if(conWidth != currentWidth) {
      currentWidth = conWidth;
      $('#container').width(conWidth);
      $('#container').BlocksIt({
        numOfCol: col,
        offsetX: 8,
        offsetY: 8
      });
    }
  });
});
</script>




  </body>


</html>