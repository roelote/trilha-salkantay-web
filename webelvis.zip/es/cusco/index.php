<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>FREE Tour Cusco Español | City Tour Cusco | Centro Historico</title>
    <meta content="Somos la mejor alternativa para su Free Tour Cusco Español | City Tour Cusco, nuestro free tour es operado en el centro histórico (Tours cerca de cusco) | Nuestro tour Cusco a pie o caminando tienes precios Libres | Cusco Tour a Pie y Tours Gratis Cusco." name="description" />
    <meta content="Free Tour Cusco Español, city tour Cusco, tours cerca de cusco, tour en Cusco, tours gratis cusco, free tour centro historico de lima, city tours, free walking tour cusco, tour caminando en cusco, tours a pie cusco, tours gratis cusco" name="keywords" />
    <meta content="es" name="language" />
   <meta name="author" content="Free Walking Tours" />
    <!-- Bootstrap -->
    <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/styles.css" rel="stylesheet">
    <link href="/css/responsiveslides.css" rel="stylesheet">
    <link href="/css/stylefwt.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />
    <link href="/css/flag-icon.min.css" rel="stylesheet">
    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
  </head>
  <body>
   <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>
<script src="../js/mapa-cusco.js"></script>

    <div class="container px-0">
      <header class="cabecera">
            <?php include('../menu.php');?>
  
               <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                      <ul class="rslides" id="slider2">
                        <li><img src="../img/home-free-walking-tour-cusco.jpg" alt="free walking tours cusco"></li>
                        <!-- <li><img src="../img/cusco-slider-walking-tour.jpg" alt="free walking tours cusco"></li> -->
                      </ul>
                </div>
            </div>

              
      </header>

    <div class="cuerpo">

      <section class="container izquierda">
            
            <div class="text-general col-lg-12 col-lg-12 col-xs-12">
              <h1>Free Tour Cusco Español | City Tour Cusco | Centro Historico </h1> 
              <p>Exploremos juntos a pie la majestuosa y fascinante Ciudad del Cusco, Capital del Imperio de Los Inkas, denominado en el Idioma Quechua como Qosqo, epicentro económico, cultural, político y religioso de la civilización Andina | En nuestro Free Tour Cusco en Español, un city tour a pie Moderno y Electrizante le ilustraremos sobre la historia del Hombre Andino y la importancia de la ciudad del Cusco hoy día para todo el Perú y la Industria del Turismo, nuestro free city tour Cusco(free walking tour en el centro histórico – tours cerca de Cusco) es una plataforma moderna que ofrece un breve prefacio histórico de esta majestuosa Urbe Andina |  Nuestro Free City Tour en Cusco esta efectuado por Guías Oficiales de Turismo graduados de Institutos y/o Universidades de prestigio Quienes cuentan con la autorización del Ministerio de Turismo y Comercio Exterior para laborar como Guía de Turistas(En Perú para ser Guía de Turistas se requiere de un permiso emitido por el Ministerio de Turismo, el cual es posible obtener solamente habiendo estudiado La Carrera Profesional de Guía de Turistas), dicho esto nuestro tour en Cusco caminando es 100% de calidad y seguro.</p>

              <p>Nuestros Free Walking City Tours Cusco tienen una duración de 2.5 horas, tenemos varias salidas y/o horarios de lunes a sábado a las 10am & 1pm& 3:30pm y los domingos a las 10am (único horario).</p>
              
<h2>Horarios:</h2>
<p>De Lunes a S&aacute;bado: 10am &amp; 1pm&amp; 3:30pm y los Domingos a las 10am (&uacute;nico horario).</p>
<h2>Punto de Encuentro:</h2>
<p>Ub&iacute;quenos en la &nbsp;plazoleta&nbsp;<a href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.517125,-71.980095,14z/data=!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171255!4d-71.9800953?hl=es-US">REGOCIJO</a>&nbsp;frente al Choco Museo.</p>
<h2>C&oacute;mo identificar a nuestro Gu&iacute;a Oficial:</h2>
<ul>
<li>B&uacute;squenos en el Punto de Encuentro Correcto.</li>
<li>Busque por el Logo de Inkan Milky Way Tours Cusco en los chalecos amarillos.</li>
</ul>
<h2>Qu&eacute; Incluye nuestro free city tour Cusco?</h2>
<p>Todos nuestros Free City Tours Cusco incluyen visita del centro hist&oacute;rico a pie (Calles coloniales, Iglesias, Puentes, Museos) bastante cultura y historia &ndash; No visitamos Bares, No Bebidas.</p>
<h2>Duraci&oacute;n: </h2>
<p>2.5 a 3 horas.</p>
<h2>Precio: </h2>
<p>FREE Tours Libres &ndash; en base a Donaciones al final del free tour.</p>
<h2>Idioma:</h2>
<p>Grupos en Ingl&eacute;s y Espa&ntilde;ol de Lunes a Domingo a las 10am | Los Free Tours de Lunes a S&aacute;bado a la 1pm y 3:30pm solamente son en Ingles.</p>
        <div class="btn-reserva">
  
    <a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
    <a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

    <a href="#titlea-side"><button type="button" class="btn btnreserva active">¡Reserva Ya!</button></a>

    <a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
    <a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=hola%20puedes%20ayudarme"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
    </div>


<p><span style="color: #ff0000;">Muy Importante:</span>&nbsp;NO se confunda con otras personas, b&uacute;squenos en la direcci&oacute;n correcta, vestimos el Logo Inkan Milky Way en los chalecos amarillos &amp; Nuestros Free Tours en Cusco est&aacute;n operados por Inkan Milky Way Tours Cusco, una compa&ntilde;&iacute;a 100% Peruana,&nbsp;<a href="https://www.facebook.com/freewalkingtourscusco/">S&iacute;ganos aqu&iacute;.</a></p>

      

            </div>

            <div class="row">

                                  <div class="ciudadfwt bot25">

                                                 <div class="center"> 
                                                  <a href="tour-a-pie-centro-historico">
                                                  <h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking City Tour Cusco - 10am</span></span></h3>
                                                  </a>
                                                 </div>
                                                <div class="slidert">
                                                      
                                                        <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                       <img class="efectoimg"src="../img/free-walking-tour-cusco-10-am.jpg">
                                                      </div>

                                                        <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                          <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                          <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Lunes a Sábado<br>
                                                          <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todas las personas que puedan caminar.<br>
                                                          <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 2.5 a 3 horas.<br>
                                                          <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>
                                                          <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Lugar de Encuentro:</strong></span>Plazoleta Regocijo frente al CHOCO MUSEO <br>
                                                          <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma: </strong></span>English - Español <br>
                                                          <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span>Inkan Milky Way en los Chalecos Amarillos   <br>
                                                          
                                                          <div>
                                                              <div class="porciento50">
                                                        <span><a class="click-here" href="tour-a-pie-centro-historico"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>
                                                                </div> 
                                                              <div class="porciento50"><a href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                          </div>
                                                        </div>
                                               </div>
                                               
                                    </div>
                                      <div class="ciudadfwt bot25">


                                               <div class="center"> 
                                                  <a href="tours-a-pie-centro-historico-barroco"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking City Tour Cusco - 1pm</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg"src="../img/free-walking-tour-cusco-1-pm.jpg">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                          <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                          <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Lunes a Sábado<br>
                                                          <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todas las personas que puedan caminar.<br>
                                                          <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 2.5 a 3 horas.<br>
                                                          <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span> Ninguna, caminata plana 1.6 km.<br>
                                                          <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Lugar de Encuentro:</strong></span>Plazoleta Regocijo frente al CHOCO MUSEO<br>
                                                          <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma: </strong></span>Sólo Inglés <br>
                                                          <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span>Inkan Milky Way en los Chalecos Amarillos   <br>
                                                      <div>
                                                       <div class="porciento50">
                                                        <span><a class="click-here" href="tours-a-pie-centro-historico-barroco"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>
                                                       </div> 
                                                        <div class="porciento50"><a href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>

                                  </div>


                                  <div class="ciudadfwt">

                                                 <div class="center"> 
                                                  <a href="tour-gratis-centro-historico"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking City Tour Cusco - 3:30pm</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg"src="../img/tour-a-pie-centro-historico-cusco.jpg">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                          <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                          <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Lunes a Sábado<br>
                                                          <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todas las personas que puedan caminar.<br>
                                                          <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 2.5 a 3 horas.<br>
                                                          <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span>Ninguna, caminata plana 1.6 km.<br>
                                                          <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Lugar de Encuentro:</strong></span>Plazoleta Regocijo frente al CHOCO MUSEO<br>
                                                          <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma: </strong></span> Sólo Inglés<br>
                                                         <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span>Inkan Milky Way en los Chalecos Amarillos   <br>
                                                          
                                                    <div>
                                                       <div class="porciento50">
                                                        <span><a class="click-here" href="tour-gratis-centro-historico"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>
                                                       </div> 
                                                        <div class="porciento50"><a href="/es/reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>
                                        </div>
                                      <div class="ciudadfwt">
                                               <div class="center"> 
                                                  <a href="tour-a-pie-mercado-san-pedro-centro-historico"><h3 class="titulociudad"><span class="tours-time "><span class="rojo">Free Walking City Tour Cusco - Domingos - 10am</span></span></h3></a>
                                                 </div>
                                                <div class="slidert">
                                                  
                                                  <div class="imgslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                     <img class="efectoimg"src="../img/tour-a-pie-solo-domingos.jpg">
                                                  </div>
                                                  <div class="textoslider col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                          <span><i class="fa fa-tag" aria-hidden="true"></i><strong> Tipo de Tour:</strong></span> Caminata Cultural. <br>
                                                          <span><i class="fa fa-calendar" aria-hidden="true"></i><strong> Cuándo?:</strong></span> Solo Domingo<br>
                                                          <span><i class="fa fa-thumbs-up" aria-hidden="true"></i><strong> Bueno para:</strong></span> Todas las personas que puedan caminar.<br>
                                                          <span><i class="fa fa-clock-o" aria-hidden="true"></i><strong> Duración:</strong></span> 2.5 a 3 horas.<br>
                                                          <span><i class="fa fa-hand-paper-o" aria-hidden="true"></i><strong> Dificultad:</strong></span>Ninguna, caminata plana 1.6 km.<br>
                                                          <span><i class="fa fa-map-marker" aria-hidden="true"></i><strong> Lugar de Encuentro:</strong></span>Plazoleta Regocijo frente al CHOCO MUSEO<br>
                                                          <span><i class="fa fa-language" aria-hidden="true"></i><strong> Idioma: </strong></span>English - Español <br>
                                                          <span><i class="fa fa-eye" aria-hidden="true"></i><strong> Busque únicamente por:</strong></span>Inkan Milky Way en los Chalecos Amarillos   <br>
                                                          
                                                    <div>
                                                       <div class="porciento50">
                                                        <span><a class="click-here" href="tour-a-pie-mercado-san-pedro-centro-historico"><i class="fa fa-info-circle" aria-hidden="true"></i> Más Información</a></span>
                                                       </div> 
                                                        <div class="porciento50"><a href="reservar"><button type="button" class="btn btn-primary">Reserve Ahora</button></a></div>
                                                    </div>
                                                  </div>
                                               </div>

                                  </div>

                </div>
            <!-- /.row -->
            <div class="mapasciudad">
                    <!-- <div class="centrarimg">
                  <img src="../img/maps-inkan-mily-way-en.jpg" alt="">
                  </div> -->

                  <div class="row">

                      <div class="col-lg-12">
                          
                              <div class="col-lg-12 col-md-12 col-xs-12">
                              <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="Tour a Pie Cusco 10am - 1pm - 3.30pm - Domingo 10am " data-caption="free walking cusco" data-image="../img/maps-inkan-mily-way-es.jpg" data-target="#image-gallery">
                                  <img class="img-responsive" src="../img/maps-inkan-mily-way-es.jpg" alt="Another alt text">
                              </a>
                  </div>


                  <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <div class="modal-dialogo">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span><span class="sr-only">Close</span></button>
                                  <h4 class="modal-title" id="image-gallery-title"></h4>
                              </div>
                              <div class="modal-body">
                                  <img id="image-gallery-image" class="img-responsive" src="">
                              </div>
                              
                          </div>
                      </div>
                  </div>


                </div>
           </div>
      </div>
      </section>
    <br>
    <br>


      <aside class="derecha" id="titlea-side">
        <?php include('../cuadro-reservas-cusco.php');?>
      <div class="tripadvisor">
  <div id="TA_cdsratingsonlynarrow448" class="TA_cdsratingsonlynarrow">
<ul id="lcqzktl5F" class="TA_links iHAorEkhX">
<li id="k14sp8OALJ" class="OQePi0jRk2l">
<a target="_blank" href="https://www.tripadvisor.com.pe/"><img src="https://www.tripadvisor.com.pe/img/cdsi/img2/branding/tripadvisor_logo_transp_340x80-18034-2.png" alt="TripAdvisor"/></a>
</li>
</ul>
</div>
<script src="https://www.jscache.com/wejs?wtype=cdsratingsonlynarrow&amp;uniq=448&amp;locationId=7238744&amp;lang=es_PE&amp;border=true&amp;shadow=false&amp;backgroundColor=white&amp;display_version=2"></script>

</div>
         <div class="facebookpubli">

  <!-- <div class="fb-page" data-href="https://www.facebook.com/CuscoFTF/" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/CuscoFTF/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/CuscoFTF/">Free Tours by Foot Cusco</a></blockquote></div> -->

    <div class="blogpage display-n mb-5">
    <a target="_blank" href="/blog" ><img src="../img/blogger-free-tour-cusco.jpg" alt="blog-free-walking-tour-cusco"></a>
    </div>



    <div class="fb-page" data-href="https://www.facebook.com/freewalkingtourscusco/" data-width="380" 
    data-hide-cover="false"
    data-show-facepile="false" 
    data-show-posts="false"></div>
</div>

          <div class="chalecoc text-center mt-2 mb-5">
          <img src="../img/chaleco-imagen.png" alt="chalecos fwt" width="250px" >
        </div>

      

       
      </aside>
 
     
      <div class="maps-c mb-5">
       <div class="contenedormap"><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15517.202489400717!2d-71.980109!3d-13.5171337!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x49be8bcaa264818d!2sInkan+Milky+Way+Cusco%2C+Free+Walking+Tour!5e0!3m2!1ses!2spe!4v1520118233554" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>
     </div>
    <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Inicio</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Cusco</strong>
                                  </div>
                  </div>
          <section class="mt-5 pt-5 mb-5">

         <div id="wrap">
            <div class="card mb-5">
              <div class="thumb" id="one" style="background-image: url(../img/free-walking-tour-lima-10-30-am.jpg);}"></div>
              <div class="option">
                <i class="material-icons"></i>
                <i class="material-icons"></i>
                <i class="material-icons"></i>
              </div>
              <h3 class="text-center">Free Tour Lima</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3">Going to Lima? Join our free tour Partner, offering the best tip based walks, full on history & culture</p>
              <div class="add"><a target="_blank" href="/lima/">More Info</a></div>
              <div class="buy"> <a target="_blank" href="/booking">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="two" style="background-image: url(../img/free-walking-tour-arequipa-3-pm.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Free Tour Arequipa</h3>
              
              <p class="price">Tip Basis</p>
              
              <p class="desc mt-1 mb-3" >Are you planning to visist Arequipa? Be part of the finest free walking tours operated by our Partner</p>
              <div class="add"> <a target="_blank" href="/arequipa/">More Info</a></div>
              <div class="buy"><a target="_blank" href="/booking">Book Know</a></div>
            </div>
            <div class="card mb-5">
              <div class="thumb" id="three" style="background-image: url(../img/cusco-private-tour.jpg);}"></div>
              <div class="option"><i class="material-icons"></i><i class="material-icons"></i><i class="material-icons"></i></div>
              <h3 class="text-center">Private Walks Cusco</h3>
              
              <p class="price">$35.00</p>
              
              <p class="desc mt-1 mb-3">Want a private walk? Then join our premier private walking tours, operated by a Local Indigenous Co</p>
              <div class="add"> <a target="_blank" href="#">More Info</a></div>
              <div class="buy"><a target="_blank" href="#">Book Know</a></div>
            </div>
          </div>

  
     </section>


    <div class="banners mt-5">
       <img src="../img/imgfooter.jpg" alt="">
    </div>
    <?php include('../footer.php');?>




    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
   
<script src="https://code.jquery.com/jquery-2.2.3.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>

<script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>
<script language="javascript">
$(document).ready(function() {
    $().ajaxStart(function() {
        $('#loading').show();
        $('#result').hide();
    }).ajaxStop(function() {
        $('#loading').hide();
        $('#result').fadeIn('slow');
    });
    $('#form, #fat, #fo3').submit(function() {
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function(data) {
                $('#result').html(data);

            }
        })
        
        return false;
    }); 
})  
</script>


<script>
  
 $(document).ready(function(){

    loadGallery(true, 'a.thumbnail');

    //This function disables buttons when needed
    function disableButtons(counter_max, counter_current){
        $('#show-previous-image, #show-next-image').show();
        if(counter_max == counter_current){
            $('#show-next-image').hide();
        } else if (counter_current == 1){
            $('#show-previous-image').hide();
        }
    }

    /**
     *
     * @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
     * @param setClickAttr  Sets the attribute for the click handler.
     */

    function loadGallery(setIDs, setClickAttr){
        var current_image,
            selector,
            counter = 0;

        $('#show-next-image, #show-previous-image').click(function(){
            if($(this).attr('id') == 'show-previous-image'){
                current_image--;
            } else {
                current_image++;
            }

            selector = $('[data-image-id="' + current_image + '"]');
            updateGallery(selector);
        });

        function updateGallery(selector) {
            var $sel = selector;
            current_image = $sel.data('image-id');
            $('#image-gallery-caption').text($sel.data('caption'));
            $('#image-gallery-title').text($sel.data('title'));
            $('#image-gallery-image').attr('src', $sel.data('image'));
            disableButtons(counter, $sel.data('image-id'));
        }

        if(setIDs == true){
            $('[data-image-id]').each(function(){
                counter++;
                $(this).attr('data-image-id',counter);
            });
        }
        $(setClickAttr).on('click',function(){
            updateGallery($(this));
        });
    }
});
</script>

  </body>


</html>
