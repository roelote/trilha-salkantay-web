<?php
if($_POST)
{
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phno = $_POST['phno'];
    $fecha=$_POST['date'];
    $nombretours = $_POST['nombretour'];
    

$from = $_POST['email'];
$subject = 'Reserva Español Miraflores';
$message = 'Nombre: ' . $fname . 
"\n". 'E-mail: ' . $email. 
"\n". 'Tour:' . $nombretours.
"\n". 'Fecha:' . $fecha.  
"\n". 'Nro Pax:' . $lname. 
"\n". 'Mensaje:' . $phno;

$headers = "From: ". $from . "\n";
mail ('info@freewalkingtoursperu.com ', $subject, $message, $headers);


	?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2">Su reserva para el free tour de Miraflores esta CONFIRMADO, solo presentese en lugar correcto.
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">IMPORTANTE: Verifique el punto de encuentro del free tour para ciudad.</span></td>
    </tr>
    </tbody></table>
    <?php
	
}

?>
