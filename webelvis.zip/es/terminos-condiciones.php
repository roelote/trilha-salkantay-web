<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tour Terms & Conditions | Free Tours by foot</title>
    <meta content="Terms & Conditions, cusco lima arequipa tours peru" name="description" />
    <meta content="free walking tour miraflores, free walks, city tours, miraflores walking tour map" name="keywords" />
    <meta content="en" name="language" />
   <meta name="author" content="Free Walking Tours" />

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/responsiveslides.css" rel="stylesheet">
    <link href="css/stylefwt.css" rel="stylesheet">
     <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />
    
  </head>
  <body>
<style>
  /* clearfix */

  .linea-con
  {
    background: rgba(0, 0, 0, 0) url("https://www.inkanmilkyway.com/wp-content/uploads/2016/10/call-bg.png") no-repeat scroll center top;
    font-size: 18px;
    padding-top: 75px;
    text-transform: uppercase;
  }

   .information {
    float: right;
    margin-right: 90px;
    border: 1px solid gray;
    padding: 15px;
    border-radius: 10px;
    }

.information p {
    text-align: center;
}
.information .fa {
    color: teal;
}
.title-con
{
  font-weight: 600;
}
.clearfix {
  clear:both;
}

/* wrapper css */
#wrapper{
  margin-top:70px;
  width:100%;
}
#wrapper hgroup{
  text-align:center;
}
#wrapper h2{
  margin:5px 0;
  color:#FF6D99;
  text-shadow:1px 1px 2px #A50031;
  font-size:33px;
  font-family:Arial Narrow, Arial, sans-serif;
}
#wrapper h3{
  font-style:italic;
  font-weight:normal;
  font-size:18px;
  text-shadow:1px 1px 0 #fff;
  color:#888;
  margin:5px 0;
}

#container{
  position:relative;
  width:1100px;
  margin:0 auto 25px;
  padding-bottom: 10px;
  
}
.grid{
  width:188px;
  min-height:100px;
  padding: 15px;
  background:#fff;
  margin:8px;
  font-size:12px;
  float:left;
  box-shadow: 0 1px 3px rgba(34,25,25,0.4);
  -moz-box-shadow: 0 1px 3px rgba(34,25,25,0.4);
  -webkit-box-shadow: 0 1px 3px rgba(34,25,25,0.4);
  
  -webkit-transition: top 1s ease, left 1s ease;
  -moz-transition: top 1s ease, left 1s ease;
  -o-transition: top 1s ease, left 1s ease;
  -ms-transition: top 1s ease, left 1s ease;
}

.call
{
background: rgba(0, 0, 0, 0) url("https://www.inkanmilkyway.com/wp-content/uploads/2016/10/shadow-01.jpg") no-repeat scroll center bottom;
    margin-bottom: 30px;
    margin-top: 0;
    padding-bottom: 12px;
    right: 100px;
    width: 100%; 
}
.container2
{
 width: 90%;
margin: 0 auto;
}
.container2 li {
    margin: 7px 0px;
}
.grid strong {
  border-bottom:1px solid #ccc;
  margin:10px 0;
  display:block;
  padding:0 0 5px;
  font-size:17px;
}
.grid .meta{
  text-align:right;
  color:#777;
  font-style:italic;
}
.grid .imgholder img{
  max-width:100%;
  background:#ccc;
  display:block;
}

.backd
{
    margin-top: 40px;
    color: #333;
    text-shadow: 1px 1px 1px #fff;
    font-family: 'Freeroad-Regular';
    background: url("img/puntos.png") repeat-x scroll 0 10px;
}
.blank
{
  background-color: #fff;
    color: #333;
    font-weight: 600;
    font-size: 25px;
}
h3 {
    padding: 0 1em;
}
@media screen and (max-width : 1240px) {
  body{
    overflow:auto;
  }
}
@media screen and (max-width : 900px) {
  #backlinks{
    float:none;
    clear:both;
  }

  .information
  {
      margin-right: 0px;
      margin-bottom: 30px;
      width: 100%;
      margin-top: 30px;
  }
  #backlinks a{
    display:inline-block;
    padding-right:20px;
  }
  #wrapper{
    margin-top:90px;
  }
}
@media only screen and (max-width: 700px){
   .container2
  {
    width: auto !important;
  }
  .container2 p
  {
    margin: 1em;
  }
  .grid
  {
    width: 100%;
  }
  #container
  {
    width: 100%;
    padding: 0 10px;
  }
  .imgholder {
    float: left;
    margin: 0 10px;
    width: 200px;
}

.container2
{
  padding: 0 5px 0px 0px;
}


  }
</style>



    <div id="fb-root"></div>
    <div class="container">
      <header class="cabecera">
        <div class="idiomas">
        <span class="en"><a href="/terms-conditions"><img src="img/en.png" alt="spanish"></a></span>
        <span>|</span>
        <span class="es"><a href="/es/terminos-condiciones"><img src="img/es.png" alt="ingles"></a></span>
      </div>
           <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                      <ul class="rslides" id="slider2">
                        <li><img src="img/contact-us.jpg" alt="free walking tours lima"></li>
                      </ul>
                </div>
            </div> 

               <?php include('menu.php');?>
      </header>

    <div class="cuerpo">

    <div class="container2">
      <div class="row">
        <h1 class="backd"><span class="blank px-4">TÉRMINOS & CONDICIONES</span></h1>
        
      </div>
    <div class="container2 mb-5">
 
        <ul>
          <li>Todos los Free Tours en Lima, Arequipa y Cusco son operados independientemente, porque cada ciudad tiene su propio operador, se recomienda a los operadores de acuerdo a la Calidad del Servicio que brindan.</li>
          <li>Siempre podemos hacer la cancelación del tour, sino tenemos suficientes participantes, cuestiones climáticas, protestas o cualquier otra razón.</li>
          <li>FreeWalkingToursPeru.com se reserva el derecho de admisión de cualquier turista a participar en nuestro free walking tour si se considera necesario.</li>
          <li>FreeWalkingToursPeru.com y todo el equipo, no acepta ninguna responsabilidad por cualquier caso infortuito como perdida de sus pertenecías durante el desarrollo del tour.</li>
          <li>Todos nuestros free walking tours a nivel nacional se operan gracias al aporte económico de cada turista como lo es a nivel mundial, se aprecia y valora aportes económicos decentes siempre y cuando que el servicio sea de buena calidad, razón por la cual en ninguna hoja de esta página ofrecemos “Tours Gratis” sino más bien free walking tours, que es un concepto inglés, no lo traduzca.</li>
          <li>Nuestros itinerarios son referenciales y/o flexibles de acuerdo a condiciones climáticas, huelgas, festividades u otros.</li>
          <li>Los Turistas que les gusta escapar de nuestros tours sin dejar ninguna seña de Gratitud, NO están permitidos en participar. </li>

        </ul> 
</div>

     </div>


    <div class="banners">
       <img src="img/imgfooter.jpg" alt="">
    </div>
  <?php include('footer.php');?>


</div>

   
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/blocksit.min.js"></script>
    <script src="js/responsiveslides.min.js"></script>
<script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submit.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>


  </body>


</html>