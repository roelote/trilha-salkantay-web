

<style>
  .form-control
  {
    font-size: 12px;
  }
</style>
<section class="confirmation mt-5">
  <div class="confirmation-text mt-3 mb-3">
 <h3  class="mt-1 mb-0" style="font-size: 1.6em;margin-bottom: 6px !important; text-align: center;"><span class="flag-icon flag-icon-pe"></span>
  ¿Por qué elegirnos? <span class="flag-icon flag-icon-pe"></span></h3>
    <div class="mb-0">
      <ul style="list-style: none;margin-left: 0px !important;padding-left: 10px;">

<li><i class="fas fa-bullhorn"></i> Compañía 100% Peruana.</li>
<li><i class="fas fa-bullhorn"></i> Reservar es GRATIS.</li>
<li><i class="fas fa-bullhorn"></i> Te demoras menos de 1 min.</li>
<li><i class="fas fa-bullhorn"></i> Confirmación Instantánea</li>


      </ul>
    </div>
  </div>
</section>

<div  id="cuadro-reservas">
    <section>
        <hgroup class="boooking">
            <span>¡Reserve Ya!</span>
        </hgroup>

<div id="container">
  <div id="form" class="result">
  <?php
function dameURL(){
$url="http://".$_SERVER['HTTP_HOST'].":".$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];
return $url;
}
$urlweb=dameURL();

$resultado = substr($urlweb, 39);
$nombretour=str_replace("-"," ",$resultado);
$nombretour1=str_replace("/","-",$nombretour);

?>
      <form method="post" id="reg-form">

         <!--            <input type="hidden" name="nombretour" value=<?=$resultado?> />  -->
        
                   <div class="form-group top15 padding10">
                      <input type="text" name="fname" id="lname" placeholder="Nombre" required data-error="Por favor ingrese su nombre"/>
                    </div>
                    <div class="form-group padding10">
                      <input type="email" name="email" id="email" placeholder="Escriba bien su correo" required data-error="Por favor ingrese su correo" />
                    </div>


                       <div class="form-group padding10">
                               
                        <input type="text" id="datepicker" name="date" placeholder="Fecha" />
                      </div>
                  <!--   <div class="form-group padding10">
                      <input type="text" name="lname" id="lname" placeholder="Asunto:" />
                    </div> -->

                    <div class="form-group padding10">
                     <div class="controls">
                            <select class="form-control" id="lname" name="lname">
                            <option value="" disabled selected>Cantidad de Turistas</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                              <option>6</option>
                              <option>7</option>
                              <option>8</option>
                              <option>9</option>
                              <option>10</option>
                            </select>
                           </div>
              </div>

                     <div class="form-group padding10">
                      <select class="form-control" name="nombretour" id="nombretour" >
                         <option value="" disabled selected>Elija el Horario del Free Tour</option>
                          <option value="cusco-10am">Free Tour Cusco Centro 10am </option>
                          <option value="cusco-1pm">Free Tour Cusco Centro 1pm </option>
                          <option value="cusco-3-30pm">Free Tour Cusco Centro 3:30pm </option>
                          <option value="cusco-10am-domingo">Free Tour Cusco Centro Domingo 10am </option>
                      </select>
                    </div>
                    

                      

                      <div class="form-group padding10">
                        <textarea class="form-control" name="phno" rows="3" placeholder="IMPORTANTE para CUSCO: Todos los domingos solo tenemos UN solo free tour a las 10AM." id="comment" ></textarea>
                      </div> 

                    <div class="centrarsend"><button type="submit">Enviar</button></div>
        </form>
    </div>
</div>
        



<style type="text/css">

.confirmation-text {
    /*border: 1px solid;*/
    margin: 0 auto;
padding: 7px;

width: 95%;

color: #131515;

border-radius: 4px;

font-size: 13px;

background-color: #dedede;
}
.centrarsend button
{
  background-color: #fc0;
  color: #2f2d2d;
  border: 1px solid #a59898;
  font-weight: initial;
}

#cuadro-reservas
{
  margin-top: 5% !important;
}


input
{
  width:100%;
  height:35px;
  text-align:center;
  border:solid #cddcdc 2px;
  font-family:Verdana, Geneva, sans-serif;
  border-radius:3px;
}
button
{
  text-align:center;
  width:50%;
  height:35px;
  border:0;
  font-family:Verdana, Geneva, sans-serif;
  border-radius:3px;
  background:#00a2d1;
  color:#fff;
  font-weight:bolder;
  font-size:18px;
}
hr
{
  border:solid #cecece 1px;
}
#header
{
  width:100%;
  height:50px;
  background:#00a2d1;
  text-align:center;
}
#header label
{
  font-family:Verdana, Geneva, sans-serif;
  font-size:35px;
  color:#f9f9f9;
}
.form-control
{
  color:#4e4e4e;
}
a{
  color:#00a2d1;
  text-decoration:none;
}
</style>

  
</section>
</div>