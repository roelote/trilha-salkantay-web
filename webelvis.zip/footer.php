<footer>
	
	<div class="pies">
		
                 <div class="tours-footer-text">
							  <div class="centered centrar col-sm-12 col-md-12">
							    <a href="/partners">Friends</a> |<a target="_blank" href="http://www.inkanmilkyway.com/">Free Tour Partner Perú</a> | <a target="_blank" href="/terms-conditions">Terms & Conditions</a> | <a href="/contact-us">Contact Us</a>
							</div>
							<br>
							<div class="mb-4 limapie col-sm-4 col-md-4">
							<p><b>Free Walking Tour Lima</b></p>
							<p>Address: <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.122698,-77.0328307,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.122698!4d-77.030642">Calle Schell,<br>
							by Oechsle Mall, Miraflores 15074</a></p>
							<p>Opens: 9:50AM–8:30PM</p>
							<p>Telf: +51 958745640 - Elvis</p>
							<p>Telf: +51 984479073 - Richard</p>
							</div>

							<div class="mb-4 arequipapie col-sm-4 col-md-4">
							<p><b>Free Walking Tour Arequipa</b></p>
							<p>Address: <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5388673,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786">Calle Santa Catalina,<br>
							in Chaqchao Choco Museo Arequipa</a></p>
							<p>Opens: 9:50AM–8:30PM</p>
							<p>Telf: +51 958745640 - Elvis</p>
							<p>Telf: +51 984479073 - Richard</p>
							</div>
							
							<div class="mb-4 cuscopie col-sm-4 col-md-4">
							<p><b>Free Walking Tour Cusco</b></p>
							<p>Address: <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Cusco,+Free+Walking+Tour/@-13.5171428,-71.9823017,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x49be8bcaa264818d!8m2!3d-13.5171428!4d-71.980113">Regocijo, Plazoleta<br>
							in front of Choco Museo, Cusco 08000</a></p>
							<p>Opens: 9:50AM–8:30PM</p>
							<p>Telf: +51 958745640 - Elvis</p>
							<p>Telf: +51 984479073 - Richard</p>
							</div>
                   </div>

	</div>
</footer>