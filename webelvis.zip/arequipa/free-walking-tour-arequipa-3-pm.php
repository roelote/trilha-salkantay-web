<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Arequipa Tours by foot | Arequipa Day Tours | FREE Walking Tour Afternoon</title>
    <meta content="Not sure what to do in Arequipa? Decide wisely, then melt into this startling & eye-opening city on Arequipa Tours by Foot, our Day Tours or Free Walking Tour Arequipa are performed by graduated & licensed tour guides from prestigious universities, experts on history and culture of this ancient Andean city." name="description" />
    <meta content="Arequipa Tours, Arequipa Day Tours, Free Tour Arequipa, Free walking tour Arequipa, free tour downtown Arequipa " name="keywords" />
    <meta content="en" name="language" />

   <!-- Bootstrap -->
     <link rel="icon" type="image/ico" href="../img/favicon.ico" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link href="../css/responsiveslides.css" rel="stylesheet">
    <link href="../css/stylefwt.css" rel="stylesheet">

 <!--   estilos slider pekeño -->
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <link href="../css/owl.theme.css" rel="stylesheet">
         <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

    <link href="../css/easy-responsive-tabs.css" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" crossorigin="anonymous">
 <link href="../css/flag-icon.min.css" rel="stylesheet">
                <!-- favicons -->
        <link rel="apple-touch-icon" sizes="57x57" href="../favicons/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../favicons/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../favicons/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../favicons/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../favicons/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../favicons/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../favicons/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../favicons/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../favicons/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="../favicons/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="../favicons/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../favicons/favicon-16x16.png">
        <link rel="manifest" href="../favicons/manifest.json">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content="../favicons/ms-icon-144x144.png">
        <meta name="theme-color" content="#ffffff">
          <!-- end favicons -->
          <!-- open graph -->
                          <meta property="og:type" content="website">
                          <meta property="og:title" content="Arequipa Tours by foot | Arequipa Day Tours | FREE Walking Tour Afternoon">
                          <meta property="og:description" content="Not sure what to do in Arequipa? Decide wisely, then melt into this startling & eye-opening city on Arequipa Tours by Foot, our Day Tours or Free Walking Tour Arequipa are performed by graduated & licensed tour guides from prestigious universities, experts on history and culture of this ancient Andean city">
                          <meta property="og:url" content="https://www.freewalkingtoursperu.com/arequipa/free-walking-tour-arequipa-3-pm">
                          <meta property="og:image" content="https://www.freewalkingtoursperu.com/img/free-walks-arequipa-2.jpg">
                          <meta property="fb:app_id" content="FreeTourDowntownArequipa">
                              <!-- twitter -->
          <!-- end open graph -->

<script type="application/ld+json">
      {
        "@context": "http://schema.org/",
        "@type": "Review",
        "itemReviewed": {
          "@type": "Thing",
          "name": "Free Tour Arequipa 3pm"
        },
        "author": {
          "@type": "Organization",
          "name": "Arequipa"
        },
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": "4.6",
          "bestRating": "5"
        },
        "publisher": {
          "@type": "Organization",
          "name": "Free Walking Tours Peru"
        }
      }
      
    </script>


  </head>
  <body>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79425114-2', 'auto');
  ga('send', 'pageview');
</script>
    <div id="fb-root"></div>

    <div class="container px-0">
      <header class="cabecera">
         <?php include('../menu.php');?>

      <section class="slidera">
        <div class="container-fluid px-0" style="float: left; position: relative;">
        <div class="row mb-0">

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
        <div class="item active">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-walking-tour-peru-xs.jpg">
        <img src="../img/lima-walking-tour-peru.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        <div class="item">
        <picture>
        <source media="(max-width: 550px)" srcset="../img/xs/lima-walking-tour-xs.png">
        <img src="../img/lima-walking-tour.jpg" class="w-100" alt="free walking tour lima">
        </picture>
        </div>
        </div>
        
       
        </div>
        </div>
         <div class="base"></div>
        </div>
         
        </section>
           
      </header>

 
    <div class="cuerpo">

      <section class="container izquierda">


        <section class="cuadro-texto cuadro-contenedor">

          <h1>Free Arequipa Tours by Foot at 3pm | Arequipa Day Tours</h1>

          
          <div class="wecolmetour">
            
         <p>Welcome to Arequipa Tours on foot in the Afternoon!!! Let´s make the best of your Arequipa Day Tours by free walking in a city that has produced many of the country’s leading political and cultural figures such as Mario Vargas Llosa (Novelist, novel prize winner, 2010), Mariano Melgar (Musician & Poet) or Pedro Paulet (Scientist) and more | This city has diversified industries and is a major processing centre for alpaca, llama, and sheep’s wool | It is the commercial, political, and military centre of southern Peru, easy to access by air, rail, and highway and the last 20 years became a popular tourist centre because of “Juanita” Mummy  , Santa Catalina convent, Colqa Canyon, Culinary and the great infrastructure for this industry like Hotels, Bars, Restaurants, Highways and more | Let´s enjoy this delightful & marvelous city in our Day Tours on foot: Free Walking Tour Arequipa.</p> 

         <p><b>NOTE:</b> All our free tours in Arequipa (<a href="free-walking-tour-arequipa-10-am">10am</a> & <a href="free-walking-tour-arequipa-3-pm">3pm</a> – Monday to Sundays) are the same or similar, so you can only take one free tour.</p>

          <h2 class="text-center">BEFORE JOINING OUR FREE TOUR YOU SHOULD KNOW:</h2>

<p><strong>Free Tour Meet up Time</strong>: 3pm from Monday to Sunday</p>
<p><strong>Meeting Place</strong>:&nbsp;<a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5388673,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786">Santa Catalina Street 204</a>&nbsp;inside The Chaqchao Choco Museo.</p>
<p><strong>How to find our Meeting Place?&nbsp;</strong>We are just one block behind the Cathedral.</p>
<p><strong>Walking Tour Length</strong>: 2.5 to 3 hours.</p>
<p><strong>Our Happy Official Tour Guide wears</strong>: &nbsp;Nothing, Just show up at the correct meeting point &ndash; NO Uniform</p>
<p><strong>To bring</strong>: Warm Cloth, Hats, sunglasses, walking shoes and a jumper.</p>
<p><strong>Price:</strong>&nbsp;FREE &ndash; Donation basis.</p>
<p><strong>Language</strong>: Groups in English &amp; Spanish, you choose your language | Si hablas espa&ntilde;ol debes de venir al free tour de las 10am &amp; 3pm(Lunes a S&aacute;bado), Los Free Tours cada Domingo es solamente en Ingles.</p>

<div class="btn-reserva">
  

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51958745640&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 958745640</button></a>

<a href="#titlea-side"><button type="button" class="btn btnreserva active">Book Now</button></a>

<a class="whatsapp-movil" href="whatsapp://send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>
<a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=+51984479073&text=Hello%20can%20you%20help%20me?"><button type="button" class="btn whatsap active"><i class="fab fa-whatsapp"></i> +51 984479073</button></a>

</div>


<p><span style="color: #ff0000;">To Consider:</span>&nbsp;You might get confused with other people, pls show up at the correct meeting point &amp; Our free tours in Cusco are operated by Inkan Milky Way Tours Cusco, a 100% Indigenous Peruvian Co,&nbsp;<a href="https://www.facebook.com/freewalkingtourscusco/">follow us here.</a></p>


         

          </div>
           <div class="slidertours">
              <div id="demo">
                <div class="container">
                  <div class="row">
                    <div class="span12">

                      <div id="owl-demo" class="owl-carousel">
                        <div class="item"><img src="../img/free-walks-arequipa-1.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walks-arequipa-2.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walks-arequipa-3.jpg" alt="Owl Image"></div>
                        <div class="item"><img src="../img/free-walks-arequipa-1.jpg" alt="Owl Image"></div>

                      </div>
                      
                    </div>
                  </div>
                </div>
               </div>
       </div>

         <div id="verticalTab">
                <ul class="resp-tabs-list">
                <li> <span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> ITINERARY</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> INCLUSIONS</li>
                <li><span class="glyphicon glyphicon-hand-right" aria-hidden="true"> </span> REMARKS & FAQ’S</li>
                </ul>
                <div class="resp-tabs-container">
                    <div>
                        <h2 class="h2-tours-detalle"> Spots we are going to visit:  </h2> 

                       <p class="texto-ciudades">Below itinerary is changeable because of many reasons: festivals, strikes, holydays, car traffics, rainy season, etc. if you are a Blogger, Top rated TripAdvisor Criticizer, Lonely Planet Agent or just a highly demanding customer, then we ask you kindly to check our policies to avoid misunderstandings; Nonetheless we will do our best so that you can have a great experience with us.</p>

                      <ul style="list-style-type: none" class="bi-ciudades">
                
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> Join us at <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5388673,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786">Santa Catalina Street #204</a> at 3pm in the Chocolate factory, just one block behind the Plaza de Armas. <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5388673,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786">See our Google Maps</a> for our Free Tours by Foot powered by Free Tour Downtown Arequipa.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> You will have a chance to taste some chocolates and also learn the benefits of enjoying this exotic fruit seeds native to the American Continent, brought to Europe by the Spaniards.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> After this we will head to Plaza de Armas to see the Cathedral, the main catholic building dating back to the 17th century, the Water Fountain (once the main source of water for citizens from the colonial times, also a source of water for horses, alpacas, llamas and more) and The Jesuit Cloister of the Company of Jesus. </li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> Get to visit also the “San Lazaro” Neighborhood with very narrow walkways dating back to Colonial Period.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> At this tour we will take you to the San Camilo Market designed by Alexander Eiffel, the same man who has designed the Eiffel tower in Paris, France.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> Since we are on the Andes we have arranged this walking tour to see the Alpaca Zoo, where you we will show you how to differ Alpaca from Llama? Or how to tell original alpaca wool? Keep mind you are not obligated to buy nothing.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> All our morning walking tours not just all places mentioned above but lots of answers to your questions, travel emotions, stereotypes and traditional local standard urban plans.</li>
<li><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span> We will finish this tour by having some Pisco Sours.</li>
            </ul>
                    </div>

                    <div>
                      <div class="imagesit">
                        <img src="../img/ico-arequipa-3pm/misti-volcano-free-walks-arequipa.png" alt="misti-volcano-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/acomodation-tips-free-walks-free-walks-arequipa.png" alt="acomodation-tips-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/alpaca-watching-free-walks-free-walks-arequipa.png" alt="alpaca-watching-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/best-picture-free-walks-free-walks-arequipa.png" alt="best-picture-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/catholicism-free-walks-free-walks-arequipa.png" alt="catholicism-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/chocolate-tastings-free-walks-free-walks-arequipa.png" alt="chocolate-tastings-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/geo-orientation-free-walks-free-walks-arequipa.png" alt="geo-orientation-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/gothic-free-walks-free-walks-arequipa.png" alt="gothic-free-walks-free-walks-arequipa">
                       
                        <img src="../img/ico-arequipa-3pm/history-free-walks-free-walks-arequipa.png" alt="history-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/inquires-free-walks-free-walks-arequipa.png" alt="inquires-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/lisenced-company-free-walks-free-walks-arequipa.png" alt="lisenced-company-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/llamas-free-walks-free-walks-arequipa.png" alt="llamas-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/monastery-santa-catalina-free-walks-arequipa.png" alt="monastery-santa-catalina-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/panoramic-views-free-walks-free-walks-arequipa.png" alt="panoramic-views-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/pisco-sours-free-walks-free-walks-arequipa.png" alt="pisco-sours-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/profesional-guides-free-walks-free-walks-arequipa.png" alt="profesional-guides-free-walks-free-walks-arequipa">
                        <img src="../img/ico-arequipa-3pm/travel-tips-free-walks-free-walks-arequipa.png" alt="travel-tips-free-walks-free-walks-arequipa">
                          

                      </div>
                    </div>

                    <div>
                    <ul style="list-style-type: none">
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Where is our Meeting Point in Arequipa?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">At Santa Catalina Street #204 at the Chocolate factory, just one block behind the Cathedral from the Plaza de Armas. Please use our <a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.3967192,-71.5366786,15z/data=!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786">Google Map</a for Arequipa City.
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>How to recognize our Tour Guides at the Meeting Point in Arequipa?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">Just show up at the Correct Meeting Point, Calle Santa Catalina 204, (Choco Factory) there is no other free tour company here, so you will not get confused.
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Where does the free tour end upin Arequipa?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">All our free tours end up near downtown Arequipa, just 5 minutes away from the Plaza de Armas.
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>What’s an appropriate amount of tip for our free tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">This is our Philosophy for our Free Tour: <span style="color: #008080;">Pay what you think the tour was worth&iexcl;</span>, our free tours are from good to great quality, in simple terms, they are decent tours and a decent tour should be rewarded Generously, <span style="color: #ff0000;">Not with coins such as 2 soles or 5 soles.</span><br>
LLet us mean ourselves clear: <span style="color: #008080;">Pay What It's Worth is Not Pay what you can or what you like&rdquo;</span>. In New York, some free tour companies have the philosophy of &ldquo;Pay what you like&rdquo;, and this really good because New Yorkers are big Tippers however we are in South America where many people don&rsquo;t even have the Tipping culture <br>
Apart from this consider that your tour guide relies entirely on your tips, since no one of them are funded by NGO´s or the government. Tips are also shared among the whole team.
Most tourists tip between twenty soles to thirty soles, this is subject to change according to the quality of the tour.<br>
Thanks</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Things to be brought:(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">
  - Sun Block Lotions.<br>
- Sun Glasses.<br>
- Hats.<br>
- Bottles of Water.<br>
- Walking Shoes.<br>
- BIG SMILE and WILLINGNESS TO WALK.
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Available Languages in Arequipa:(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">English and Spanish, for both languages we need a considerable amount of tourists, so that we can make a unilingual guided group, otherwise will be in English only. Al 90% tenemos guiados en español en ambos tours a las 10am y 3pm, siempre puede venir a hacer su free tour en español – Recuerde esto es para Arequipa, puede variar en otras ciudades.<br>
<span style="color: #ff0000;">Nota:</span>En Arequipa los domingos los guiados free tour  son solamente en Ingles.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>When is this happening?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">At 10am & 3pm From Monday to Sunday, 7 days of the week.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Do the free tours in Arequipa (10am & 3pm) have different itinerary?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">No, our 10am & 3pm free tour in Arequipa have the same itinerary, so you can only take one.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Can we leave the free tour because we have other scheduled tours?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">You can always leave our free tour, if you have other tours or activities, however Don’t forget to tip your tour guide, Don’t escape, Don’t run away, Don’t walk away, Don’t ignore your tour guide, Don’t pretend that you don’t know our walks are tip based, Don’t pretend that you forgot to bring some tip.<br>
Thanks</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>What is the duration of our Free Tours in Arequipat?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">All our Arequipa Walking Tours last about 2.5 to 3 hours, approximately 1.6 km – 1 mi. in distance, therefore we kindly ask our tourists to HAVE that AVAIABLE TIME.</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Minimum walkers required to run the tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">05 tourists, otherwise will be cancelled, for more info go to: <a href="https://www.freewalkingtoursperu.com/terms-conditions">our policies.</a> </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Maximum walkers allowed per group?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">20 tourists either for English or Spanish, for more info go to: <a href="https://www.freewalkingtoursperu.com/terms-conditions">our policies.</a> From time to time we have large groups and one tour guide to manage the whole group, please don’t blame on your guide or the team, simply because most attendees don’t book in advance so cannot take a decision beforehand. </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We are a group of 11 or more. Can we make a reservation online?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">Groups or Families of 11 or more are more than welcome to <a href="https://www.freewalkingtoursperu.com/contact-us">contact us</a> before reserving and according to our available tour guides and available spot in our free tour whether we will accept or reject your participation in our free tours. From experience we know that large groups have the tendency to NOT pay attention to the Tour Guide´s explanation which is so disrespectful for both the guide and other attendees.<br>

However if you happen to forget to book your large group, you can always show up at the meeting point, we will take care of you, just don’t expect the best of the best, remember it is free tour, if you want the best from the best look for a private tour. </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We are a group of 11 or more. Can we have a private free tour?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">NO, our free tour service is a group service, you will join other attendees.<br>
Even if you are 20 people, we still say no, because from experience we know that big groups of friends or mates Do Not pay attention to our Tour Guide’s explanation.<br>
Because of this reason, we advise you to take a Private tour (pre-paid) however if you want to take our free tour, you must <a href="https://www.freewalkingtoursperu.com/contact-us">contact us</a> in advance so that you can join our GROUP service (Not private).</p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>Can our free tours ever get cancelled because of weather, protests or festivities in Arequipa?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">
- When it comes to Protests we might cancel our free tour, this can happen without a previous notification, so we ask for your understanding in advance.<br>
- If there are Festivities, we might cancel also.<br>
- If rain, the show goes on unless it is too rainy.<br>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We use crutches, can we participate in your free tours?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">Yes, you can as long as you are capable to walk and stand on your feet for some minutes while your guide explains about some historical spots. </p></li>
<li><p class="qquest"><span class="glyphicon  glyphicon glyphicon-ok" aria-hidden="true"></span>We use wheelchair, can we participate in your free tours?(<a href="#" class="alternar-respuesta">View</a>)</p>
<p class="respuesta" style="display:none">Unfortunately the answer is NO, because most streets in Peru are not yet designed for Wheelchair users, this issue is out from our hands to solve. We kindly encourage you to take a private tour instead, make sure you have a person that can help you. </p></li>

 
                    <a href="#" class="alternar-todo"id="alternar-todo">Show and hide all answers</a>

                    </ul>
                    </div>
                </div>
            </div>



         </section>

      </section>

      <aside class="derecha">
        <div class="redes-movil mt-3 visible-xs">
        <section class="redes-s" style="width: 100%;font-size: 12px; border-radius: 5px;">
  <div class="row text-center mt-2 mb-3">
  <span class="tex-center">
  <h4 id="titlea-side">Make a wise decision in Arequipa, see our awesome 581+ reviews at:</h4>

   <a href="https://web.facebook.com/arequipafreewalkingtour/"><i class="fab fa-facebook"></i></a>
   <i class="fab fa-youtube-square"></i>
   <img src="/img/trip-advisor.jpg" class="mt-1" alt="" width="38" height="35">
   <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.396719,-71.536679,16z/data=!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786?hl=es-ES"><img src="/img/google-b.png" alt="" style="" width="40" height="38"></a>
   <a href="https://plus.google.com/u/0/b/116581257145326937453/116581257145326937453"><i class="fab fa-google-plus-square"></i></a>
</span>
  </div>
</section>
        </div>
       <?php include('../cuadro-reservas-arequipa.php');?>

       <div class="blogpage hidden-xs">

</div>
        <div class="mapadetalle">
        <h2 class="hidden-xs"> <span class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span>Click The Map to See</h2>
        <div class="centrarmapa mb-5"><img id="myImg" src="../img/arequipa-free-tours-en.png" alt="Free Walking Tour Arequipa 3:00 pm" width="300" height="200"></div>

        <!-- The Modal -->
        <div id="myModal" class="modal">
          <span class="close">×</span>
          <img class="modal-content" id="img01" alt="mapa ubicacion">
          <div id="caption"></div>
        </div>
        </div>

      </aside>
      
    <section class="redes-s hidden-xs" style="float: left;
width: 100%;
border: 2px solid #c8cbc4;
background-color: #ede58a;font-size: 1.7em;">
  <div class="row text-center mt-2 mb-3">
  <span class="tex-center">
  Make a wise decision in Arequipa, see our awesome 581+ reviews at:

   <a href="https://web.facebook.com/arequipafreewalkingtour/"><i class="fab fa-facebook"></i></a>
   <i class="fab fa-youtube-square"></i>
   <img src="/img/trip-advisor.jpg" class="mt-1" alt="" width="38" height="35">
   <a href="https://www.google.com/maps/place/Inkan+Milky+Way+Arequipa,+Free+Walking+Tour/@-16.396719,-71.536679,16z/data=!4m5!3m4!1s0x0:0xfd3216dc3b492aee!8m2!3d-16.3967192!4d-71.5366786?hl=es-ES"><img src="/img/google-b.png" alt="" style="" width="40" height="38"></a>
   <a href="https://plus.google.com/u/0/b/116581257145326937453/116581257145326937453"><i class="fab fa-google-plus-square"></i></a>
</span>
  </div>
</section>

     <div class="maps-c mb-5">
      <h3 class="text-center mt-1" style="float: left;width: 100%;font-size: 1.6em;">Meeting Point Map for our Arequipa Free Tours - Google maps</h3>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15310.211872184705!2d-71.5366786!3d-16.3967192!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xfd3216dc3b492aee!2sInkan+Milky+Way+Arequipa%2C+Free+Walking+Tour!5e0!3m2!1ses!2spe!4v1522846940688" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
     </div>
     <div class="carousel-reviews broun-block hidden-xs">
   <h3 class="text-center mt-3" style="float: left;width: 100%;font-size: 1.6em;">What our customers are saying about us¡</h3>     
    <div class="container">
        <div class="">
            <div id="carousel-reviews1" class="carousel slide" data-ride="carousel"  data-interval="5000">
            
                <div class="carousel-inner">
                    <div class="item active">
                            <div class="col-md-4 col-sm-6">
                                  <div class="block-text rel zmin">
                                  <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Muy recomendable</a>
                                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                                  <p>Creo que es la mejor forma de conocer la Arequipa. El tour duro unas 2.5 horas, la ruta resultó ser muy interesante y explicada con bastante detalle no se paro ni en bares ni en comercios lo cual agradezco. El mismo guia explicaba en ingles y en español lo cual ralentizo el ritmo del tour. El guia me resulto ser poco empatico hablaba muy rapido con una explicacion que se veía que tenia muy interiorizada y automatizada. No visitamos la fabrica de alpaca que si creia que normalmente se hace en este tour. Salió a las 10.</p>
                                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                </div>
                            <div class="person-text rel">
                               <img alt="" src="/img/reviews/review-arequipa4.jpg" width="80"> 

                              <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Miguel N</a>
                          <!--     <i>from Glasgow, Scotland</i> -->
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 hidden-xs">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Great way to see and understand the city</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>For ( in our case) a Sole 60 tip from two people for a 3 hour + guided walk around this lovely city we thought it was really good value. The guide is passionate, enthusiastic, and knowledgable about his city. It’s a reasonable walk so take water and wear a hat/sun protection. He asks interesting questions. Excellent command of English.</p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="/img/reviews/review-arequipa.jpg" width="80">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Kettering</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>

                  <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Informative, funny and useful</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>We booked the trip on the 30th of December in the afternoon and experienced a great rain! The guide was very knowledgeable about the history of the city and knew specific details. He took us to special places like factories of alpaca wool, library devoted to Vargas. However, he asked us kind of provocative questions about yourself and living the life and made - in my opinion - some inappropriate comments, but that did not take away the spirit of the tour.</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-f/03/90/f6/e7/facebook-avatar.jpg" width="80">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">NataVor</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>

          </div>

                    <div class="item ">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Great intro to the City</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Tour is not really free since guides depend on tips. Whatever you can afford will be worth every penny or cent. Our guide Johan was super friendly, knowledgeable and passionate in every sense of Perú and Arequipa. We’ve ended up walking and talking for almost 3.5 hours. Didn’t even know time went by so fast. Some free drink samples and tips about Peruvian custom, food and traditions. Highly recommend and in my opinion it is a must when visiting this great City.</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                  <img alt="" src="/img/reviews/review-arequipa2.jpg" width="80">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Maciej K</a>
              <!--   <i>from Glasgow, Scotland</i> -->
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Una experiencia 100%recomendable</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>Hicimos el tour a las 3 de la tarde, en el grupo de español y comenzamos con una degustación de te de chocolate, mas tarde salimos a la ciudad que es preciosa. Nuestro guía fue Edgar, al cual felicito porque no paró de contar anecdotas, de esperar para que pudieramos hacer fotos, en fin, de mostrar de una forma divertida arequipa y su cultura, incluso nos invito a Pisco!   </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-arequipa1.jpg" width="80">
                    <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Andrés L</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Buen Tour para ver sitios que no verías por cuenta propia</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>It was a great Tour! Our guide was very friedly, gave us a lot of interesting information and aswered all of our questions. We liked the most that he went to the market with us and explained something about the different fruits for example. My two friends and i totally recommand!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-s/01/2a/fd/a0/avatar.jpg" width="80">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">fenanCR</a>
              </div>
            </div>
                    </div>

                    <div class="item">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.facebook.com/pg/freewalkingtourscusco/reviews/?ref=page_internal">Interesante</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>Un tour interesante para conocer la historia de Arequipa!! El guía nos explicó la historia de esta ciudad tan rica culturalmente!! También vimos sitios muy bonitos y interesantes y lo imprescindible de Arequipa. Se visita la fábrica donde tejen con Lana de alpaca y vicuña y el tour empieza y acaba en una cafetería súper bonita donde puedes degustar buen chocolate!! Y tengo que decir que estas visitas no son con afán de que compres como pasa en otras ocasiones. Para mí imprescindible y totalmente recomendable!!</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-s/01/2a/fd/93/avatar.jpg" width="80">
                <a title="" href="https://www.facebook.com/pg/freewalkingtourscusco/reviews/?ref=page_internal">Marta R</a>
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="#">Excellent!</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Once again TripAdvisor community, you have not let me down! This was an excellent walking tour! The guide, Johan, is everything that a good guide should be: knowledgeable, passionate and entertaining! The tour actually lasted 3.5 hours and it just flew by. It was so interesting! We had a quick lunch stop which was perfectly timed. Johan makes a ton of recommendations that cater to every type of traveler.  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/10/da/12/70/noemie-s.jpg" width="80">
                    <a title="" href="#">Noemie S</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Excellent Tour</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>This was one of the most interesting walking tours in Peru. It covered not only the history of Arequipa and Peru but also included topics like food, literature and the various cultural influences all over the city. The guide was extremely knowledgeable and engaging. Our group was massive but the guide managed to keep everyone involved and interested. </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-arequipa3.jpg" width="90">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">RaeLynn P</a>
              </div>
            </div>
                    </div>
         
                                    
                </div>
                <a class="left carousel-control" href="#carousel-reviews1" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-reviews1" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </div>
    </div>

</div>


<div class="carousel-reviews broun-block hidden-sm hidden-md hidden-lg">

<h3 class="text-center mt-1 hidden-xs " style="float: left;width: 100%;font-size: 1.6em;">What our customers are saying about us¡</h3>
    <div class="container">
        <div class="">
            <div id="carousel-reviews" class="carousel slide" data-ride="carousel"  data-interval="5000">
            
                <div class="carousel-inner">
                    <div class="item active">
                            <div class="col-md-4 col-sm-6">
                                  <div class="block-text rel zmin">
                                 <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Muy recomendable</a>
                                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                                  <p>Creo que es la mejor forma de conocer la Arequipa. El tour duro unas 2.5 horas, la ruta resultó ser muy interesante y explicada con bastante detalle no se paro ni en bares ni en comercios lo cual agradezco. El mismo guia explicaba en ingles y en español lo cual ralentizo el ritmo del tour. El guia me resulto ser poco empatico hablaba muy rapido con una explicacion que se veía que tenia muy interiorizada y automatizada. No visitamos la fabrica de alpaca que si creia que normalmente se hace en este tour. Salió a las 10.</p>
                                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                </div>
                            <div class="person-text rel">
                               <img alt="" src="/img/reviews/review-arequipa4.jpg" width="80">  

                              <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Miguel N</a>
                          <!--     <i>from Glasgow, Scotland</i> -->
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 hidden-xs">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Great way to see and understand the city</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>For ( in our case) a Sole 60 tip from two people for a 3 hour + guided walk around this lovely city we thought it was really good value. The guide is passionate, enthusiastic, and knowledgable about his city. It’s a reasonable walk so take water and wear a hat/sun protection. He asks interesting questions. Excellent command of English.</p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="/img/reviews/review-arequipa.jpg" width="80">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Clara Lam</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>

                  <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Informative, funny and useful</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>We booked the trip on the 30th of December in the afternoon and experienced a great rain! The guide was very knowledgeable about the history of the city and knew specific details. He took us to special places like factories of alpaca wool, library devoted to Vargas. However, he asked us kind of provocative questions about yourself and living the life and made - in my opinion - some inappropriate comments, but that did not take away the spirit of the tour.</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-f/03/90/f6/e7/facebook-avatar.jpg" width="80">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">NataVor</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>

          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                      <div class="block-text rel zmin">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Great way to see and understand the city</a>
                        <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                          <p>For ( in our case) a Sole 60 tip from two people for a 3 hour + guided walk around this lovely city we thought it was really good value. The guide is passionate, enthusiastic, and knowledgable about his city. It’s a reasonable walk so take water and wear a hat/sun protection. He asks interesting questions. Excellent command of English.  </p>
                            <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                          </div>
                    <div class="person-text rel">
                             <img alt="" src="/img/reviews/review-arequipa.jpg" width="80">
                          <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Kettering</a>
            <!--           <i>United States</i> -->
                    </div>
                  </div>
          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                    <div class="block-text rel zmin">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Informative, funny and useful</a>
                      <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                        <p>We booked the trip on the 30th of December in the afternoon and experienced a great rain! The guide was very knowledgeable about the history of the city and knew specific details. He took us to special places like factories of alpaca wool, library devoted to Vargas. However, he asked us kind of provocative questions about yourself and living the life and made - in my opinion - some inappropriate comments, but that did not take away the spirit of the tour.</p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
                    <div class="person-text rel">
                      <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-f/03/90/f6/e7/facebook-avatar.jpg" width="80">
                      <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">NataVor</a>
                    <!--   <i>Indonesia</i> -->
                    </div>
                  </div>
          </div>



                    <div class="item ">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Great intro to the City</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Tour is not really free since guides depend on tips. Whatever you can afford will be worth every penny or cent. Our guide Johan was super friendly, knowledgeable and passionate in every sense of Perú and Arequipa. We’ve ended up walking and talking for almost 3.5 hours. Didn’t even know time went by so fast. Some free drink samples and tips about Peruvian custom, food and traditions. Highly recommend and in my opinion it is a must when visiting this great City.</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                  <img alt="" src="/img/reviews/review-arequipa2.jpg" width="80">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Maciej K</a>
              <!--   <i>from Glasgow, Scotland</i> -->
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Una experiencia 100%recomendable</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>Hicimos el tour a las 3 de la tarde, en el grupo de español y comenzamos con una degustación de te de chocolate, mas tarde salimos a la ciudad que es preciosa. Nuestro guía fue Edgar, al cual felicito porque no paró de contar anecdotas, de esperar para que pudieramos hacer fotos, en fin, de mostrar de una forma divertida arequipa y su cultura, incluso nos invito a Pisco!   </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-arequipa1.jpg" width="80">
                    <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Andrés L</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Buen Tour para ver sitios que no verías por cuenta propia</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>It was a great Tour! Our guide was very friedly, gave us a lot of interesting information and aswered all of our questions. We liked the most that he went to the market with us and explained something about the different fruits for example. My two friends and i totally recommand!</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-s/01/2a/fd/a0/avatar.jpg" width="80">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">fenanCR</a>
              </div>
            </div>
                    </div>


          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                <div class="block-text rel zmin">
                    <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Una experiencia 100%recomendable</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>Hicimos el tour a las 3 de la tarde, en el grupo de español y comenzamos con una degustación de te de chocolate, mas tarde salimos a la ciudad que es preciosa. Nuestro guía fue Edgar, al cual felicito porque no paró de contar anecdotas, de esperar para que pudieramos hacer fotos, en fin, de mostrar de una forma divertida arequipa y su cultura, incluso nos invito a Pisco!   </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-arequipa1.jpg" width="80">
                    <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Andrés L</a>
              </div>
            </div>
          </div>


          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
              <div class="block-text rel zmin">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Buen Tour para ver sitios que no verías por cuenta propia</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>Resultó muy interesante las historias del guía así como el recorrido, por ejemplo la fábrica de ropa de alpaca creo que es algo que no hubieramos visto si hubiéramos ido por libre. duró unas 3 horas. el guía controlaba de historia e hizo amena la visita, siempre dispuesto a contestar las preguntas, aunque algún chiste que hizo no tenía mucha gracia pero al menos lo intentaba</p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-s/01/2a/fd/a0/avatar.jpg" width="80">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-or10-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">fenanCR</a>
              </div>
            </div>
          </div>
                    <div class="item">
                        <div class="col-md-4 col-sm-6">
                    <div class="block-text rel zmin">
                    <a title="" href="https://www.facebook.com/pg/freewalkingtourscusco/reviews/?ref=page_internal">Interesante</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star-empty"></span>  </span></div>
                    <p>Un tour interesante para conocer la historia de Arequipa!! El guía nos explicó la historia de esta ciudad tan rica culturalmente!! También vimos sitios muy bonitos y interesantes y lo imprescindible de Arequipa. Se visita la fábrica donde tejen con Lana de alpaca y vicuña y el tour empieza y acaba en una cafetería súper bonita donde puedes degustar buen chocolate!! Y tengo que decir que estas visitas no son con afán de que compres como pasa en otras ocasiones. Para mí imprescindible y totalmente recomendable!!</p>
                  <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                  </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-s/01/2a/fd/93/avatar.jpg" width="80">
                <a title="" href="https://www.facebook.com/pg/freewalkingtourscusco/reviews/?ref=page_internal">Marta R</a>
              </div>
            </div>
                  <div class="col-md-4 col-sm-6 hidden-xs">
                <div class="block-text rel zmin">
                    <a title="" href="#">Excellent!</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Once again TripAdvisor community, you have not let me down! This was an excellent walking tour! The guide, Johan, is everything that a good guide should be: knowledgeable, passionate and entertaining! The tour actually lasted 3.5 hours and it just flew by. It was so interesting! We had a quick lunch stop which was perfectly timed. Johan makes a ton of recommendations that cater to every type of traveler.  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/10/da/12/70/noemie-s.jpg" width="80">
                    <a title="" href="#">Noemie S</a>
              </div>
            </div>
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
              <div class="block-text rel zmin">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Excellent Tour</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>This was one of the most interesting walking tours in Peru. It covered not only the history of Arequipa and Peru but also included topics like food, literature and the various cultural influences all over the city. The guide was extremely knowledgeable and engaging. Our group was massive but the guide managed to keep everyone involved and interested. </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-arequipa3.jpg" width="90">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">RaeLynn P</a>
              </div>
            </div>
                    </div>

                    <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
                <div class="block-text rel zmin">
                    <a title="" href="#">Excellent!</a>
                  <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                    <p>Once again TripAdvisor community, you have not let me down! This was an excellent walking tour! The guide, Johan, is everything that a good guide should be: knowledgeable, passionate and entertaining! The tour actually lasted 3.5 hours and it just flew by. It was so interesting! We had a quick lunch stop which was perfectly timed. Johan makes a ton of recommendations that cater to every type of traveler.  </p>
                      <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                    </div>
              <div class="person-text rel">
                <img alt="" src="https://media-cdn.tripadvisor.com/media/photo-l/10/da/12/70/noemie-s.jpg" width="80">
                    <a title="" href="#">Noemie S</a>
              </div>
            </div>
          </div>

          <div class="item hidden-sm hidden-lg">
             <div class="col-md-4 col-sm-6 hidden-sm hidden-lg">
              <div class="block-text rel zmin">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">Excellent Tour</a>
                <div class="mark">My rating: <span class="rating-input"><span data-value="1" class="glyphicon glyphicon-star"></span><span data-value="2" class="glyphicon glyphicon-star"></span><span data-value="3" class="glyphicon glyphicon-star"></span><span data-value="4" class="glyphicon glyphicon-star"></span><span data-value="5" class="glyphicon glyphicon-star"></span>  </span></div>
                  <p>This was one of the most interesting walking tours in Peru. It covered not only the history of Arequipa and Peru but also included topics like food, literature and the various cultural influences all over the city. The guide was extremely knowledgeable and engaging. Our group was massive but the guide managed to keep everyone involved and interested. </p>
                <ins class="ab zmin sprite sprite-i-triangle block"></ins>
              </div>
              <div class="person-text rel">
                <img alt="" src="/img/reviews/review-arequipa3.jpg" width="90">
                <a title="" href="https://www.tripadvisor.com.pe/Attraction_Review-g294313-d6023591-Reviews-Free_Tour_Downtown_Arequipa-Arequipa_Arequipa_Region.html">RaeLynn P</a>
              </div>
            </div>
          </div>


                                    
                </div>
                <a class="left carousel-control" href="#carousel-reviews" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" href="#carousel-reviews" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </div>
    </div>
</div>
       <div id="contenido-ruta">
                                 <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/" itemprop="url" title="INICIO" class="linkgeneral">
                                      <span itemprop="title">Home</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                                    <a href="/arequipa/" itemprop="url" title="Lima" class="linkgeneral">
                                      <span itemprop="title">Arequipa</span>
                                    </a>»
                                  </div> 
                                  <div class="contenedor-ruta-navegacion">
                      
                                      <strong>Free Walking Tour Arequipa at 3:00 pm</strong>
                                  </div>
                  </div> 
    <div class="banners mt-5">
         <img src="../img/imgfooter.jpg" alt="publicidad logos">
      </div>
    <?php include('../footer.php');?>

    </div>

    </div>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
 <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>

     <script src="../js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <script src="../js/responsiveslides.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/easy-responsive-tabs.js"></script>
      <script src="../js/script-efectos.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="../js/mapa-arequipa.js"></script>

      <script>
       $(function() {
               $("#datepicker").datepicker({ dateFormat: "dd/mm/yy" }).val()
       });
   </script>
   <script>
  $('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 3000);
    return false;
});
</script>
 <script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submitarequipa.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>

<style>
    #owl-demo .item{
        margin: 3px;
    }
    #owl-demo .item img{
        display: block;
        width: 100%;
        height: auto;
    }
    </style>


  </body>


</html>

