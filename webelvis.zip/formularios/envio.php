
<?php
$from = $_POST['fapellidos'];
$subject = 'Reserva free walks';
$message = 'Nombre: ' . $_POST['fnombres'] . 
"\n". 'E-mail: ' . $_POST['fapellidos']. 
"\n". 'Numero de Pasajeros:' . $_POST['size']. 
"\n". 'Ciudad:' . $_POST['country'].
"\n". 'Hora:' . $_POST['combo2'].
"\n". 'Fecha:' . $_POST['date'].
"\n". 'Mensaje:' . $_POST['data']

;

$headers = "From: ". $from . "\n";
mail ('jroelxx@gmail.com', $subject, $message, $headers);


// header('Location: thanks.html');

echo "Tus datos fueron enviados correctamente <b>".$_POST['fnombres']."</b>";
?>