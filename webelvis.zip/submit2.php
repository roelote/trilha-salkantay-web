<?php
if($_POST)
{
   $fname = $_POST['name1'];
    $email = $_POST['email2'];
    $nombretours = $_POST['ciudad1'];
    $fecha=$_POST['date1'];
    $lname = $_POST['size1'];
    $phno = $_POST['message1'];

    

$from = $_POST['email2'];

$subject = 'Free Walks Lima - English';
$subject2= 'Your CONFIRMATION Details Lima';
$message = 
'<table width="300" border="1" align="center" cellpadding="1" cellspacing="1"
  <tr>
    <th colspan="2">Free Tour by Foot Lima<br></th>
  </tr>
  <tr>
    <td>Name<br></td>
    <td>'.$fname.'</td>
  </tr>
  <tr>
    <td>Tour<br></td>
    <td>'.$nombretours.'</td>
  </tr>
  <tr>
    <td>Date<br></td>
    <td>'.$fecha.'</td>
  </tr>
  <tr>
    <td>Nro Pax<br></td>
    <td>'.$lname.'</td>
  </tr>
  <tr>
    <th colspan="2">Message<br></th>
  </tr>
   <tr>
   <th colspan="2">'.$phno.'<br></th>
  </tr>
</table>';

$message2 = 
'<table style="height: 173px; width: 456.767px;" border="1">
<tbody>
<tr>
<td style="width: 130px;">Company:</td>
<td style="width: 304.767px; text-align: center;"><strong>Inkan Milky Way Tours Lima </strong></td>
</tr>
<tr>
<td style="width: 130px;">Pax Name:</td>
<td style="width: 304.767px;">&nbsp;'.$fname.'</td>
</tr>
<tr>
<td style="width: 130px;">Size of Group:</td>
<td style="width: 304.767px;">&nbsp;'.$lname.'</td>
</tr>
<tr>
<td style="width: 130px;">Date of the Tour:</td>
<td style="width: 304.767px;">&nbsp;'.$fecha.'</td>
</tr>
<tr>
<td style="width: 130px;">Starting Time:</td>
<td style="width: 304.767px;">&nbsp;'.$nombretours.'</td>
</tr>
<tr>
<td style="width: 130px;">Meeting Point:</td>
<td style="width: 304.767px; text-align: left;">
<p>*<strong>10am</strong> Pick up time:&nbsp;Join us at <a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.1235112,-77.0287202,15z/data=!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.1235112!4d-77.0287202">Calle Tarata 248</a>, Mama Olla Restaurant, in Miraflores.</p>
<p><span style="font-weight: 400;">*</span><strong>11am</strong><span style="font-weight: 400;"> &amp; </span><strong>3pm</strong><span style="font-weight: 400;"> Meet up time: Join us in front of </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">La Merced Church</span></a><span style="font-weight: 400;">, at Jiron de la Union in dwntwn Lima.</span></p>
</td>
</tr>
</tbody>
</table>
<p style="margin-top: 0px; margin-bottom: 0px; color: #000000; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; font-family: Calibri,Arial,Helvetica,sans-serif;"><span style="font-size: 18px;"><strong><span style="color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="color: #888888; font-family: Calibri,Arial,Helvetica,sans-serif;"><span style="color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="color: #006fc9; font-family: Calibri,Arial,Helvetica,sans-serif;"><span style="font-family: Calibri,Arial,Helvetica,sans-serif;"><span style="color: #000000;">NOTE:</span></span></span></span></span></span></strong></span></p>
<ul>
<li style="font-weight: 400;"><span style="font-weight: 400;">We are </span><strong>Inkan Milky Way Tours Lima</strong><span style="font-weight: 400;">, your booking is confirmed, we already got u on our system, we will be waiting for you at the Correct Meeting Point, don&rsquo;t make us wait for you for nothing, if you cannot come, let us know.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Our Official tour Guides Elvis or Richard wear the </span><span style="font-weight: 400; background-color: #ffff00;">Inkan Milky Way Logo</span><span style="font-weight: 400;">, on the yellow vests, Look for the logo, not for the colour.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">We operate free tours in Lima from mon to sat only &ndash; </span><span style="font-weight: 400; color: #ff0000;">No Sundays</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Lima free tour at 3pm:</span><span style="font-weight: 400;"> If you booked this afternoon free tour way in advance, double check our website one day prior to your </span><a href="https://www.freewalkingtoursperu.com/lima/free-walking-tour-lima-afternoon"><span style="font-weight: 400;">free tour at 3pm</span></a><span style="font-weight: 400;">, since we operate this afternoon free tour in the high season only.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400; color: #ff0000;">Don&rsquo;t look for us at Plaza de Armas at Nowhere in Peru</span><span style="font-weight: 400;">, we have specific meeting points, </span><span style="font-weight: 400; color: #ff0000;">NO plaza de armas.</span></li>
<li style="font-weight: 400;"><span style="color: #ff0000;"><strong>Be aware</strong><span style="font-weight: 400;"> with people wearing </span><strong>Fake yellow vests</strong><span style="font-weight: 400;"> in Lima</span></span><span style="font-weight: 400;">, withOUT our logo.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Any review for our Free Tours in&nbsp;Lima go to&nbsp;</span><a href="https://web.facebook.com/InkanMilkyWayToursLima/"><span style="font-weight: 400;">Inkan Milky Way Tours Lima</span></a><span style="font-weight: 400;">.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">See our Meeting Point google maps: </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.123592,-77.028598,14z/data=!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.123592!4d-77.028598?hl=es-ES"><span style="font-weight: 400;">10am</span></a><span style="font-weight: 400;"> &amp; </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">11am</span></a><span style="font-weight: 400;"> &amp; </span><a href="https://www.google.com/maps/place/Inkan+Milky+Way+Lima,+Free+Tour/@-12.048165,-77.032845,16z/data=!4m5!3m4!1s0x0:0x260b4404fb6284e!8m2!3d-12.048165!4d-77.0328452?hl=es-ES"><span style="font-weight: 400;">3pm</span></a></li>
</ul>
<p><strong>How to find us in Miraflores?</strong>&nbsp;We are just 2min to 5min AWAY from Kennedy Park (on foot). Use as Landmark <a href="https://www.google.com.pe/maps/place/Inkan+Milky+Way+Lima,+Free+Walking+Tour/@-12.1235112,-77.0287202,15z/data=!4m5!3m4!1s0x0:0x3e2cd448586ebf0b!8m2!3d-12.1235112!4d-77.0287202">Tarata street</a>, everybody knows this street.</p>
<p><strong>Keep free walking with us in three cities: </strong><a href="https://www.freewalkingtoursperu.com/lima/">Lima</a><strong>, </strong><a href="https://www.freewalkingtoursperu.com/arequipa/">Arequipa</a><strong> and </strong><a href="https://www.freewalkingtoursperu.com/cusco/">Cusco</a><strong>, </strong><a href="https://www.freewalkingtoursperu.com/booking/">BOOK NOW</a><strong>!</strong></p>
<p><span style="font-size: 12pt;"><strong style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #888888;"><span style="font-size: 14px; color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><img style="margin-left: 5px;" src="http://www.inkanmilkyway.com/wp-content/uploads/2018/03/map-lima-nuevo-en.jpg" alt="Meeting Point Lima 10am" width="260" height="249" /></span></strong></span> <span style="font-size: 12pt;"><strong style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #888888;"><span style="font-size: 14px; color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><img src="https://www.freewalkingtoursperu.com/img//map-lima-free-tour-11am-3pm.png" alt="Meeting Point lima 10-30am" width="260" height="249" /></span></strong></span></p>
<p style="margin-top: 0px; margin-bottom: 0px; color: #000000; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; font-family: Calibri, Arial, Helvetica, sans-serif;"><strong style="font-size: 14px; font-family: Arial, Helvetica, sans-serif;">Inkan Milky Way Tours Lima<br /></strong></p>
<p style="margin-top: 0px; margin-bottom: 0px; color: #000000; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; font-family: Calibri, Arial, Helvetica, sans-serif;"><strong style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt;"><span style="color: #bd1398;">Contact Numbers</span></strong><span style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt; color: #bd1398;">:</span></p>
<p style="margin-top: 0px; margin-bottom: 0px; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #666666; font-family: Calibri, Arial, Helvetica, sans-serif;"><span style="font-size: 12px; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="background-color: #ffffff; color: #000000;"><span style="font-size: 9pt; font-family: sans-serif; color: #000000; background: white none repeat scroll 0% 0%;"><span style="color: #008000;">Whatsapp:</span> +51 958745640 &amp; +51 984479073 <br /></span></span></span></p>
<p style="font-size: 11px;"><a href="http://www.freewalkingtoursperu.com">www.freewalkingtoursperu.com</a><strong> is operated &amp; powered by Inkan Milky Way Tours.</strong></p>
<p style="font-size: 11px;">If your tour guide, does not show up, please contact us, send us a WhatstApp message and give us the opportunity to explain you, this situation might happen because of strikes.</p>
';

$from3=$fname."<".$email.">";
$headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers .= "From: ". $from3 . "\n";

$from2='Inkan Milky Way Tours & Walks <info@freewalkingtoursperu.com>';
$headers2 = 'MIME-Version: 1.0' . "\r\n";
    $headers2 .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers2 .= "From: ". $from2 . "\n";

mail ('info@freewalkingtoursperu.com ', $subject, $message, $headers);

mail ($from, $subject2, $message2, $headers2);




    ?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2" class="resultado">Thanks for booking with Inkan Milky Way Tours & Walks, we just REPLIED you with all your CONFIRMATION Details, CHECK OUT your INBOX or SPAM BOX so that you get to the Correct Meetting Point and Tour Guide.
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">NOTICE: Double check your Meeting Point Map for each city.</span></td>
    </tr>
    </tbody></table>
    <?php
    
}

?>