<?php
$from = $_POST['email'];
$subject = 'Pregunta free tours ';
$message = 'Nombre: ' . $_POST['name'] . 
"\n". 'E-mail: ' . $_POST['email']. 
"\n". 'Nacionalidad:' . $_POST['nationality']. 
"\n". 'Asunto:' . $_POST['subject'].
"\n". 'Mensaje:' . $_POST['data']

;

$headers = "From: ". $from . "\n";
mail ('info@freewalkingtoursperu.com', $subject, $message, $headers);

echo"Thanks for choosing Free Tours by Foot Peru.Your inquire/booking has been sent successfully | We will reply you very soon | If you do not get NO reply to your booking just show up PLS | Before coming to the Free Tours DOUBLE CHECK your MEETING POINT MAP for every city.";
?>