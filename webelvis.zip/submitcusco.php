<?php
if($_POST)
{
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phno = $_POST['phno'];
    $fecha=$_POST['date'];
    $nombretours = $_POST['nombretour'];

    

$from = $_POST['email'];

$subject = 'Free Walks Cusco - English';
$subject2= 'Your CONFIRMATION Details - Cusco';
$message = 
'<table width="300" border="1" align="center" cellpadding="1" cellspacing="1"
  <tr>
    <th colspan="2">Booking Free Tour by Foot Cusco<br></th>
  </tr>
  <tr>
    <td>Name<br></td>
    <td>'.$fname.'</td>
  </tr>
  <tr>
    <td>Tour<br></td>
    <td>'.$nombretours.'</td>
  </tr>
  <tr>
    <td>Date<br></td>
    <td>'.$fecha.'</td>
  </tr>
  <tr>
    <td>Nro Pax<br></td>
    <td>'.$lname.'</td>
  </tr>
  <tr>
    <th colspan="2">Message<br></th>
  </tr>
   <tr>
   <th colspan="2">'.$phno.'<br></th>
  </tr>
</table>';

$message2 = 
'<table style="height: 173px; width: 456.767px;" border="1">
<tbody>
<tr>
<td style="width: 130px;">Company:</td>
<td style="width: 304.767px; text-align: center;"><strong>FTF Logo on the Yellow Vests<br /> </strong>Inkan Milky Way - Tours by Foot Cusco</td>
</tr>
<tr>
<td style="width: 130px;">Pax Name:</td>
<td style="width: 304.767px;">&nbsp;'.$fname.'</td>
</tr>
<tr>
<td style="width: 130px;">Size of Group:</td>
<td style="width: 304.767px;">&nbsp;'.$lname.'</td>
</tr>
<tr>
<td style="width: 130px;">Date of the Tour:</td>
<td style="width: 304.767px;">&nbsp;'.$fecha.'</td>
</tr>
<tr>
<td style="width: 130px;">Starting Time:</td>
<td style="width: 304.767px;">&nbsp;'.$nombretours.'</td>
</tr>
<tr>
<td style="width: 130px;">Meeting Point:</td>
<td style="width: 304.767px; text-align: center;">Plazoleta Regocijo (Kusipata) in front of the <strong>City Hall</strong> or the <strong>Choco Museo</strong></td>
</tr>
</tbody>
</table>
<p style="text-align: center;"><strong><span style="color: #000000;">NOTE:</span></strong></p>
<p>Your Professional Tour Guide will be waiting for you, <span style="background-color: #ffff00;">he wears FTF logo on the YELLOW VESTS <strong>UNDERNEATH</strong> a Jacket</span>, because the tour agencies don&rsquo;t want us to wear them, <strong>so just ask your tour guide to SHOW YOU the <span style="background-color: #ffff00;">FTF logo.</span></strong></p>
<p>You can also ask for our names: Elvis, Richard and Daniel, we are all brothers, ask for these names at the correct meeting point.</p>
<p><strong>&nbsp;</strong></p>
<ul>
<li>We offer original historical walks: NO Bars - No Restaurants - NO&nbsp;Drinks.</li>
<li><span style="color: #ff0000;">Do not get confused with other people claiming to work with us AT the Plaza de Armas,&nbsp;Plaza Espinar, they are not our team, they wear blue t-shirts, white t-shirts, ogange t-shirts, purple vests.</span></li>
<li>If you miss your free tour, you can still join us at the following departures: From Mon to Sat at: <strong>10am &ndash; 1pm &ndash; 3:30pm</strong> &ndash; on <em>Sundays at <strong>10am only</strong>.</em></li>
<li>See our 3D Meeting Point Map for Cusco below or here <a href="https://www.freewalkingtoursperu.com/cusco/walking-tour-map/">Cusco Meeting Point Map</a></li>
</ul>
<p><img src="http://www.inkanmilkyway.com/wp-content/uploads/2017/10/fotos-guides.jpg" alt="Tour Guides" width="500" height="228" /></p>
<p>&nbsp;<span style="font-size: 12pt;"><strong style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #888888;"><span style="font-size: 14px; color: #05233d; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><img src="https://www.freewalkingtoursperu.com/img/cusco-walks.png" alt="Meeting Point Cusco" width="497" height="288" /></span></strong></span></p>
<p><strong style="font-size: 14px; font-family: Arial, Helvetica, sans-serif;">Free Tours by Foot Cusco - Inkan Milky Way Co.</strong></p>
<p><strong style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt;"><span style="color: #bd1398;">If you are lost call us, we will pick you up</span></strong><span style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt; color: #bd1398;">:</span></p>
<p style="margin-top: 0px; margin-bottom: 0px; font-size: 12pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #666666; font-family: Calibri, Arial, Helvetica, sans-serif;"><span style="font-size: 12px; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="color: #1b4260;"><span style="background-color: #ffffff; color: #000000;">Whatsapp: +51&nbsp;958745640</span></span><a id="LPNoLP" href="mailto:j_per_44@hotmail.com"></a><span style="background-color: #ffffff; color: #000000;">&nbsp;- &nbsp;<span style="font-family: Arial, Helvetica, sans-serif; font-size: 13.3333px;">Elvis Peralta</span></span></span></p>
<p style="margin-top: 0px; margin-bottom: 0px; font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; color: #666666;"><span style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 12pt;"><span style="font-size: 12px; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 12px;"><span style="color: #1b4260;"><span style="background-color: #ffffff; color: #000000;">Whatsapp:+&nbsp;</span></span></span></span><span style="font-size: 12pt;"><span style="font-size: 12px; font-family: Trebuchet MS,Arial,Helvetica,sans-serif;"><span style="font-family: Calibri, Arial, Helvetica, sans-serif; font-size: 16px;"><span style="color: #1b4260;"><span style="background-color: #ffffff; color: #757b80;"><span style="color: #000000; font-size: 12px;">51&nbsp;984479073</span><span style="color: #000000;"> -&nbsp; <span style="font-family: Arial, Helvetica, sans-serif; font-size: 13.3333px;">Richard Peralta</span></span></span></span></span></span></span></span></p>';

$from3=$fname."<".$email.">";
$headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers .= "From: ". $from3 . "\n";

$from2='Inkan Milky Way Tours<info@freewalkingtoursperu.com>';
$headers2 = 'MIME-Version: 1.0' . "\r\n";
    $headers2 .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
     $headers2 .= "From: ". $from2 . "\n";

mail ('info@freewalkingtoursperu.com', $subject, $message, $headers);

mail ($from, $subject2, $message2, $headers2);





	?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2" class="resultado1">Thanks for booking with Inkan Milky Way Tours Cusco, we just replied you with all your Confirmation Details, Check your Inbox or Spam Box, so that you get to the Correct Meeting Point – If no reply show up at the Correct Meeting Point, we already got you in our system – Double check your meet up times, especially on Sundays.
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">NOTICE: Double check your Meeting Point Map for each city.</span></td>
    </tr>
    </tbody></table>
    <?php
	
}

?>
