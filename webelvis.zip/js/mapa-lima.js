function myMap() 
{
    var locations = [
      ['<div> <div class="contenidos-map"><h2>Inkan Milky Way Tours 10am</h2><p class=texto-map>Visit us <a href="/"> website</a></p></div></div>',  -12.124288, -77.026953, 2],
      ['<div> <div class="contenidos-map"><h2>Inkan Milky Way Tours 10:50am</h2><p class=texto-map>Visit us <a href="/"> website</a></p></div></div>',-12.048112, -77.032331, 1]
    ];

    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 12,
      scrollwheel: false,
      center: new google.maps.LatLng(-12.070757, -77.034202),
      mapTypeId: google.maps.MapTypeId.HYBRID,
    });



    var infowindow = new google.maps.InfoWindow();


    var marker, i;

    for (i = 0; i < locations.length; i++) {  
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map
      });


      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));


      var infowindow = new google.maps.InfoWindow();
      infowindow.setContent(locations[i][0]);
      infowindow.open(map, marker);



    }
 
}





function loadScript()
{
  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyCIR_U-CJrv2TIvV4IQEG775gioW3Ffk4s&callback=myMap";
  document.body.appendChild(script);
}

window.onload = loadScript;