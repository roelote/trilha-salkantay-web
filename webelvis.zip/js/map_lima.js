
function initialize()
{
	var mapOptions = {
		zoom: 18,
		center: new google.maps.LatLng(-12.119570, -77.029134),
		
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		scrollwheel:false
		
	};
  /* crear el mapa */
	var map = new google.maps.Map(document.getElementById('mapa_lima'),mapOptions);
  /* estilos */
  var styles = [ { "featureType": "landscape", "elementType": "geometry", "stylers": [ { "saturation": 1 }, { "visibility": "simplified" }, { "hue": "#91ff00" } ] },{ "featureType": "road.local", "elementType": "geometry.stroke", "stylers": [ { "color": "#b7bfaa" } ] },{ "featureType": "road.arterial", "elementType": "geometry.fill", "stylers": [ { "visibility": "on" }, { "color": "#fffadc" } ] },{ "featureType": "road.arterial", "elementType": "labels.text.fill", "stylers": [ { "color": "#664037" } ] },{ "featureType": "road.arterial", "elementType": "labels.text.stroke", "stylers": [ { "color": "#ffffff" } ] },{ "featureType": "road.highway", "elementType": "geometry.fill", "stylers": [ { "color": "#e3daa8" } ] },{ "featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [ { "color": "#595643" } ] },{ "featureType": "road.highway", "elementType": "labels.text.stroke", "stylers": [ { "color": "#ffffff" } ] },{ "featureType": "road.local", "elementType": "labels.text.fill", "stylers": [ { "color": "#383b33" } ] },{ "featureType": "poi.park", "elementType": "geometry.fill", "stylers": [ { "visibility": "on" }, { "color": "#a1d455" } ] } ];
  map.setOptions({styles: styles});	
  /* mostrar además los otros hostales en la ciudad */
 	   var neighborhoods = [
		new google.maps.LatLng(-12.119570, -77.029134)];
		var nombres = ["Free Walking Tour Lima"];
		var direcciones = ["Plaza de Armas"];
		var url = ["/booking"];
		var markers = [];
		var image = '/img/maker_plus.png';
		for (var i = 0; i < neighborhoods.length; i++) 
		{		
		var marker = new google.maps.Marker({
		position: neighborhoods[i],
		map: map,
		icon: image,
		title: nombres[i]
		});
		marker.html = '<div class="infowindow-googlemap"><h2 class="hostel-name-googlemap titlepeq title">'+nombres[i]+'</h2><div><p>'+direcciones[i]+'</p><p>Go to <a href="'+url[i]+'">'+nombres[i]+' website</a></p></div></div>';			
		var infowindow = new google.maps.InfoWindow({boxStyle: {
                background: "url('http://google-maps-utility-library-v3.googlecode.com/svn/trunk/infobox/examples/tipbox.gif') no-repeat",
                opacity: 0.75,
                width: "280px"
        }});		
		google.maps.event.addListener(marker, 'click', function() 
		{
			infowindow.setContent(this.html);
			infowindow.open(map, this);
		});
		markers.push(marker);	
	}
	mover(2, map, neighborhoods, markers);
	/* mostrar descripcion de la propiedad */
	/* centrar el mapa cuando se redimensiona la ventana */	
	google.maps.event.addDomListener(window, 'resize', function() 
	{
		window.setTimeout(function() {
			map.panTo(neighborhoods[2]);
		}, 3000);
	});	
}



function mover(pos, map, neighborhoods, markers)
{
	for (var i = 0; i < neighborhoods.length; i++) {
		var mark = markers[i];
		mark.setAnimation(null);
	}
	var marker = markers[pos];
	marker.setAnimation(google.maps.Animation.BOUNCE);
	//location.href = '#modal-hostel-map';
	  window.setTimeout(function() {
		  map.panTo(neighborhoods[pos]);
		}, 500);
}

function loadScript()
{
  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = "http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&sensor=false&callback=initialize";
  document.body.appendChild(script);
}

window.onload = loadScript;
