<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Free Walking Tour Contact Us| Free Tours by foot</title>
    <meta content="Contact us, free walking tour cusco, arequipa, miraflores, lima" name="description" />
    <meta content="free walking tour miraflores, free walks, city tours, miraflores walking tour map" name="keywords" />
    <meta content="en" name="language" />
   <meta name="author" content="Free Walking Tours" />

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/responsiveslides.css" rel="stylesheet">
    <link href="css/stylefwt.css" rel="stylesheet">
     <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" media="all" />
    
  </head>
  <body>

<style>
  /* clearfix */

  .linea-con
  {
    background: rgba(0, 0, 0, 0) url("https://www.inkanmilkyway.com/wp-content/uploads/2016/10/call-bg.png") no-repeat scroll center top;
    font-size: 18px;
    padding-top: 75px;
    text-transform: uppercase;
  }

   .information {
    float: right;
    margin-right: 90px;
    border: 1px solid gray;
    padding: 15px;
    border-radius: 10px;
    }

.information p {
    text-align: center;
}
.information .fa {
    color: teal;
}
.title-con
{
  font-weight: 600;
}
.clearfix {
  clear:both;
}

/* wrapper css */
#wrapper{
  margin-top:70px;
  width:100%;
}
#wrapper hgroup{
  text-align:center;
}
#wrapper h2{
  margin:5px 0;
  color:#FF6D99;
  text-shadow:1px 1px 2px #A50031;
  font-size:33px;
  font-family:Arial Narrow, Arial, sans-serif;
}
#wrapper h3{
  font-style:italic;
  font-weight:normal;
  font-size:18px;
  text-shadow:1px 1px 0 #fff;
  color:#888;
  margin:5px 0;
}

#container{
  position:relative;
  width:1100px;
  margin:0 auto 25px;
  padding-bottom: 10px;
  
}
.grid{
  width:188px;
  min-height:100px;
  padding: 15px;
  background:#fff;
  margin:8px;
  font-size:12px;
  float:left;
  box-shadow: 0 1px 3px rgba(34,25,25,0.4);
  -moz-box-shadow: 0 1px 3px rgba(34,25,25,0.4);
  -webkit-box-shadow: 0 1px 3px rgba(34,25,25,0.4);
  
  -webkit-transition: top 1s ease, left 1s ease;
  -moz-transition: top 1s ease, left 1s ease;
  -o-transition: top 1s ease, left 1s ease;
  -ms-transition: top 1s ease, left 1s ease;
}

.call
{
background: rgba(0, 0, 0, 0) url("https://www.inkanmilkyway.com/wp-content/uploads/2016/10/shadow-01.jpg") no-repeat scroll center bottom;
    margin-bottom: 30px;
    margin-top: 0;
    padding-bottom: 12px;
    right: 100px;
    width: 100%; 
}
.grid strong {
  border-bottom:1px solid #ccc;
  margin:10px 0;
  display:block;
  padding:0 0 5px;
  font-size:17px;
}
.grid .meta{
  text-align:right;
  color:#777;
  font-style:italic;
}
.grid .imgholder img{
  max-width:100%;
  background:#ccc;
  display:block;
}

.backd
{
    margin-top: 40px;
    color: #333;
    text-shadow: 1px 1px 1px #fff;
    font-family: 'Freeroad-Regular';
    background: url("img/puntos.png") repeat-x scroll 0 10px;
}
.blank
{
  background-color: #fff;
    color: #333;
    font-weight: 600;
    font-size: 25px;
}
h3 {
    padding: 0 1em;
}
@media screen and (max-width : 1240px) {
  body{
    overflow:auto;
  }
}
@media screen and (max-width : 900px) {
  #backlinks{
    float:none;
    clear:both;
  }

  .information
  {
      margin-right: 0px;
      margin-bottom: 30px;
      width: 100%;
      margin-top: 30px;
  }
  #backlinks a{
    display:inline-block;
    padding-right:20px;
  }
  #wrapper{
    margin-top:90px;
  }
}
@media only screen and (max-width: 700px){
   .container2
  {
    width: auto !important;
  }
  .container2 p
  {
    margin: 1em;
  }
  .grid
  {
    width: 100%;
  }
  #container
  {
    width: 100%;
    padding: 0 10px;
  }
  .imgholder {
    float: left;
    margin: 0 10px;
    width: 200px;
}
  }
</style>




    <div id="fb-root"></div>
    <div class="container">
      <header class="cabecera">
         <?php include('menu.php');?>
           <div class="slider">
                  <div id="wrappers" class="relativo over-effect">
                      <ul class="rslides" id="slider2">
                        <li><img src="img/contact-us.jpg" alt="free walking tours lima"></li>
                      </ul>
                </div>
            </div> 

              
      </header>

    <div class="cuerpo">

    <div class="container2">
      <div class="row">
        <h1 class="backd"><span class="blank px-4">CONTACT US</span></h1>
        
      </div>
     
     <div id="container">
        
        <?php include('cuadro-reservas.php');?>

        <div class="information">
          
          <p class="linea-con"></p>
          <p class="title-con">--IF YOU PREFER TO TALK TO US IN PERSON ---</p>
          <p class="text-center">…just give us a call at</p>
          <p><b>Cusco:</b><br> 
            <i class="fa fa-mobile" aria-hidden="true"></i> (+51)958 745 640<br>
            <i class="fa fa-mobile" aria-hidden="true"></i> (+51)984 479 073</p>
          <p><b>Lima:</b><br>
            <i class="fa fa-mobile" aria-hidden="true"></i> (+51)958 745 640<br>
            <i class="fa fa-mobile" aria-hidden="true"></i> (+51)984 479 073</p>
          <p><b>Arequipa:</b><br>
          <i class="fa fa-mobile" aria-hidden="true"></i> (+51)959 305 262 <br>
          <i class="fa fa-mobile" aria-hidden="true"></i> (+514)6631229 </p>
          <p><b>Calling hours:</b><br>
Mon to Sat from 6am to 10am<br>

Mon to Sat from 1pm to 10pm<br>

Sundays from 8am to 8pm</p>
          <div class="call"></div>

        </div>
    </div>

     </div>


    <div class="banners">
       <img src="img/imgfooter.jpg" alt="">
    </div>
  <?php include('footer.php');?>


</div>

   
    <script
        src="https://code.jquery.com/jquery-2.2.3.js"
        integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
        crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/blocksit.min.js"></script>
    <script src="js/responsiveslides.min.js"></script>
<script>
     $(document).ready(function()
{ 
  $(document).on('submit', '#reg-form', function()
  {
    var data = $(this).serialize();
    $.ajax({
    type : 'POST',
    url  : '../submit.php',
    data : data,
    success :  function(data)
           {            
            $("#reg-form").fadeOut(500).hide(function()
            {
              $(".result").fadeIn(500).show(function()
              {
                $(".result").html(data);
              });
            });
            
           }
    });
    return false;
  });
});

   </script>


  </body>


</html>