<?php




if($_POST)
{
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phno = $_POST['phno'];
    $nombretours = $_POST['nombretour'];
    

$from = $_POST['email'];
$subject = 'reserva tour';
$message = 'Nombre: ' . $fname . 
"\n". 'E-mail: ' . $email. 
"\n". 'Tour:' . $nombretours. 
"\n". 'Asunto:' . $lname. 
"\n". 'Mensaje:' . $phno;

$headers = "From: ". $from . "\n";
mail ('asdasd@asd3.com', $subject, $message, $headers);


	?>
    
    <table border="0">
    
    <tbody><tr>
    <td colspan="2">Thanks for choosing Free Tours by Foot Peru.
Your inquire/booking has been sent successfully.
We will reply you very soon.
If you do not get no reply to your booking just show up
  </td>
    </tr>
   
    <hr>

<tr><td>
  <span class="colornotice">NOTICE: Double check your Meeting Point Map for each city.</span></td>
    </tr>
    </tbody></table>
    <?php
	
}

?>